# **App Name**: SCAD InternLink

## Core Features:

- Company Registration: Company registration form with fields for name, industry, size, logo, and email.
- Internship Search and Filter: Internship listing display with search and filter options.
- Student Profile Management: Student profile page with sections for job interests, past internships, activities, and major selection.
- Company Dashboard: Company dashboard for managing internship posts and viewing applications.
- Report Submission: Report submission interface where students can create, read, update, and delete internship reports.

## Style Guidelines:

- Primary color: SCAD gold (#CFB53B) to maintain brand recognition.
- Secondary colors: Black and white to keep the design minimal.
- Accent: Teal (#008080) for interactive elements.
- Clean and modern typography for improved readability and accessibility.
- Consistent and professional icons to improve usability and guide the user.
- Clean and well-structured layouts that provide the application with consistent information architecture.