
"use client";

import type { FC } from 'react';
import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Video, VideoOff, Mic, MicOff, ScreenShare, PhoneOff, Send, Edit, Info, MessageSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Workshop, User } from '@/types';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import Image from 'next/image';

interface Message {
  id: string;
  sender: string; // 'You' or participant name
  text: string;
  timestamp: string;
}

interface WorkshopLiveInterfaceProps {
  workshop: Workshop;
  onLeave: () => void;
  notes: string;
  onNotesChange: (notes: string) => void;
  onSaveNotes: () => void;
  user: User | null;
}

export const WorkshopLiveInterface: FC<WorkshopLiveInterfaceProps> = ({
  workshop,
  onLeave,
  notes,
  onNotesChange,
  onSaveNotes,
  user
}) => {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isMicEnabled, setIsMicEnabled] = useState(true);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [chatInput, setChatInput] = useState("");

  useEffect(() => {
    const getCameraPermission = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setHasCameraPermission(false);
        toast({ variant: 'destructive', title: 'Device Not Supported', description: 'Your browser does not support camera/mic access.' });
        return;
      }
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        setStream(mediaStream);
        setHasCameraPermission(true);
        if (videoRef.current) videoRef.current.srcObject = mediaStream;
      } catch (error) {
        setHasCameraPermission(false);
        toast({ variant: 'destructive', title: 'Device Access Denied', description: 'Please enable camera/mic permissions.' });
      }
    };
    getCameraPermission();
    // Simulate initial chat messages
    setChatMessages([
        { id: '1', sender: workshop.facilitator || 'Facilitator', text: `Welcome to "${workshop.title}"! Feel free to ask questions.`, timestamp: new Date().toLocaleTimeString() },
    ]);

    // Simulate receiving a message
    const mockMessageTimer = setTimeout(() => {
        setChatMessages(prev => [...prev, {id: '2', sender: 'Another Attendee', text: 'This is insightful!', timestamp: new Date().toLocaleTimeString()}]);
        if(user?.isPro) { // Only show toast to pro users as per new user story
             toast({ title: "New Chat Message (Mock)", description: "Someone sent a message in the workshop chat." });
        }
    }, 15000);


    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
      clearTimeout(mockMessageTimer);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workshop.id]); // Added workshop.id to dependencies for re-initialization if workshop changes

  const toggleVideo = () => {
    if (stream) {
      stream.getVideoTracks().forEach(track => track.enabled = !isVideoEnabled);
      setIsVideoEnabled(!isVideoEnabled);
      toast({ title: `Video ${!isVideoEnabled ? 'On' : 'Off'}` });
    }
  };

  const toggleMic = () => {
    if (stream) {
      stream.getAudioTracks().forEach(track => track.enabled = !isMicEnabled);
      setIsMicEnabled(!isMicEnabled);
      toast({ title: `Mic ${!isMicEnabled ? 'On' : 'Off'}` });
    }
  };
  
  const handleScreenShare = async () => {
    toast({ title: 'Screen Sharing (Mock)', description: 'Screen sharing started.' });
  };

  const handleLeave = () => {
    if (stream) stream.getTracks().forEach(track => track.stop());
    toast({ title: 'Left Workshop', description: `You left "${workshop.title}".` });
    onLeave();
  };

  const handleSendChatMessage = () => {
    if (!chatInput.trim() || !user) return;
    const newMessage: Message = {
        id: Date.now().toString(),
        sender: 'You',
        text: chatInput,
        timestamp: new Date().toLocaleTimeString()
    };
    setChatMessages(prev => [...prev, newMessage]);
    setChatInput("");
    // Mock: Simulate facilitator response
    setTimeout(() => {
        setChatMessages(prev => [...prev, {id: Date.now().toString() + 'resp', sender: workshop.facilitator || 'Facilitator', text: 'Thanks for your question/comment!', timestamp: new Date().toLocaleTimeString()}]);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col p-4 overflow-hidden">
      <Card className="flex-1 flex flex-col shadow-2xl w-full max-w-6xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl text-primary">Live Workshop: {workshop.title}</CardTitle>
          <CardDescription>Facilitator: {workshop.facilitator || 'N/A'}</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 grid md:grid-cols-3 gap-4 overflow-hidden">
          {/* Main Video / Screen Share Area */}
          <div className="md:col-span-2 bg-muted rounded-lg aspect-video flex items-center justify-center text-muted-foreground relative overflow-hidden">
            {hasCameraPermission ? (
                 <Image src={`https://picsum.photos/seed/${workshop.id}live/1280/720`} layout="fill" objectFit="cover" alt="Workshop live stream placeholder" data-ai-hint="presentation screen" />
            ) : (
                 <VideoOff className="h-24 w-24" />
            )}
            {hasCameraPermission === false && (
                 <Alert variant="destructive" className="absolute bottom-4 left-4 max-w-md">
                    <Info className="h-4 w-4" />
                    <AlertTitle>Camera/Mic Issue</AlertTitle>
                    <AlertDescription>Device access denied. Your experience is limited.</AlertDescription>
                </Alert>
            )}
            {/* Overlay for participant video (placeholder) */}
             <div className="absolute bottom-4 right-4 w-1/4 max-w-[180px] aspect-video bg-secondary rounded-md border border-border overflow-hidden">
                <video ref={videoRef} className={`w-full h-full object-cover transform scale-x-[-1] ${!isVideoEnabled || !hasCameraPermission ? 'hidden' : ''}`} autoPlay muted playsInline />
                {(!hasCameraPermission || !isVideoEnabled) && <div className="w-full h-full flex items-center justify-center bg-muted"><VideoOff className="h-8 w-8 text-muted-foreground"/></div>}
                <p className="absolute bottom-1 left-1/2 -translate-x-1/2 text-xs bg-black/50 text-white px-1 rounded">You</p>
            </div>
          </div>

          {/* Sidebar for Chat & Notes */}
          <div className="flex flex-col space-y-4 overflow-hidden">
            {/* Chat Area */}
            <Card className="flex-1 flex flex-col">
              <CardHeader className="p-3 border-b">
                <CardTitle className="text-lg flex items-center"><MessageSquare className="mr-2 h-5 w-5"/>Chat</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 p-3 overflow-y-auto">
                <ScrollArea className="h-full">
                  {chatMessages.map(msg => (
                    <div key={msg.id} className={`mb-2 p-2 rounded-lg ${msg.sender === 'You' ? 'bg-primary/10 ml-auto' : 'bg-secondary'}`}>
                      <p className="text-xs text-muted-foreground">{msg.sender} - {msg.timestamp}</p>
                      <p className="text-sm">{msg.text}</p>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
              <CardFooter className="p-3 border-t">
                <div className="flex w-full gap-2">
                  <Textarea value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Type your message..." rows={1} className="flex-1 resize-none text-sm"/>
                  <Button onClick={handleSendChatMessage} size="icon"><Send className="h-4 w-4"/></Button>
                </div>
              </CardFooter>
            </Card>
            {/* Notes Area */}
            <Card className="flex-1 flex flex-col">
              <CardHeader className="p-3 border-b">
                <CardTitle className="text-lg flex items-center"><Edit className="mr-2 h-5 w-5"/>My Notes</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 p-0">
                <Textarea value={notes} onChange={(e) => onNotesChange(e.target.value)} placeholder="Take your notes here..." className="h-full w-full resize-none border-0 rounded-none focus-visible:ring-0 text-sm p-3"/>
              </CardContent>
              <CardFooter className="p-3 border-t">
                <Button onClick={onSaveNotes} variant="outline" size="sm" className="ml-auto">Save Notes</Button>
              </CardFooter>
            </Card>
          </div>
        </CardContent>
        <CardFooter className="flex flex-wrap justify-center items-center gap-3 p-4 border-t">
          <Button variant={isVideoEnabled ? "outline" : "secondary"} onClick={toggleVideo} disabled={!hasCameraPermission}>
            {isVideoEnabled ? <Video className="mr-2" /> : <VideoOff className="mr-2" />} {isVideoEnabled ? 'Video On' : 'Video Off'}
          </Button>
          <Button variant={isMicEnabled ? "outline" : "secondary"} onClick={toggleMic} disabled={!hasCameraPermission}>
            {isMicEnabled ? <Mic className="mr-2" /> : <MicOff className="mr-2" />} {isMicEnabled ? 'Mic On' : 'Mic Off'}
          </Button>
          <Button variant="outline" onClick={handleScreenShare}>
            <ScreenShare className="mr-2" /> Share Screen (Mock)
          </Button>
          <Button variant="destructive" onClick={handleLeave}>
            <PhoneOff className="mr-2" /> Leave Workshop
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};
