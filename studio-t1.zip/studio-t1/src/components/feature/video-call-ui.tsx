
"use client";

import type { FC } from 'react';
import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Video, VideoOff, Mic, MicOff, ScreenShare, PhoneOff, AlertTriangle, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface VideoCallUIProps {
  participantName: string;
  onLeaveCall: () => void;
  isCallCreator?: boolean; 
  onParticipantJoin?: () => void;
  onParticipantLeave?: () => void;
}

export const VideoCallUI: FC<VideoCallUIProps> = ({ 
  participantName, 
  onLeaveCall, 
  isCallCreator = true,
  onParticipantJoin,
  onParticipantLeave 
}) => {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isMicEnabled, setIsMicEnabled] = useState(true);
  const [stream, setStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    const getCameraPermission = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.error('MediaDevices API not supported.');
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Camera Not Supported',
          description: 'Your browser does not support camera access.',
        });
        return;
      }
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        setStream(mediaStream);
        setHasCameraPermission(true);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (error) {
        console.error('Error accessing camera/mic:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Device Access Denied',
          description: 'Please enable camera and microphone permissions in your browser settings.',
        });
      }
    };

    getCameraPermission();

    // Simulate participant joining
    const joinTimer = setTimeout(() => {
      if (onParticipantJoin) {
        onParticipantJoin();
      }
    }, 2500); // Simulate join after 2.5 seconds

    // Simulate participant leaving after some time
    const leaveTimer = setTimeout(() => {
      if (onParticipantLeave) {
        onParticipantLeave(); 
      }
      // Automatically leave the call after participant leaves
      // onLeaveCall(); // The parent component will now handle this after showing the toast
    }, 30000); // Simulate leave after 30 seconds

    return () => {
      // Cleanup stream on component unmount
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      clearTimeout(joinTimer);
      clearTimeout(leaveTimer);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  const toggleVideo = () => {
    if (stream) {
      stream.getVideoTracks().forEach(track => track.enabled = !isVideoEnabled);
      setIsVideoEnabled(!isVideoEnabled);
      toast({ title: `Video ${!isVideoEnabled ? 'Enabled' : 'Disabled'}` });
    }
  };

  const toggleMic = () => {
    if (stream) {
       stream.getAudioTracks().forEach(track => track.enabled = !isMicEnabled);
       setIsMicEnabled(!isMicEnabled);
       toast({ title: `Microphone ${!isMicEnabled ? 'Enabled' : 'Disabled'}` });
    }
  };

  const handleScreenShare = async () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
      try {
        toast({ title: 'Screen Sharing Started (Mock)', description: 'You are now sharing your screen.' });
      } catch (error) {
        console.error('Error starting screen share:', error);
        toast({ variant: 'destructive', title: 'Screen Share Failed', description: 'Could not start screen sharing.' });
      }
    } else {
      toast({ variant: 'destructive', title: 'Screen Share Not Supported', description: 'Your browser does not support screen sharing.' });
    }
  };

  const handleLeaveCallInternal = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    // Toast for self-leaving is handled by parent component
    onLeaveCall();
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl shadow-2xl">
        <CardHeader>
          <CardTitle className="text-2xl text-primary">Video Call with {participantName}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {hasCameraPermission === false && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Camera/Microphone Access Denied</AlertTitle>
              <AlertDescription>
                Video call functionality is limited. Please enable camera and microphone permissions in your browser settings and refresh.
              </AlertDescription>
            </Alert>
          )}
           {hasCameraPermission === null && (
            <Alert variant="default">
                <Info className="h-4 w-4" />
                <AlertTitle>Accessing Camera & Microphone</AlertTitle>
                <AlertDescription>
                    Please allow permission when prompted by your browser.
                </AlertDescription>
            </Alert>
           )}

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {/* Participant's video (main view) - Placeholder */}
            <div className="md:col-span-4 bg-muted rounded-lg aspect-video flex items-center justify-center text-muted-foreground relative overflow-hidden">
               {/* This area would typically show the other participant's video. For demo, it's a placeholder or mirrors own video if creator. */}
               {(isCallCreator && hasCameraPermission) || !isCallCreator ? ( // If not creator, assume this is where remote video shows
                 <video ref={videoRef} className={`w-full h-full object-cover ${!isVideoEnabled && isCallCreator ? 'hidden' : ''}`} autoPlay muted={isCallCreator} playsInline />
               ) : (
                 <p>Waiting for {participantName} to join...</p>
               )}
               {!isVideoEnabled && isCallCreator && hasCameraPermission && <VideoOff className="h-24 w-24 text-muted-foreground" />}
               {!hasCameraPermission && <VideoOff className="h-24 w-24 text-muted-foreground" />}
            </div>

            {/* Self video (small preview) */}
            <div className="md:col-span-1 space-y-2 flex flex-col items-center">
                <div className="bg-muted/50 rounded-lg aspect-square w-full max-w-[150px] md:w-full flex items-center justify-center text-muted-foreground overflow-hidden">
                  {/* Always show local preview if camera permission is granted, regardless of who created call initially */}
                  {hasCameraPermission ? (
                      <video ref={isCallCreator ? undefined : videoRef} src={isCallCreator ? videoRef.current?.srcObject ? URL.createObjectURL(videoRef.current.srcObject as MediaSource) : undefined : undefined } className={`w-full h-full object-cover transform scale-x-[-1] ${!isVideoEnabled ? 'hidden' : ''}`} autoPlay muted playsInline />
                  ) : (
                      <VideoOff className="h-12 w-12" />
                  )}
                  {hasCameraPermission && !isVideoEnabled && <VideoOff className="h-12 w-12 text-muted-foreground"/>}
                </div>
                <p className="text-xs text-center text-muted-foreground">Your Preview</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row justify-center items-center gap-3 p-4 border-t">
          <Button variant={isVideoEnabled ? "outline" : "secondary"} onClick={toggleVideo} disabled={!hasCameraPermission}>
            {isVideoEnabled ? <Video className="mr-2" /> : <VideoOff className="mr-2" />} {isVideoEnabled ? 'Stop Video' : 'Start Video'}
          </Button>
          <Button variant={isMicEnabled ? "outline" : "secondary"} onClick={toggleMic} disabled={!hasCameraPermission}>
            {isMicEnabled ? <Mic className="mr-2" /> : <MicOff className="mr-2" />} {isMicEnabled ? 'Mute Mic' : 'Unmute Mic'}
          </Button>
          <Button variant="outline" onClick={handleScreenShare}>
            <ScreenShare className="mr-2" /> Share Screen
          </Button>
          <Button variant="destructive" onClick={handleLeaveCallInternal}>
            <PhoneOff className="mr-2" /> Leave Call
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};
