
"use client";

import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  SidebarGroup,
  SidebarGroupLabel,
  useSidebar,
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { LogOut, LayoutDashboard, Briefcase, Users, FileText, BarChart2, Settings, CalendarDays, Video, GraduationCap, BookOpen, ListChecks, Crown } from "lucide-react"; // Added Crown
import { Logo } from "./logo";
import { useAuth } from "@/hooks/use-auth";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { LucideIcon } from "lucide-react";

interface NavLink {
  href: string;
  label: string;
  icon: LucideIcon;
  isProFeature?: boolean;
}

const commonLinks: NavLink[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/internships", label: "Internships", icon: Briefcase },
];

const studentLinks: NavLink[] = [
  ...commonLinks,
  { href: "/profile", label: "My Profile", icon: Users },
  { href: "/my-applications", label: "My Applications", icon: FileText },
  { href: "/my-reports", label: "My Reports", icon: BookOpen }, // No longer Pro
  { href: "/assessments", label: "Assessments", icon: ListChecks, isProFeature: true },
  { href: "/workshops", label: "Workshops", icon: CalendarDays, isProFeature: true }, // Now Pro
  { href: "/appointments", label: "Appointments", icon: Video, isProFeature: true },
];

const companyLinks: NavLink[] = [
  ...commonLinks,
  { href: "/company/jobs", label: "Job Posts", icon: Briefcase },
  { href: "/company/applications", label: "Applications", icon: FileText },
  { href: "/company/interns", label: "Interns", icon: Users },
];

const scadOfficeLinks: NavLink[] = [
  ...commonLinks,
  { href: "/scad-office/company-applications", label: "Company Approvals", icon: Users },
  { href: "/scad-office/students", label: "Students", icon: GraduationCap },
  { href: "/scad-office/reports", label: "Internship Reports", icon: FileText },
  { href: "/scad-office/statistics", label: "Statistics", icon: BarChart2 },
  { href: "/scad-office/workshops", label: "Manage Workshops", icon: CalendarDays },
  { href: "/scad-office/appointments", label: "Appointments", icon: Video },
  { href: "/scad-office/settings", label: "System Settings", icon: Settings },
];

const facultyLinks: NavLink[] = [
  ...commonLinks,
  { href: "/faculty/reports", label: "Review Reports", icon: FileText },
  { href: "/faculty/statistics", label: "View Statistics", icon: BarChart2 },
];


export function AppSidebar() {
  const { state } = useSidebar(); // For collapsed state
  const { user, logout } = useAuth();
  const pathname = usePathname();

  const getNavLinks = (): NavLink[] => {
    if (!user) return [];
    switch (user.role) {
      case 'student': return studentLinks;
      case 'company': return companyLinks;
      case 'scad_office': return scadOfficeLinks;
      case 'faculty': return facultyLinks;
      default: return commonLinks;
    }
  };

  const navLinks = getNavLinks();

  const isLinkActive = (href: string) => {
    if (href === "/dashboard") return pathname === href; // Exact match for dashboard
    return pathname.startsWith(href); // Prefix match for others
  }

  return (
    <Sidebar collapsible="icon" className="hidden md:flex">
      <SidebarHeader>
        <Logo collapsed={state === 'collapsed'} />
      </SidebarHeader>
      <SidebarContent className="p-2 flex-1">
        <SidebarMenu>
          {navLinks.map((link) => (
            <SidebarMenuItem key={link.href}>
              <Link href={link.href} passHref legacyBehavior>
                <SidebarMenuButton
                  isActive={isLinkActive(link.href)}
                  tooltip={{ children: link.label, className: "capitalize" }}
                  className="justify-start"
                >
                  {link.icon && <link.icon className="h-5 w-5" />}
                  <span className="truncate flex-1">{link.label}</span>
                  {link.isProFeature && user?.role === 'student' && (
                     <Crown className={`h-4 w-4 ml-auto ${user.isPro ? 'text-yellow-400 dark:text-yellow-500' : 'text-muted-foreground/50'}`} />
                  )}
                </SidebarMenuButton>
              </Link>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-2">
        <Separator className="my-2" />
         {user?.role === 'scad_office' && (
            <Link href="/scad-office/settings" passHref legacyBehavior>
                <SidebarMenuButton tooltip={{ children: "System Settings" }} className="justify-start">
                    <Settings className="h-5 w-5" /> 
                    <span>System Settings</span>
                </SidebarMenuButton>
            </Link>
         )}
         {user?.role !== 'scad_office' && (
            <Link href="/settings" passHref legacyBehavior>
                <SidebarMenuButton tooltip={{ children: "Settings" }} className="justify-start">
                    <Settings className="h-5 w-5" /> 
                    <span>Settings</span>
                </SidebarMenuButton>
            </Link>
         )}
        <SidebarMenuButton onClick={logout} tooltip={{ children: "Log Out" }} className="justify-start">
          <LogOut className="h-5 w-5" />
          <span>Log Out</span>
        </SidebarMenuButton>
      </SidebarFooter>
    </Sidebar>
  );
}
