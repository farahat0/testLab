
"use client";

import type { User, UserRole, CompanySizeKey, Industry, PastInternship, Major, InternshipApplication, InternshipApplicationStatus, StudentInternshipStatus, StudentAssessment } from '@/types';
import { Industries, Majors, Semesters } from '@/types'; // Import Majors and Semesters
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';

// Mock users - in a real app, this would come from a backend
export const MOCK_USERS: Record<string, Omit<User, 'id'>> = {
  'student@scad.edu': { 
    email: 'student@scad.edu', 
    role: 'student', 
    name: 'Alex Bee',
    jobInterests: 'UX Design, Web Development, Interactive Media',
    pastInternships: [
      { companyName: 'Digital Wonders LLC', jobTitle: 'UI Design Intern', responsibilities: 'Created wireframes and mockups for mobile apps. Conducted user testing sessions.', duration: 'Summer 2023' }
    ],
    collegeActivities: 'SCAD UX Club (President), Hackathon Participant (2022)',
    major: Majors[2], // UX Design
    semester: Semesters[4], // Semester 5
    isPro: false,
    internshipStatus: "Internship Completed",
  },
  'prostudent@scad.edu': { 
    email: 'prostudent@scad.edu', 
    role: 'student', // Role is still student, isPro flag handles PRO status
    name: 'Casey Dell',
    jobInterests: 'Game Development, 3D Animation',
    pastInternships: [
      { companyName: 'PixelPlay Studios', jobTitle: 'Junior Game Dev Intern', responsibilities: 'Asset creation, bug fixing, level design.', duration: 'Spring 2023 (3 Months)' },
      { companyName: 'Animagic Features', jobTitle: 'Animation Assistant', responsibilities: 'Clean-up animation, character rigging support.', duration: 'Fall 2022 (3 Months)' }
    ],
    collegeActivities: 'SCAD Game Dev Club, SIGGRAPH Volunteer',
    major: Majors[0], // Animation
    semester: Semesters[6], // Semester 7
    isPro: true, // This student is a PRO student
    internshipStatus: "Actively Interning",
    profileViewedBy: ["Tech Solutions Inc.", "Innovate Corp", "FutureAI"],
  },
   'newstudent@scad.edu': { 
    email: 'newstudent@scad.edu', 
    role: 'student', 
    name: 'Jordan River',
    major: Majors[3], // Film & Television
    semester: Semesters[1], // Semester 2
    isPro: false,
    internshipStatus: "Not Started",
  },
  'another@scad.edu': {
    email: 'another@scad.edu',
    role: 'student',
    name: 'Sam Lee',
    major: Majors[1], // Graphic Design
    semester: Semesters[7], // Semester 8
    isPro: true,
    internshipStatus: "Report Approved",
    profileViewedBy: ["PixelPlay Studios"],
  },
  'extra@scad.edu': {
    email: 'extra@scad.edu',
    role: 'student',
    name: 'Pat Jones',
    major: Majors[4], // Advertising
    semester: Semesters[3], // Semester 4
    isPro: false,
    internshipStatus: "Report Submitted",
  },
  'company@example.com': { 
    email: 'company@example.com', 
    role: 'company', 
    name: 'Tech Solutions Inc.' 
  },
  'innovate@example.com': { 
    email: 'innovate@example.com', 
    role: 'company', 
    name: 'Innovate Corp' 
  },
   'futureai@example.com': {
    email: 'futureai@example.com',
    role: 'company',
    name: 'FutureAI'
  },
  'pixelplay@example.com': {
    email: 'pixelplay@example.com',
    role: 'company',
    name: 'PixelPlay Studios'
  },
  'scad@scad.edu': { 
    email: 'scad@scad.edu', 
    role: 'scad_office', 
    name: 'SCAD Admin Ivy' 
  },
  'faculty@scad.edu': { 
    email: 'faculty@scad.edu', 
    role: 'faculty', 
    name: 'Prof. Ernest Smith' 
  },
};

const INITIAL_MOCK_STUDENT_APPLICATIONS: InternshipApplication[] = [
  { id: "app1", internshipId: "1", internshipTitle: "UX Design Intern", companyName: "Innovate Corp", companyId: "c1", studentId: "student@scad.edu", studentName: "Alex Bee", studentEmail: "student@scad.edu", status: "Completed", appliedDate: "2024-03-01T10:00:00Z", documents: [{ name: "Alex_Bee_UX_Resume.pdf" }, { name: "Innovate_CoverLetter.pdf" }] },
  { id: "app2", internshipId: "2", internshipTitle: "Software Engineer Intern", companyName: "Tech Solutions Inc.", companyId: "c2", studentId: "student@scad.edu", studentName: "Alex Bee", studentEmail: "student@scad.edu", status: "Reviewed", appliedDate: "2024-05-18T14:30:00Z", documents: [{ name: "alex_bee_swe_resume.pdf" }] },
  { id: "app3", internshipId: "4", internshipTitle: "Data Analyst Intern", companyName: "FutureAI", companyId: "c4", studentId: "student@scad.edu", studentName: "Alex Bee", studentEmail: "student@scad.edu", status: "Interviewing", appliedDate: "2024-05-15T09:00:00Z" },
  { id: "appStdRejected", internshipId: "job_std_rejected", internshipTitle: "Junior Web Developer", companyName: "Web Basics Co.", companyId: "comp_web_basics", studentId: "student@scad.edu", studentName: "Alex Bee", studentEmail: "student@scad.edu", status: "Rejected", appliedDate: "2024-05-10T00:00:00Z", documents: [{ name: "alex_bee_webdev_resume.pdf" }] },
  { id: "appStdAccepted", internshipId: "job_std_accepted", internshipTitle: "Content Writing Intern", companyName: "Wordsmith Inc.", companyId: "comp_wordsmith", studentId: "student@scad.edu", studentName: "Alex Bee", studentEmail: "student@scad.edu", status: "Accepted", appliedDate: "2024-04-25T00:00:00Z", documents: [{ name: "alex_bee_writing_sample.pdf" }] },
  
  { id: "app4", internshipId: "5", internshipTitle: "Graphic Design Intern", companyName: "Innovate Corp", companyId: "c1", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentEmail: "prostudent@scad.edu", status: "Offered", appliedDate: "2024-05-10T11:00:00Z", documents: [{ name: "Casey_Dell_Portfolio_Preview.pdf"}]},
  { id: "app5", internshipId: "job_completed_1", internshipTitle: "Past Animation Intern", companyName: "Animated Dreams", companyId: "comp_anim", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentEmail: "prostudent@scad.edu", status: "Completed", appliedDate: "2023-09-01T00:00:00Z", documents: [{ name: "casey_anim_final_report.pdf"}] },
  { id: "appProPending", internshipId: "job_pro_pending", internshipTitle: "AI Ethics Researcher (Pro)", companyName: "Ethical AI Now", companyId: "comp_ethical_ai", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentEmail: "prostudent@scad.edu", status: "Pending", appliedDate: "2024-06-01T00:00:00Z", documents: [{ name: "casey_dell_ai_ethics_proposal.pdf" }] },
  { id: "appProRejected", internshipId: "job_pro_rejected", internshipTitle: "Lead 3D Modeler (Pro)", companyName: "SculptVerse", companyId: "comp_sculptverse", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentEmail: "prostudent@scad.edu", status: "Rejected", appliedDate: "2024-05-28T00:00:00Z", documents: [{ name: "casey_dell_sculpt_portfolio.pdf" }] },
  { id: "appProAccepted", internshipId: "job_pro_accepted", internshipTitle: "Senior Game Designer (Pro)", companyName: "Epic Adventures", companyId: "comp_epic_adventures", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentEmail: "prostudent@scad.edu", status: "Accepted", appliedDate: "2024-05-20T00:00:00Z", documents: [{ name: "casey_dell_gamedesign_doc.pdf" }] },
];


interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  registerCompany: (details: {
    name: string;
    industry: Industry;
    size: CompanySizeKey;
    logo?: File;
    email: string;
    documents?: File[];
  }) => Promise<boolean>;
  updateUserProfile: (updatedUser: Partial<Omit<User, 'id' | 'email' | 'role'>>) => Promise<boolean>; // Make specific to profile updateable fields
  studentApplications: InternshipApplication[];
  addStudentApplication: (application: Omit<InternshipApplication, 'id' | 'appliedDate' | 'studentId' | 'studentName' | 'studentEmail' | 'status'>, files?: File[]) => Promise<boolean>;
  updateStudentApplicationStatus: (applicationId: string, status: InternshipApplicationStatus) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [studentApplications, setStudentApplications] = useState<InternshipApplication[]>(INITIAL_MOCK_STUDENT_APPLICATIONS);
  const router = useRouter();

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('scad-user');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error);
      localStorage.removeItem('scad-user');
    }
    setLoading(false);
  }, []);

  const login = async (email: string, pass: string): Promise<boolean> => {
    setLoading(true);
    const lowercaseEmail = email.toLowerCase();
    if (MOCK_USERS[lowercaseEmail]) {
      const userDataFromMock = MOCK_USERS[lowercaseEmail];
      const fullUserData: User = { 
        id: userDataFromMock.email, // Use email as ID for mock
        email: userDataFromMock.email,
        role: userDataFromMock.role,
        name: userDataFromMock.name,
        jobInterests: userDataFromMock.jobInterests,
        pastInternships: userDataFromMock.pastInternships,
        collegeActivities: userDataFromMock.collegeActivities,
        major: userDataFromMock.major,
        semester: userDataFromMock.semester,
        isPro: userDataFromMock.isPro,
        internshipStatus: userDataFromMock.internshipStatus,
        profileViewedBy: userDataFromMock.profileViewedBy,
      };
      localStorage.setItem('scad-user', JSON.stringify(fullUserData));
      setUser(fullUserData);
      router.push('/dashboard');
      setLoading(false);
      return true;
    }
    setLoading(false);
    return false;
  };

  const logout = () => {
    localStorage.removeItem('scad-user');
    setUser(null);
    setStudentApplications(INITIAL_MOCK_STUDENT_APPLICATIONS); 
    router.push('/login');
  };

  const registerCompany = async (details: {
    name: string;
    industry: Industry;
    size: CompanySizeKey;
    logo?: File;
    email: string;
    documents?: File[];
  }): Promise<boolean> => {
    setLoading(true);
    console.log("Company registration attempt:", details);
    const lowercaseEmail = details.email.toLowerCase();
    const newCompanyUser: User = { 
      email: lowercaseEmail, 
      role: 'company' as UserRole, 
      name: details.name, 
      id: lowercaseEmail,
      // Initialize other company-specific fields if any
    };
    MOCK_USERS[lowercaseEmail] = newCompanyUser; 
    localStorage.setItem('scad-user', JSON.stringify(newCompanyUser));
    setUser(newCompanyUser);
    router.push('/dashboard'); 
    setLoading(false);
    return true;
  };

  const updateUserProfile = async (updatedFields: Partial<Omit<User, 'id' | 'email' | 'role'>>): Promise<boolean> => {
    if (!user) return false;
    setLoading(true);
    const updatedUser: User = { ...user, ...updatedFields };
    
    // Update state
    setUser(updatedUser);
    
    // Update localStorage
    localStorage.setItem('scad-user', JSON.stringify(updatedUser));
    
    // Update MOCK_USERS in memory for current session consistency
    if (MOCK_USERS[user.email]) {
      // Ensure we only update fields that are part of the Omit<User, 'id'> type
      const mockUserToUpdate = MOCK_USERS[user.email];
      const safeUpdatedFields: Partial<Omit<User, 'id'>> = {};

      for (const key in updatedFields) {
        if (key !== 'id' && key !== 'email' && key !== 'role' && Object.prototype.hasOwnProperty.call(updatedFields, key)) {
          (safeUpdatedFields as any)[key] = (updatedFields as any)[key];
        }
      }
      MOCK_USERS[user.email] = { ...mockUserToUpdate, ...safeUpdatedFields };
    }
    setLoading(false);
    return true;
  };

  const addStudentApplication = async (applicationData: Omit<InternshipApplication, 'id' | 'appliedDate' | 'studentId' | 'studentName' | 'studentEmail' | 'status'>, files?: File[]): Promise<boolean> => {
    if (!user || user.role !== 'student') return false;

    const newApplication: InternshipApplication = {
      ...applicationData,
      id: `app${Date.now()}`, 
      studentId: user.id,
      studentName: user.name || 'Student Name Missing',
      studentEmail: user.email,
      appliedDate: new Date().toISOString(),
      status: 'Pending', 
      documents: files ? files.map(file => ({ name: file.name })) : applicationData.documents,
    };

    setStudentApplications(prevApplications => [newApplication, ...prevApplications]);
    INITIAL_MOCK_STUDENT_APPLICATIONS.unshift(newApplication); 
    console.log("Added new application:", newApplication);
    return true;
  };

  const updateStudentApplicationStatus = async (applicationId: string, status: InternshipApplicationStatus): Promise<boolean> => {
    setStudentApplications(prevApps => prevApps.map(app => 
      app.id === applicationId ? { ...app, status } : app
    ));
    const masterIndex = INITIAL_MOCK_STUDENT_APPLICATIONS.findIndex(app => app.id === applicationId);
    if (masterIndex !== -1) {
      INITIAL_MOCK_STUDENT_APPLICATIONS[masterIndex].status = status;
    }
    return true;
  };


  return (
    <AuthContext.Provider value={{ 
        user, 
        loading, 
        login, 
        logout, 
        registerCompany, 
        updateUserProfile,
        studentApplications,
        addStudentApplication,
        updateStudentApplicationStatus
      }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
