
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText, Search, Filter, CheckCircle, Edit3, Download, MessageSquareWarning, CalendarClock, User, XCircle } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { InternshipReport, InternshipReportStatus, Major } from "@/types";
import { Majors } from "@/types"; // Import Majors
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";


// Mock reports that this faculty member needs to review
const mockFacultyReports: InternshipReport[] = [
    { id: "report2", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentMajor: "Animation", internshipId: "5", internshipTitle: "Junior Game Dev Intern", companyName: "PixelPlay Studios", submissionDate: "2023-07-20T00:00:00Z", reportTitle: "PixelPlay Internship Overview", introduction: "This report covers my work at PixelPlay.", body: "Detailed tasks and achievements...", companyEvaluation: "PixelPlay provided a challenging yet rewarding environment.", recommendCompany: true, status: "Pending Review", facultyAdvisorId: "faculty@scad.edu", facultyAdvisorName: "Prof. Ernest Smith", internshipStartDate: "2023-05-01T00:00:00Z", internshipEndDate: "2023-07-15T00:00:00Z", companySupervisorName: "Mr. Dev Lead" },
    { id: "report4", studentId: "newstudent@scad.edu", studentName: "Jordan River", studentMajor: "Film & Television", internshipId: "int004", internshipTitle: "Design Intern", companyName: "Studio Max", submissionDate: "2023-09-05T00:00:00Z", reportTitle: "Branding Project Report", introduction: "My experience on the client X branding project.", body: "My role involved concept development and presentation.", status: "Pending Review", facultyAdvisorId: "faculty@scad.edu", facultyAdvisorName: "Prof. Ernest Smith", internshipStartDate: "2023-06-01T00:00:00Z", internshipEndDate: "2023-08-31T00:00:00Z", companySupervisorName: "Ms. Art Director" },
    { id: "report1", studentId: "student@scad.edu", studentName: "Alex Bee", studentMajor: "UX Design", internshipId: "1", internshipTitle: "UX Design Intern", companyName: "Innovate Corp", submissionDate: "2023-08-15T00:00:00Z", reportTitle: "Innovate Corp UX Internship", introduction: "Summary of my UX design internship.", body: "Worked on wireframes, user testing, and mockups.", companyEvaluation: "Innovate Corp has a great culture for interns.", recommendCompany: true, status: "Approved", facultyAdvisorId: "faculty@scad.edu", facultyAdvisorName: "Prof. Ernest Smith", internshipStartDate: "2023-05-15T00:00:00Z", internshipEndDate: "2023-08-10T00:00:00Z", companySupervisorName: "Dr. UX Head" },
    { id: "report_needs_revision_faculty", studentId: "student@scad.edu", studentMajor: "UX Design", studentName: "Alex Bee", internshipId: "compInternship1", internshipTitle: "Web Dev Intern", companyName: "Web Wizards", submissionDate: "2024-01-10T00:00:00Z", reportTitle: "Web Wizards Internship Report (Revision)", introduction: "Initial submission was lacking detail.", body: "Updated with more examples and outcomes.", status: "Appealed", facultyAdvisorId: "faculty@scad.edu", facultyAdvisorName: "Prof. Ernest Smith", facultyComments: "The introduction needs to be more specific.", appealMessage: "I have updated the introduction as requested and provided more detail in the body regarding my learning outcomes and challenges.", internshipStartDate: "2023-10-01T00:00:00Z", internshipEndDate: "2023-12-20T00:00:00Z", companySupervisorName: "Ms. Tech Lead" },
];


export default function FacultyReportsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reports, setReports] = useState<InternshipReport[]>([]);
  const [filteredReports, setFilteredReports] = useState<InternshipReport[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<InternshipReportStatus | "all">("all");
  const [selectedMajor, setSelectedMajor] = useState<Major | "all">("all"); // State for major filter
  const [viewingReport, setViewingReport] = useState<InternshipReport | null>(null);

  // State for clarification dialog
  const [isClarificationDialogOpen, setIsClarificationDialogOpen] = useState(false);
  const [reportForClarification, setReportForClarification] = useState<InternshipReport | null>(null);
  const [clarificationAction, setClarificationAction] = useState<InternshipReportStatus | null>(null);
  const [currentClarificationText, setCurrentClarificationText] = useState("");


  useEffect(() => {
    if (user?.role === 'faculty') {
        const facultySpecificReports = mockFacultyReports.filter(r => r.facultyAdvisorId === user.id);
        setReports(facultySpecificReports);
        setFilteredReports(facultySpecificReports);
    }
  }, [user]);

  useEffect(() => {
    let tempFiltered = reports;
    if (searchTerm) {
        tempFiltered = tempFiltered.filter(r => 
            r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            r.internshipTitle.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    if (filterStatus !== "all") {
        tempFiltered = tempFiltered.filter(r => r.status === filterStatus);
    }
    if (selectedMajor !== "all") { // Apply major filter
        tempFiltered = tempFiltered.filter(r => r.studentMajor === selectedMajor);
    }
    setFilteredReports(tempFiltered);
  }, [searchTerm, filterStatus, selectedMajor, reports]);

  const handleUpdateStatus = (reportId: string, newStatus: InternshipReportStatus, comments?: string) => {
    setReports(prev => prev.map(r => r.id === reportId ? {...r, status: newStatus, facultyComments: comments || r.facultyComments} : r));
    const masterIndex = mockFacultyReports.findIndex(r => r.id === reportId);
    if (masterIndex !== -1) {
        mockFacultyReports[masterIndex].status = newStatus;
        if(comments !== undefined) mockFacultyReports[masterIndex].facultyComments = comments; // Allow clearing comments
    }
    
    toast({title: "Report Status Updated", description: `Report marked as ${newStatus}.`});
    if (viewingReport?.id === reportId) {
        setViewingReport(prev => prev ? {...prev, status: newStatus, facultyComments: comments !== undefined ? comments : prev.facultyComments} : null);
    }
  };

  const openClarificationDialog = (report: InternshipReport, action: 'Needs Revision' | 'Rejected') => {
    setReportForClarification(report);
    setClarificationAction(action);
    setCurrentClarificationText(report.facultyComments || "");
    setIsClarificationDialogOpen(true);
  };

  const submitClarification = () => {
    if (reportForClarification && clarificationAction) {
      handleUpdateStatus(reportForClarification.id, clarificationAction, currentClarificationText);
      setIsClarificationDialogOpen(false);
      setReportForClarification(null);
      setClarificationAction(null);
      setCurrentClarificationText("");
    }
  };

  const handleDownloadReport = (report: InternshipReport) => {
    const reportContent = `
      Report Title: ${report.reportTitle}
      Student: ${report.studentName} (${report.studentId})
      Student Major: ${report.studentMajor || 'N/A'}
      Internship: ${report.internshipTitle} at ${report.companyName}
      Internship Dates: ${report.internshipStartDate ? new Date(report.internshipStartDate).toLocaleDateString() : 'N/A'} - ${report.internshipEndDate ? new Date(report.internshipEndDate).toLocaleDateString() : 'N/A'}
      Company Supervisor: ${report.companySupervisorName || 'N/A'}
      Submission Date: ${new Date(report.submissionDate).toLocaleDateString()}
      Status: ${report.status}
      Faculty Advisor: ${report.facultyAdvisorName || 'N/A'}

      Introduction:
      ${report.introduction || 'N/A'}

      Body:
      ${report.body || 'N/A'}

      Student's Evaluation of Company:
      ${report.companyEvaluation || 'Not Provided'}
      Recommend Company to other SCAD students: ${report.recommendCompany !== undefined ? (report.recommendCompany ? 'Yes' : 'No') : 'Not Provided'}

      Relevant SCAD Courses Mentioned:
      ${report.relevantCourses?.join(", ") || 'N/A'}
      
      Faculty Comments:
      ${report.facultyComments || 'N/A'}

      Student Appeal Message (if any):
      ${report.appealMessage || 'N/A'}
    `;
    const blob = new Blob([reportContent.trim()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.studentName}_${report.internshipTitle.replace(/\s+/g, '_')}_Report.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Report Downloaded", description: "The report content has been downloaded as a text file." });
  };
  
  const getStatusVariant = (status: InternshipReportStatus) => {
    switch(status) {
      case "Approved": return "default";
      case "Needs Revision": return "destructive";
      case "Rejected": return "destructive";
      case "Draft": return "outline";
      case "Appealed": return "secondary"; 
      case "Pending Review": return "secondary";
      default: return "secondary";
    }
  }


  if (user?.role !== 'faculty') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for faculty only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <FileText className="mr-3 h-8 w-8" /> Review Internship Reports
          </CardTitle>
          <CardDescription className="text-lg">
            Access and review internship reports submitted by students you advise.
          </CardDescription>
        </CardHeader>
        <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
                <div className="relative md:col-span-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input 
                        placeholder="Search student/job title..." 
                        className="pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Select value={selectedMajor} onValueChange={(val) => setSelectedMajor(val as Major | "all")}>
                    <SelectTrigger><SelectValue placeholder="Filter by Major" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Majors</SelectItem>
                        {Majors.map(m => (
                            <SelectItem key={m} value={m}>{m}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                <Select value={filterStatus} onValueChange={(val) => setFilterStatus(val as InternshipReportStatus | "all")}>
                    <SelectTrigger><SelectValue placeholder="Filter by Status" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        {(["Pending Review", "Approved", "Needs Revision", "Rejected", "Draft", "Appealed"] as InternshipReportStatus[]).map(s => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
          
          {filteredReports.length > 0 ? (
             <div className="space-y-4">
              {filteredReports.map((report) => (
                <Card key={report.id} className="overflow-hidden">
                  <CardHeader className="flex flex-row items-start justify-between space-x-4 p-4 bg-muted/30">
                    <div>
                      <CardTitle className="text-xl">{report.reportTitle}</CardTitle>
                      <CardDescription>
                        Student: {report.studentName} ({report.studentMajor || 'N/A'}) <br/>
                        Internship: {report.internshipTitle} at {report.companyName} <br/>
                        Submitted: {new Date(report.submissionDate).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <Badge variant={getStatusVariant(report.status)} className="whitespace-nowrap mt-1">
                       {report.status}
                   </Badge>
                  </CardHeader>
                  {report.appealMessage && report.status === "Appealed" && (
                     <CardContent className="p-4 border-t">
                        <Alert variant="default" className="bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700">
                          <MessageSquareWarning className="h-4 w-4 text-blue-500" />
                          <AlertTitle className="text-blue-700 dark:text-blue-300">Student Appeal Message</AlertTitle>
                          <AlertDescription className="text-blue-600 dark:text-blue-400">{report.appealMessage}</AlertDescription>
                        </Alert>
                      </CardContent>
                  )}
                  <CardFooter className="p-4 bg-muted/30 flex justify-end space-x-2">
                     <Button variant="outline" size="sm" onClick={() => { setViewingReport(report); }}>View Report</Button>
                     <Button variant="ghost" size="icon" onClick={() => handleDownloadReport(report)} title="Download Report">
                        <Download className="h-4 w-4" />
                      </Button>
                      {(report.status === 'Pending Review' || report.status === 'Appealed') && (
                        <>
                            <Button variant="default" size="sm" onClick={() => handleUpdateStatus(report.id, "Approved")}>
                                <CheckCircle className="mr-1.5 h-4 w-4"/> Approve
                            </Button>
                            <Button variant="outline" className="text-orange-600 border-orange-500 hover:bg-orange-50 hover:text-orange-700" size="sm" onClick={() => openClarificationDialog(report, "Needs Revision")}>
                                <Edit3 className="mr-1.5 h-4 w-4"/> Needs Revision
                            </Button>
                             <Button variant="destructive" size="sm" onClick={() => openClarificationDialog(report, "Rejected")}>
                                <XCircle className="mr-1.5 h-4 w-4"/> Reject
                            </Button>
                        </>
                      )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-10">No reports require your review at this time, or match current filters.</p>
          )}
        </CardContent>
      </Card>

      {/* Dialog to view full report and manage status/comments */}
      <Dialog open={!!viewingReport} onOpenChange={() => setViewingReport(null)}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl text-primary">{viewingReport?.reportTitle}</DialogTitle>
            <DialogDescription>
                <span className="block"><User className="inline h-4 w-4 mr-1" />Student: {viewingReport?.studentName} ({viewingReport?.studentId}) - Major: {viewingReport?.studentMajor || 'N/A'}</span>
                <span className="block"><FileText className="inline h-4 w-4 mr-1" />Internship: {viewingReport?.internshipTitle} at {viewingReport?.companyName}</span>
                <span className="block"><CalendarClock className="inline h-4 w-4 mr-1" />Dates: {viewingReport?.internshipStartDate ? new Date(viewingReport.internshipStartDate).toLocaleDateString() : 'N/A'} - {viewingReport?.internshipEndDate ? new Date(viewingReport.internshipEndDate).toLocaleDateString() : 'N/A'}</span>
                <span className="block"><User className="inline h-4 w-4 mr-1" />Company Supervisor: {viewingReport?.companySupervisorName || 'N/A'}</span>
            </DialogDescription>
          </DialogHeader>
            <ScrollArea className="max-h-[60vh] p-1 pr-3">
                <div className="space-y-4 py-4">
                    <h3 className="font-semibold text-lg">Introduction</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewingReport?.introduction || "N/A"}</p>
                    
                    <h3 className="font-semibold text-lg">Body</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewingReport?.body || "N/A"}</p>
                    
                    <h3 className="font-semibold text-lg">Student's Evaluation of Company</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewingReport?.companyEvaluation || "Not provided"}</p>
                    <p className="text-sm"><strong className="font-medium">Recommends Company:</strong> {viewingReport?.recommendCompany !== undefined ? (viewingReport.recommendCompany ? "Yes" : "No") : 'Not provided'}</p>
                    
                    <h3 className="font-semibold text-lg">Relevant SCAD Courses</h3>
                    <p className="text-sm text-muted-foreground">{viewingReport?.relevantCourses?.join(", ") || "N/A"}</p>
                    
                    {viewingReport?.facultyComments && (
                        <>
                            <h3 className="font-semibold text-lg">Your Comments</h3>
                            <p className="text-sm text-muted-foreground p-2 border rounded-md bg-secondary">{viewingReport.facultyComments}</p>
                        </>
                    )}
                    {viewingReport?.appealMessage && viewingReport.status === "Appealed" && (
                       <>
                         <h3 className="font-semibold text-lg text-blue-600">Student Appeal Message</h3>
                         <p className="text-sm text-blue-500 p-2 border border-blue-300 rounded-md bg-blue-50">{viewingReport.appealMessage}</p>
                       </>
                    )}
                </div>
            </ScrollArea>
            <DialogFooter className="pt-6 flex flex-col sm:flex-row gap-2">
                <div className="flex-grow">
                    Current Status: <Badge variant={getStatusVariant(viewingReport?.status || "Draft")}>{viewingReport?.status}</Badge>
                </div>
              <DialogClose asChild><Button type="button" variant="outline">Close</Button></DialogClose>
               {(viewingReport?.status === 'Pending Review' || viewingReport?.status === 'Appealed') && (
                <>
                    <Button variant="default" size="sm" onClick={() => viewingReport && handleUpdateStatus(viewingReport.id, "Approved")}>
                        <CheckCircle className="mr-1.5 h-4 w-4"/> Approve
                    </Button>
                    <Button variant="outline" className="text-orange-600 border-orange-500 hover:bg-orange-50 hover:text-orange-700" size="sm" onClick={() => viewingReport && openClarificationDialog(viewingReport, "Needs Revision")}>
                        <Edit3 className="mr-1.5 h-4 w-4"/> Mark as Needs Revision
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => viewingReport && openClarificationDialog(viewingReport, "Rejected")}>
                        <XCircle className="mr-1.5 h-4 w-4"/> Reject Report
                    </Button>
                </>
                )}
            </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clarification Dialog */}
      <Dialog open={isClarificationDialogOpen} onOpenChange={setIsClarificationDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl text-primary">
              Provide Clarification for {reportForClarification?.reportTitle}
            </DialogTitle>
            <DialogDescription>
              Please detail the reasons for marking this report as '{clarificationAction}'. <br/>
              Student: {reportForClarification?.studentName}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-2">
            <Label htmlFor="clarificationText">Comments / Clarification:</Label>
            <Textarea 
              id="clarificationText"
              value={currentClarificationText}
              onChange={(e) => setCurrentClarificationText(e.target.value)}
              rows={6}
              placeholder="Explain your reasoning clearly..."
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsClarificationDialogOpen(false)}>Cancel</Button>
            <Button onClick={submitClarification}>Submit Clarification</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}

