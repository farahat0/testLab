
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { BarChart2, Users, CheckSquare, Activity, Download, PieChart as PieChartIcon, TrendingUp, AlertTriangle, Star, BookOpen, Clock } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Pie, Cell, Legend, Tooltip, BarChart as RechartsBarChart, PieChart as RechartsPieChart } from 'recharts';
import * as RechartsPrimitive from "recharts";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const advisedStudentsCount = 15;
const reportsApprovedCount = 12; // For this faculty's advisees
const reportsRejectedOrFlaggedCount = 3; // For this faculty's advisees
const avgInternshipDuration = 3.5; // Months for advisees
const avgReviewTimeByFaculty = 2.1; // Days for this faculty

const studentPerformanceData = [
  { name: 'Alex B.', score: 85, fill: "hsl(var(--chart-1))" },
  { name: 'Casey D.', score: 92, fill: "hsl(var(--chart-2))" },
  { name: 'Jordan R.', score: 78, fill: "hsl(var(--chart-3))" },
  { name: 'Sam L.', score: 88, fill: "hsl(var(--chart-4))" },
  { name: 'Pat J.', score: 75, fill: "hsl(var(--chart-5))" },
];

const adviseeInternshipByIndustryData = [
  { name: 'Technology', value: 7, fill: "hsl(var(--chart-1))" },
  { name: 'Design', value: 4, fill: "hsl(var(--chart-2))" },
  { name: 'Marketing', value: 2, fill: "hsl(var(--chart-3))" },
  { name: 'Other', value: 2, fill: "hsl(var(--chart-4))" },
];

const adviseeFrequentlyUsedCoursesData = [
  { course: 'UXDS 200', count: 8, fill: "hsl(var(--chart-1))" },
  { course: 'ANIM 220', count: 6, fill: "hsl(var(--chart-2))" },
  { course: 'GRDS 101', count: 5, fill: "hsl(var(--chart-3))" },
];

const adviseeTopRatedCompaniesData = [
  { name: 'Innovate Corp', rating: 4.9, fill: "hsl(var(--primary))" },
  { name: 'PixelPlay', rating: 4.6, fill: "hsl(var(--accent))" },
  { name: 'Web Wizards', rating: 4.2, fill: "hsl(var(--secondary-foreground))" },
];


export default function FacultyStatisticsPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  const handleGenerateReport = () => {
    toast({
      title: "Advisee Report Generated (Mock)",
      description: "A report for your advisees' statistics has been downloaded.",
    });
    // Mock CSV generation for faculty
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Metric,Value\n"
      + `Advised Students,${advisedStudentsCount}\n`
      + `Reports Approved (Advisees),${reportsApprovedCount}\n`
      + `Reports Rejected/Flagged (Advisees),${reportsRejectedOrFlaggedCount}\n`
      + `Avg. Internship Duration (Advisees),${avgInternshipDuration} months\n`
      + `Avg. Report Review Time (Faculty),${avgReviewTimeByFaculty} days\n`
      + studentPerformanceData.map(s => `Student Assessment - ${s.name},${s.score}%`).join("\n") + "\n"
      + adviseeInternshipByIndustryData.map(i => `Advisee Industry - ${i.name},${i.value}`).join("\n") + "\n"
      + adviseeFrequentlyUsedCoursesData.map(c => `Advisee Course Usage - ${c.course},${c.count}`).join("\n") + "\n"
      + adviseeTopRatedCompaniesData.map(c => `Advisee Top Rated Company - ${c.name},${c.rating}`).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "faculty_advisee_statistics_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (user?.role !== 'faculty') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for faculty only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row justify-between items-start">
            <div>
                <CardTitle className="text-3xl font-bold text-primary flex items-center">
                    <BarChart2 className="mr-3 h-8 w-8" /> Advisee Performance Statistics
                </CardTitle>
                <CardDescription className="text-lg">
                    View statistics related to the students you advise in the internship program.
                </CardDescription>
            </div>
            <Button onClick={handleGenerateReport} variant="outline">
                <Download className="mr-2 h-4 w-4" /> Generate Advisee Report
            </Button>
        </CardHeader>
      </Card>

    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Advised Students</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{advisedStudentsCount}</div>
                <p className="text-xs text-muted-foreground">Currently active</p>
            </CardContent>
        </Card>
         <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Reports Approved (Advisees)</CardTitle>
                <CheckSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{reportsApprovedCount}</div>
                <p className="text-xs text-muted-foreground">This academic year</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Reports Rejected/Flagged</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{reportsRejectedOrFlaggedCount}</div>
                <p className="text-xs text-muted-foreground">Advisees, this cycle</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg. Review Time (You)</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{avgReviewTimeByFaculty} days</div>
                <p className="text-xs text-muted-foreground">Your average</p>
            </CardContent>
        </Card>
    </div>

    <div className="grid md:grid-cols-2 gap-6">
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><BarChart2 className="mr-2 h-5 w-5"/>Advisee Assessment Scores (Mock)</CardTitle>
                <CardDescription>Average scores from recent skills assessments for your advisees.</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                <ChartContainer config={{ score: { label: "Score", color: "hsl(var(--primary))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.BarChart data={studentPerformanceData} layout="vertical" margin={{ right: 20 }}>
                        <CartesianGrid horizontal={false} />
                        <XAxis type="number" dataKey="score" domain={[0, 100]} tickFormatter={(value) => `${value}%`} />
                        <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} tickMargin={8} width={80}/>
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <RechartsPrimitive.Bar dataKey="score" fill="var(--color-score)" radius={4} barSize={20} />
                        </RechartsPrimitive.BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><PieChartIcon className="mr-2 h-5 w-5"/>Advisee Internship Industries</CardTitle>
                <CardDescription>Distribution of your advisees' internships by industry.</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                 <ChartContainer config={{}} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.PieChart>
                            <RechartsPrimitive.Pie data={adviseeInternshipByIndustryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                            {adviseeInternshipByIndustryData.map((entry, index) => (
                                <RechartsPrimitive.Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                            </RechartsPrimitive.Pie>
                            <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                            <ChartLegend content={<ChartLegendContent nameKey="name" />} />
                        </RechartsPrimitive.PieChart>
                    </ResponsiveContainer>
                 </ChartContainer>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><BookOpen className="mr-2 h-5 w-5"/>Advisee: Frequently Used Courses</CardTitle>
                <CardDescription>Top courses your advisees cited as helpful in their internships.</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                <ChartContainer config={{ count: { label: "Mentions", color: "hsl(var(--accent))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.BarChart data={adviseeFrequentlyUsedCoursesData} layout="vertical" margin={{ right: 20 }}>
                        <CartesianGrid horizontal={false} />
                        <XAxis type="number" dataKey="count" />
                        <YAxis type="category" dataKey="course" tickLine={false} axisLine={false} tickMargin={8} width={100} />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <RechartsPrimitive.Bar dataKey="count" fill="var(--color-count)" radius={4} barSize={20} />
                        </RechartsPrimitive.BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><Star className="mr-2 h-5 w-5"/>Advisee: Top Rated Companies</CardTitle>
                <CardDescription>Highest rated companies by your advisees (out of 5).</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                 <ChartContainer config={{ rating: { label: "Avg. Rating", color: "hsl(var(--primary))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.BarChart data={adviseeTopRatedCompaniesData} >
                        <CartesianGrid vertical={false} />
                        <XAxis dataKey="name" tickLine={false} axisLine={false} tickMargin={8} />
                        <YAxis type="number" dataKey="rating" domain={[0,5]}/>
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <RechartsPrimitive.Bar dataKey="rating" fill="var(--color-rating)" radius={4} barSize={30} />
                        </RechartsPrimitive.BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
            </CardContent>
        </Card>
    </div>


    </div>
  );
}

