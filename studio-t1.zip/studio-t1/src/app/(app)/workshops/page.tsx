
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalendarDays, UserPlus, Info, Crown, Video, PlayCircle, Star, Download, MessageSquare, Send, Edit } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { Workshop, WorkshopNote, User as AuthUserType } from '@/types'; // Added AuthUserType
import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import { WorkshopLiveInterface } from "@/components/feature/workshop-live-interface";

const mockWorkshopsData: Workshop[] = [
  { id: "ws1", title: "Resume Building Masterclass", date: "2023-09-15T00:00:00Z", time: "2:00 PM - 4:00 PM", description: "Learn how to craft a compelling resume that stands out to employers. Bring your current resume for a peer review session.", facilitator: "Career Services Team", location: "Online via Zoom", maxAttendees: 50, registeredAttendees: 25, isLive: false, videoUrl: "https://www.youtube.com/embed/rokaS3LcPMA", attendees: ["prostudent@scad.edu"], isCompleted: true },
  { id: "ws2", title: "Networking for Creatives", date: "2024-09-22T00:00:00Z", time: "10:00 AM - 11:30 AM", description: "Discover effective networking strategies tailored for students in creative industries. Build connections that matter.", facilitator: "Jane Doe, Industry Expert", location: "Room 301, SCAD Main Building", maxAttendees: 30, registeredAttendees: 30, isLive: true, videoUrl: "mock-live-join-link-ws2", attendees: ["prostudent@scad.edu"], isCompleted: false },
  { id: "ws5", title: "Advanced UX Prototyping", date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), time: "1:00 PM - 3:00 PM", description: "Deep dive into advanced prototyping tools and techniques for UX designers. Pro students only.", facilitator: "Dr. Proto", location: "Online", maxAttendees: 20, registeredAttendees: 5, isLive: true, videoUrl: "mock-live-join-link-ws5", attendees: [], isCompleted: false },
  { 
    id: "ws_register_test_pro", 
    title: "Portfolio Power-Up (Pro Only)", 
    date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
    time: "10:00 AM - 12:00 PM", 
    description: "Exclusive workshop for Pro students to get advanced tips on portfolio presentation and receive direct feedback. Limited spots!", 
    facilitator: "Alumni Pro Designers", 
    location: "Online - Pro Access Link", 
    maxAttendees: 25, 
    registeredAttendees: 10, 
    isLive: true, 
    videoUrl: "mock-live-join-link-ws_register_test_pro", 
    attendees: [], 
    isCompleted: false 
  },
];

const mockWorkshopNotes: WorkshopNote[] = [
    {studentId: "prostudent@scad.edu", workshopId: "ws1", content: "Key take away: Action verbs are crucial for resume impact.", lastUpdated: new Date().toISOString()}
];


function WorkshopView({ workshop, isOpen, onClose, onRegister, isRegistered, user, onWorkshopUpdate }: { workshop: Workshop | null, isOpen: boolean, onClose: () => void, onRegister: (id: string, title: string) => void, isRegistered: boolean, user: AuthUserType | null, onWorkshopUpdate: (updatedWorkshop: Workshop) => void }) {
    const { toast } = useToast();
    const [notes, setNotes] = useState("");
    const [currentRating, setCurrentRating] = useState(workshop?.rating || 0);
    const [feedbackText, setFeedbackText] = useState(workshop?.feedback || "");
    const [showLiveInterface, setShowLiveInterface] = useState(false);

    useEffect(() => {
        if (workshop && user) {
            const existingNote = mockWorkshopNotes.find(n => n.studentId === user.id && n.workshopId === workshop.id);
            setNotes(existingNote?.content || "");
            setCurrentRating(workshop.rating || 0);
            setFeedbackText(workshop.feedback || "");
        }
         // Reset showLiveInterface when workshop changes or dialog closes
        if (!isOpen) {
            setShowLiveInterface(false);
        }
    }, [workshop, user, isOpen]);

    if (!workshop || !user) return null;

    const handleSaveNotes = () => {
        const noteIndex = mockWorkshopNotes.findIndex(n => n.studentId === user.id && n.workshopId === workshop.id);
        if (noteIndex > -1) {
            mockWorkshopNotes[noteIndex] = {...mockWorkshopNotes[noteIndex], content: notes, lastUpdated: new Date().toISOString()};
        } else {
            mockWorkshopNotes.push({studentId: user.id, workshopId: workshop.id, content: notes, lastUpdated: new Date().toISOString()});
        }
        toast({ title: "Notes Saved", description: "Your notes for this workshop have been saved." });
    };

    const handleRateWorkshop = (rating: number) => {
        setCurrentRating(rating);
        const updatedWorkshop = {...workshop, rating: rating};
        onWorkshopUpdate(updatedWorkshop); // Propagate change to parent
        const masterIndex = mockWorkshopsData.findIndex(ws => ws.id === workshop.id);
        if(masterIndex !== -1) mockWorkshopsData[masterIndex].rating = rating;
        toast({title: "Workshop Rated", description: `You rated "${workshop.title}" ${rating} stars.`});
    };
    
    const handleFeedbackSubmit = () => {
        const updatedWorkshop = {...workshop, feedback: feedbackText};
        onWorkshopUpdate(updatedWorkshop); // Propagate change to parent
        const masterIndex = mockWorkshopsData.findIndex(ws => ws.id === workshop.id);
        if(masterIndex !== -1) mockWorkshopsData[masterIndex].feedback = feedbackText;
        toast({title: "Feedback Submitted", description: `Your feedback for "${workshop.title}" has been submitted.`});
    };

    const handleDownloadCertificate = () => {
      const certificateContent = `
        ***********************************************
              CERTIFICATE OF ATTENDANCE
        ***********************************************

        This certificate is proudly presented to:

        ${user.name || 'Valued Attendee'}

        For successful participation and completion of the workshop:

        "${workshop.title}"

        Held on: ${new Date(workshop.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}

        Facilitated by: ${workshop.facilitator || 'SCAD Career Services'}

        SCAD InternLink Program
        Savannah College of Art and Design
        -----------------------------------------------
        Mock Certificate - Generated on ${new Date().toLocaleDateString()}
      `;
      const blob = new Blob([certificateContent.trim()], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Certificate_${workshop.title.replace(/\s+/g, '_')}_${(user.name || 'Attendee').replace(/\s+/g, '_')}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({title: "Certificate Downloaded", description: `Certificate for "${workshop.title}" downloaded as a text file.`});
    };

    const isWorkshopOver = workshop.isCompleted || new Date(workshop.date) < new Date();

    if (showLiveInterface && workshop.isLive && !isWorkshopOver) {
        return <WorkshopLiveInterface workshop={workshop} onLeave={() => setShowLiveInterface(false)} notes={notes} onNotesChange={setNotes} onSaveNotes={handleSaveNotes} user={user} />;
    }

    return (
        <Dialog open={isOpen} onOpenChange={(open) => { if (!open) { onClose(); setShowLiveInterface(false); } }}>
            <DialogContent className="sm:max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="text-2xl text-primary">{workshop.title}</DialogTitle>
                    <DialogDescription>
                        {new Date(workshop.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} at {workshop.time}
                        <br />Facilitator: {workshop.facilitator || 'N/A'} | Location: {workshop.location}
                    </DialogDescription>
                </DialogHeader>
                <ScrollArea className="max-h-[60vh] pr-4">
                    <div className="space-y-4 py-4">
                        <p className="text-muted-foreground">{workshop.description}</p>
                        
                        {workshop.isLive && !isWorkshopOver && (
                            <Button onClick={() => setShowLiveInterface(true)} className="w-full" disabled={!isRegistered}>
                                <Video className="mr-2 h-5 w-5" /> Join Live Session
                            </Button>
                        )}

                        {(isWorkshopOver || !workshop.isLive) && workshop.videoUrl && ( // Show recording if workshop is over OR if it was never live (pre-recorded)
                             <div>
                                <h3 className="font-semibold mb-2 text-lg">Workshop Recording:</h3>
                                <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                                    <iframe 
                                        width="100%" 
                                        height="100%" 
                                        src={workshop.videoUrl.includes("youtube.com/embed") ? workshop.videoUrl : `https://placehold.co/1280x720.png`} 
                                        title={workshop.title} 
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                        allowFullScreen
                                        data-ai-hint="workshop video player"
                                     ></iframe>
                                </div>
                            </div>
                        )}

                        {isRegistered && (
                            <div className="pt-4 border-t">
                                <Label htmlFor="workshop-notes" className="text-lg font-semibold flex items-center"><Edit className="mr-2 h-5 w-5"/> My Notes</Label>
                                <Textarea 
                                    id="workshop-notes" 
                                    value={notes} 
                                    onChange={(e) => setNotes(e.target.value)} 
                                    rows={5} 
                                    placeholder="Take notes here..." 
                                    className="mt-2"
                                />
                                <Button onClick={handleSaveNotes} size="sm" variant="outline" className="mt-2">Save Notes</Button>
                            </div>
                        )}

                        {isWorkshopOver && isRegistered && (
                            <div className="pt-4 border-t space-y-4">
                                <div>
                                    <h3 className="text-lg font-semibold">Rate this Workshop:</h3>
                                    <div className="flex items-center space-x-1 mt-1">
                                        {[1, 2, 3, 4, 5].map(star => (
                                            <Star 
                                                key={star} 
                                                className={`h-6 w-6 cursor-pointer ${currentRating >= star ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground'}`}
                                                onClick={() => handleRateWorkshop(star)}
                                            />
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <Label htmlFor="workshop-feedback" className="text-lg font-semibold">Your Feedback:</Label>
                                    <Textarea id="workshop-feedback" value={feedbackText} onChange={(e) => setFeedbackText(e.target.value)} rows={3} placeholder="Share your thoughts..." className="mt-1"/>
                                    <Button onClick={handleFeedbackSubmit} size="sm" className="mt-2">Submit Feedback</Button>
                                </div>
                                <Button onClick={handleDownloadCertificate} variant="outline" className="w-full">
                                    <Download className="mr-2 h-4 w-4" /> Download Certificate of Attendance
                                </Button>
                            </div>
                        )}

                    </div>
                </ScrollArea>
                <DialogFooter>
                    <Button variant="outline" onClick={() => { onClose(); setShowLiveInterface(false); }}>Close</Button>
                    {!isRegistered && !isWorkshopOver && workshop.maxAttendees && workshop.registeredAttendees !== undefined && workshop.registeredAttendees < workshop.maxAttendees && (
                        <Button onClick={() => onRegister(workshop.id, workshop.title)}>
                            <UserPlus className="mr-2 h-4 w-4" /> Register Now
                        </Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}


export default function WorkshopsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [workshops, setWorkshops] = useState<Workshop[]>(mockWorkshopsData);
  const [selectedWorkshopForView, setSelectedWorkshopForView] = useState<Workshop | null>(null);
  const [isWorkshopViewOpen, setIsWorkshopViewOpen] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
        setWorkshops(prev => prev.map(ws => ({
            ...ws,
            isCompleted: ws.isCompleted || new Date(ws.date) < new Date()
        })));
    }, 60000); 
    return () => clearInterval(interval);
  }, []);

  
  if (user?.role === 'student' && !user.isPro) {
    return (
      <div className="container mx-auto py-12 flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Card className="w-full max-w-lg p-8 shadow-xl text-center bg-card">
          <CardHeader className="p-0 mb-6">
            <Crown className="h-20 w-20 mx-auto text-primary mb-6" />
            <CardTitle className="text-3xl font-bold text-foreground">Pro Feature Locked</CardTitle>
            <CardDescription className="text-xl mt-3 text-muted-foreground">
              Access to <span className="font-semibold text-primary">Workshops</span> is exclusive to SCAD InternLink Pro students.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0 mb-8">
            <p className="text-foreground/90">
              Upgrade your account to unlock this feature and many more, including advanced career tools, personalized feedback, and priority access to workshops and appointments.
            </p>
          </CardContent>
          <Button size="lg" className="w-full text-lg py-3">
            Upgrade to Pro (Mock Action)
          </Button>
        </Card>
      </div>
    );
  }

  if (user?.role !== 'student' && user?.role !== 'scad_office') {
     return <p className="text-center py-10 text-destructive">Access Denied. This page is for students or SCAD Office personnel.</p>;
  }
  
  const handleRegister = (workshopId: string, title: string) => {
    if (!user || (user.role === 'student' && !user.isPro)) {
        toast({ title: "Pro Feature", description: "Workshop registration is a PRO feature.", variant: "destructive"});
        return;
    }
    setWorkshops(prevWorkshops => 
      prevWorkshops.map(ws => 
        ws.id === workshopId 
        ? { ...ws, 
            attendees: [...(ws.attendees || []), user.id], 
            registeredAttendees: (ws.registeredAttendees || 0) + 1 
          } 
        : ws
      )
    );
    // Update master mock data for persistence in demo
    const masterIndex = mockWorkshopsData.findIndex(ws => ws.id === workshopId);
    if (masterIndex !== -1) {
        mockWorkshopsData[masterIndex].attendees = [...(mockWorkshopsData[masterIndex].attendees || []), user.id];
        mockWorkshopsData[masterIndex].registeredAttendees = (mockWorkshopsData[masterIndex].registeredAttendees || 0) + 1;
    }

    toast({
      title: "Successfully Registered!",
      description: `You've registered for "${title}". A confirmation email has been sent (mock).`,
    });
    if (selectedWorkshopForView?.id === workshopId) {
        setSelectedWorkshopForView(prev => prev ? { ...prev, attendees: [...(prev.attendees || []), user.id], registeredAttendees: (prev.registeredAttendees || 0) + 1 } : null);
    }
  };

  const handleOpenWorkshopView = (workshop: Workshop) => {
    setSelectedWorkshopForView(workshop);
    setIsWorkshopViewOpen(true);
  };
  
  const handleCloseWorkshopView = () => {
    setIsWorkshopViewOpen(false);
    // setSelectedWorkshopForView(null); // Keep selected workshop for WorkshopView useEffect to handle reset
  };

  const handleWorkshopUpdate = (updatedWorkshop: Workshop) => {
    setWorkshops(prev => prev.map(ws => ws.id === updatedWorkshop.id ? updatedWorkshop : ws));
    const masterIndex = mockWorkshopsData.findIndex(ws => ws.id === updatedWorkshop.id);
    if (masterIndex !== -1) {
        mockWorkshopsData[masterIndex] = updatedWorkshop;
    }
  };


  const isWorkshopFull = (workshop: Workshop) => {
    return workshop.maxAttendees !== undefined && workshop.registeredAttendees !== undefined && workshop.registeredAttendees >= workshop.maxAttendees;
  }

  const isUserRegistered = (workshop: Workshop) => {
    return user ? workshop.attendees?.includes(user.id) : false;
  }

  const isWorkshopOver = (workshop: Workshop) => workshop.isCompleted || new Date(workshop.date) < new Date();


  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg mb-8">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <CalendarDays className="mr-3 h-8 w-8" /> Available Workshops
          </CardTitle>
          <CardDescription className="text-lg">
            Browse and register for upcoming career development workshops and events.
            {user?.role === 'student' && user.isPro && <Badge className="ml-3 bg-yellow-400 text-yellow-900 hover:bg-yellow-500"><Star className="h-4 w-4 mr-1"/>PRO ACCESS</Badge>}
          </CardDescription>
        </CardHeader>
      </Card>

      {workshops.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {workshops.map((workshop) => {
            const full = isWorkshopFull(workshop);
            const registered = isUserRegistered(workshop);
            const over = isWorkshopOver(workshop);
            const canRegister = user?.role === 'student' && user.isPro && !registered && !full && !over;

            return (
            <Card key={workshop.id} className="flex flex-col justify-between hover:shadow-xl transition-shadow">
              <CardHeader>
                <CardTitle className="text-xl">{workshop.title}</CardTitle>
                <CardDescription>
                  {new Date(workshop.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  <br />
                  {workshop.time}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <p className="text-muted-foreground line-clamp-3">{workshop.description}</p>
                {workshop.facilitator && <p><strong className="font-medium">Facilitator:</strong> {workshop.facilitator}</p>}
                <p><strong className="font-medium">Location:</strong> {workshop.location}</p>
                {workshop.maxAttendees && workshop.registeredAttendees !== undefined && (
                  <div className="text-sm">
                    <strong className="font-medium">Availability:</strong> {workshop.registeredAttendees} / {workshop.maxAttendees} spots filled
                    {full && !registered && <Badge variant="destructive" className="ml-2">Full</Badge>}
                    {registered && <Badge variant="default" className="ml-2">Registered</Badge>}
                  </div>
                )}
                 {over && <Badge variant="secondary" className="mt-2">Completed</Badge>}
                 {workshop.isLive && !over && <Badge variant="outline" className="mt-2 border-green-500 text-green-600">LIVE NOW / SOON</Badge>}
              </CardContent>
              <CardFooter>
                 {workshop.registrationLink && !workshop.isLive && !workshop.videoUrl && !registered ? (
                  <Button asChild className="w-full" variant="outline">
                    <a href={workshop.registrationLink} target="_blank" rel="noopener noreferrer">
                      <Info className="mr-2 h-4 w-4" /> More Info & External Sign Up
                    </a>
                  </Button>
                ) : (
                  (user?.role === 'student' && user.isPro) || user?.role === 'scad_office' ? ( 
                    <Button 
                      className="w-full"
                      onClick={() => {
                          if(canRegister) {
                              handleRegister(workshop.id, workshop.title);
                          } else {
                              handleOpenWorkshopView(workshop);
                          }
                      }}
                      disabled={user?.role === 'student' && user.isPro && full && !registered}
                    >
                      {registered 
                        ? (workshop.isLive && !over ? <Video className="mr-2 h-4 w-4" /> : <PlayCircle className="mr-2 h-4 w-4" />) 
                        : canRegister ? <UserPlus className="mr-2 h-4 w-4" /> : <Info className="mr-2 h-4 w-4" />
                      }
                      {registered 
                        ? (workshop.isLive && !over ? "Join Live Session" : "View Details / Recording")
                        : canRegister ? "Register Now" 
                        : (full ? "Workshop Full" : "View Details")
                      }
                    </Button>
                  ) : user?.role === 'student' && !user.isPro ? (
                     <Button className="w-full" variant="outline" disabled><Crown className="mr-2 h-4 w-4"/> Pro Feature</Button>
                  ) : null
                )}
              </CardFooter>
            </Card>
          )})}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center text-muted-foreground py-12">
            <CalendarDays className="mx-auto h-12 w-12 mb-4 text-gray-400" />
            <p className="text-xl">No workshops available at the moment.</p>
            <p>Please check back later for new opportunities.</p>
          </CardContent>
        </Card>
      )}
      
      <WorkshopView 
        workshop={selectedWorkshopForView} 
        isOpen={isWorkshopViewOpen} 
        onClose={handleCloseWorkshopView} 
        onRegister={handleRegister}
        isRegistered={selectedWorkshopForView ? isUserRegistered(selectedWorkshopForView) : false}
        user={user}
        onWorkshopUpdate={handleWorkshopUpdate}
      />

    </div>
  );
}


    
