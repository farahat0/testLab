
"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, ExternalLink, Building, Clock, DollarSign, Tag, CalendarIcon } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { InternshipApplication, InternshipApplicationStatus, Internship } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import Image from 'next/image';

// In a real app, this mock data might come from a shared service or context.
// For now, directly importing it for simplicity.
const mockInternshipsData: Internship[] = [
  { id: "1", title: "UX Design Intern", companyId: "c1", companyName: "Innovate Corp", companyLogo:"https://picsum.photos/seed/innovate/40/40", duration: "3 Months", type: "Paid", salary: "$25/hr", skillsRequired: ["Figma", "Adobe XD", "User Research"], jobDescription: "Join our dynamic UX team to work on exciting new projects. You will be involved in the entire design process from research to high-fidelity mockups.", industry: "Technology", postedDate: "2024-05-01T10:00:00Z", location: "Remote", applicationsCount: 12, status: "Open" },
  { id: "2", title: "Software Engineer Intern", companyId: "c2", companyName: "Tech Solutions Inc.", companyLogo:"https://picsum.photos/seed/techsolutions/40/40", duration: "6 Months", type: "Paid", salary: "$3000/month", skillsRequired: ["JavaScript", "React", "Node.js", "MongoDB"], jobDescription: "Gain hands-on experience in full-stack development, contributing to our flagship product. Mentorship provided.", industry: "Technology", postedDate: "2024-04-15T14:30:00Z", location: "Savannah, GA", applicationsCount: 25, status: "Open" },
  { id: "3", title: "Marketing Intern", companyId: "c3", companyName: "Creative Agency", companyLogo:"https://picsum.photos/seed/creative/40/40", duration: "Summer", type: "Unpaid", skillsRequired: ["Social Media", "Content Creation", "SEO Basics"], jobDescription: "Support our marketing campaigns, manage social media channels, and assist with content creation. Great learning opportunity.", industry: "Marketing", postedDate: "2024-05-10T09:00:00Z", location: "Remote", applicationsCount: 5, status: "Open" },
  { id: "4", title: "Data Analyst Intern", companyId: "c4", companyName: "FutureAI", companyLogo:"https://picsum.photos/seed/futureai/40/40", duration: "4 Months", type: "Paid", salary: "$28/hr", skillsRequired: ["Python", "SQL", "Tableau", "Statistics"], jobDescription: "Work with large datasets to extract meaningful insights and help drive business decisions. Exposure to machine learning concepts.", industry: "Technology", postedDate: "2024-03-20T11:00:00Z", location: "Atlanta, GA", applicationsCount: 18, status: "Closed" },
  { id: "5", title: "Graphic Design Intern", companyId: "c1", companyName: "Innovate Corp", companyLogo:"https://picsum.photos/seed/innovate2/40/40", duration: "Full-Time (3 Months)", type: "Paid", salary: "$22/hr", skillsRequired: ["Adobe Illustrator", "Photoshop", "Branding"], jobDescription: "Create compelling visual assets for web and print. Collaborate with marketing and product teams.", industry: "Design", postedDate: "2024-05-12T16:00:00Z", location: "Remote", applicationsCount: 9, status: "Open" },
  // Adding jobs that match IDs in INITIAL_MOCK_STUDENT_APPLICATIONS for withdrawal testing and viewing
  { id: "job_std_rejected", title: "Junior Web Developer", companyId: "comp_web_basics", companyName: "Web Basics Co.", companyLogo:"https://picsum.photos/seed/webbasics/40/40", duration: "3 Months", type: "Paid", salary: "$20/hr", skillsRequired: ["HTML", "CSS"], jobDescription: "Basic web development tasks.", industry: "Technology", postedDate: "2024-03-01T00:00:00Z", location: "Remote", applicationsCount: 10, status: "Closed" },
  { id: "job_std_accepted", title: "Content Writing Intern", companyId: "comp_wordsmith", companyName: "Wordsmith Inc.", companyLogo:"https://picsum.photos/seed/wordsmith/40/40", duration: "4 Months", type: "Paid", salary: "$1500/month", skillsRequired: ["Writing", "Editing"], jobDescription: "Create engaging content.", industry: "Media", postedDate: "2024-02-15T00:00:00Z", location: "Remote", applicationsCount: 5, status: "Open" },
  { id: "job_completed_1", title: "Past Animation Intern", companyId: "comp_anim", companyName: "Animated Dreams", companyLogo:"https://picsum.photos/seed/animdreams/40/40", duration: "3 Months", type: "Unpaid", skillsRequired: ["Maya", "Storyboarding"], jobDescription: "Assisted animation team.", industry: "Animation", postedDate: "2023-08-01T00:00:00Z", location: "Burbank, CA", applicationsCount: 30, status: "Closed" },
  { id: "job_pro_pending", title: "AI Ethics Researcher (Pro)", companyId: "comp_ethical_ai", companyName: "Ethical AI Now", companyLogo:"https://picsum.photos/seed/ethicalai/40/40", duration: "6 Months", type: "Paid", salary: "$5000/month stipend", skillsRequired: ["Research", "Ethics", "AI"], jobDescription: "Advanced research into AI ethics.", industry: "Technology", postedDate: "2024-05-01T00:00:00Z", location: "Remote", applicationsCount: 3, status: "Open" },
  { id: "job_pro_rejected", title: "Lead 3D Modeler (Pro)", companyId: "comp_sculptverse", companyName: "SculptVerse", companyLogo:"https://picsum.photos/seed/sculptverse/40/40", duration: "Project-based", type: "Paid", salary: "Competitive", skillsRequired: ["ZBrush", "Blender", "Texturing"], jobDescription: "Lead modeling for AAA game.", industry: "Animation", postedDate: "2024-04-15T00:00:00Z", location: "Austin, TX", applicationsCount: 8, status: "Closed" },
  { id: "job_pro_accepted", title: "Senior Game Designer (Pro)", companyId: "comp_epic_adventures", companyName: "Epic Adventures", companyLogo:"https://picsum.photos/seed/epicadv/40/40", duration: "12 Months", type: "Paid", salary: "$70k/year", skillsRequired: ["Game Design", "Unity", "Prototyping"], jobDescription: "Design core gameplay systems.", industry: "Technology", postedDate: "2024-04-01T00:00:00Z", location: "Seattle, WA", applicationsCount: 12, status: "Open" },
];


export default function MyApplicationsPage() {
  const { user, studentApplications, updateStudentApplicationStatus } = useAuth();
  const { toast } = useToast();
  const [applications, setApplications] = useState<InternshipApplication[]>([]);
  const [viewingInternshipDetails, setViewingInternshipDetails] = useState<Internship | null>(null);

  useEffect(() => {
    if (user && studentApplications) {
      setApplications(studentApplications.filter(app => app.studentId === user.id));
    }
  }, [user, studentApplications]);

  const handleWithdrawApplication = async (applicationId: string) => {
    const success = await updateStudentApplicationStatus(applicationId, 'Withdrawn');
    if (success) {
      toast({
        title: "Application Withdrawn",
        description: "Your application has been successfully withdrawn.",
        variant: "default"
      });
    } else {
      toast({
        title: "Error",
        description: "Could not withdraw application. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleViewJobDetails = (internshipId: string) => {
    const internship = mockInternshipsData.find(i => i.id === internshipId);
    if (internship) {
      setViewingInternshipDetails(internship);
    } else {
      toast({
        title: "Error",
        description: "Could not find internship details.",
        variant: "destructive"
      });
    }
  };

  if (user?.role !== 'student') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for students only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <FileText className="mr-3 h-8 w-8" /> My Internship Applications
          </CardTitle>
          <CardDescription className="text-lg">
            Track the status of your internship applications.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {applications.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Internship Title</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Applied Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applications.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">
                       <button 
                        onClick={() => handleViewJobDetails(app.internshipId)}
                        className="hover:underline cursor-pointer text-primary text-left"
                      >
                        {app.internshipTitle}
                      </button>
                    </TableCell>
                    <TableCell>{app.companyName}</TableCell>
                    <TableCell>{new Date(app.appliedDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          app.status === 'Accepted' || app.status === 'Offered' ? 'default' : 
                          app.status === 'Rejected' || app.status === 'Withdrawn' ? 'destructive' : 
                          'secondary'
                        }
                      >
                        {app.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleViewJobDetails(app.internshipId)}>
                          <ExternalLink className="mr-1.5 h-3.5 w-3.5" /> View Job
                      </Button>
                      {(app.status === 'Pending' || app.status === 'Reviewed' || app.status === 'Interviewing') && (
                         <Button variant="destructive" size="sm" onClick={() => handleWithdrawApplication(app.id)}>
                           Withdraw
                         </Button>
                       )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">You have not applied for any internships yet.</p>
          )}
        </CardContent>
      </Card>

      {viewingInternshipDetails && (
        <Dialog open={!!viewingInternshipDetails} onOpenChange={() => setViewingInternshipDetails(null)}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <div className="flex items-start justify-between mb-2">
                  <div>
                    <DialogTitle className="text-2xl font-bold text-primary">{viewingInternshipDetails.title}</DialogTitle>
                    <DialogDescription className="text-base text-foreground flex items-center">
                        <Building className="h-5 w-5 mr-2 text-muted-foreground" /> {viewingInternshipDetails.companyName}
                    </DialogDescription>
                  </div>
                  {viewingInternshipDetails.companyLogo && 
                        <Image src={viewingInternshipDetails.companyLogo} alt={`${viewingInternshipDetails.companyName} logo`} data-ai-hint="company logo details" width={48} height={48} className="h-12 w-12 rounded-md border"/>
                  }
              </div>
            </DialogHeader>
            <ScrollArea className="max-h-[65vh]">
              <div className="space-y-4 pr-6">
                <p><strong className="font-semibold">Industry:</strong> <Badge variant="outline">{viewingInternshipDetails.industry}</Badge></p>
                <p><strong className="font-semibold">Location:</strong> {viewingInternshipDetails.location}</p>
                <p><strong className="font-semibold">Duration:</strong> {viewingInternshipDetails.duration}</p>
                <p><strong className="font-semibold">Type:</strong> {viewingInternshipDetails.type} {viewingInternshipDetails.type === "Paid" && viewingInternshipDetails.salary && `(${viewingInternshipDetails.salary})`}</p>
                <p><strong className="font-semibold">Status:</strong> <Badge variant={viewingInternshipDetails.status === 'Open' ? 'default' : 'secondary'}>{viewingInternshipDetails.status}</Badge></p>
                
                <div>
                  <strong className="font-semibold">Skills Required:</strong>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {viewingInternshipDetails.skillsRequired.map(skill => <Badge key={skill} variant="secondary">{skill}</Badge>)}
                  </div>
                </div>
                <div>
                  <strong className="font-semibold">Job Description:</strong>
                  <p className="text-muted-foreground whitespace-pre-wrap mt-1">{viewingInternshipDetails.jobDescription}</p>
                </div>
                <p className="text-xs text-muted-foreground pt-2 border-t">Posted on: {new Date(viewingInternshipDetails.postedDate).toLocaleDateString()}</p>
              </div>
            </ScrollArea>
            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button variant="outline">Close</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

    </div>
  );
}
