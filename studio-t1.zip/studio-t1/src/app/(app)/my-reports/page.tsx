
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, PlusCircle, Edit2, Trash2, Download, Save, CheckCircle, XCircle, MessageSquareWarning, Send, Building, ThumbsUp } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { InternshipReport, Major, InternshipReportStatus } from "@/types";
import { coursesByMajor } from "@/types";
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";


const reportSchema = z.object({
  reportTitle: z.string().min(1, "Report title is required"),
  introduction: z.string().min(10, "Introduction must be at least 10 characters"),
  body: z.string().min(50, "Body must be at least 50 characters"),
  relevantCourses: z.array(z.string()).optional(),
  internshipId: z.string().min(1, "Internship selection is required"),
  internshipTitle: z.string().optional(), // Made optional as it will be derived
  companyName: z.string().optional(), // Made optional as it will be derived
});

type ReportFormData = z.infer<typeof reportSchema>;

const companyEvaluationSchema = z.object({
  companyEvaluation: z.string().min(10, "Evaluation must be at least 10 characters").optional().or(z.literal('')),
  recommendCompany: z.boolean().optional(),
});
type CompanyEvaluationFormData = z.infer<typeof companyEvaluationSchema>;

const appealSchema = z.object({
  appealMessage: z.string().min(20, "Appeal message must be at least 20 characters explaining your reasoning."),
});
type AppealFormData = z.infer<typeof appealSchema>;


const mockStudentReports: InternshipReport[] = [
    { id: "report1", studentId: "student@scad.edu", studentName: "Alex Bee", internshipId: "1", internshipTitle: "UX Design Intern", companyName: "Innovate Corp", submissionDate: "2023-08-15T00:00:00Z", reportTitle: "My UX Internship at Innovate", introduction: "This report details my experiences...", body: "During my internship, I focused on...", companyEvaluation: "Great learning environment.", recommendCompany: true, relevantCourses: ["UXDS 200: Foundations of UX", "UXDS 310: Interaction Design"], status: "Approved", facultyAdvisorName: "Prof. Ada Lovelace" },
    { id: "report2", studentId: "prostudent@scad.edu", studentName: "Casey Dell", internshipId: "5", internshipTitle: "Junior Game Dev Intern", companyName: "PixelPlay Studios", submissionDate: "2023-07-20T00:00:00Z", reportTitle: "Game Dev Journey at PixelPlay", introduction: "An overview of my contributions...", body: "I worked on character rigging and...", companyEvaluation: "Fast-paced but rewarding.", recommendCompany: true, relevantCourses: ["ANIM 350: 3D Modeling"], status: "Pending Review", facultyAdvisorName: "Prof. Alan Turing" },
    { id: "report3", studentId: "student@scad.edu", studentName: "Alex Bee", internshipId: "compInternship1", internshipTitle: "Web Dev Intern", companyName: "Web Wizards", submissionDate: "2024-01-10T00:00:00Z", reportTitle: "Web Wizards Internship Report", introduction: "My role as a web dev intern...", body: "Developed several frontend components...", status: "Needs Revision", facultyAdvisorName: "Prof. Charles Babbage", facultyComments: "The introduction needs to be more specific about your role and responsibilities. Please also elaborate on the challenges faced in the 'Body' section."},
    { id: "report4", studentId: "prostudent@scad.edu", studentName: "Casey Dell", internshipId: "proInternship2", internshipTitle: "3D Artist Intern", companyName: "RenderFarm Inc.", submissionDate: "2024-02-15T00:00:00Z", reportTitle: "3D Artistry at RenderFarm", introduction: "This report covers my 3D modeling internship.", body: "Contributed to asset creation for a major project.", status: "Rejected", facultyAdvisorName: "Prof. Alan Turing", facultyComments: "The report does not meet the minimum length requirements and lacks substantive reflection on learning outcomes. Please refer to the guidelines and resubmit a more detailed report if you wish for it to be considered."},
];

const mockStudentCompletedInternships = [
    { id: "1", title: "UX Design Intern", companyName: "Innovate Corp" },
    { id: "compInternship1", title: "Web Dev Intern", companyName: "Web Wizards" },
    { id: "gameInternshipPro", title: "Junior Game Dev Intern", companyName: "PixelPlay Studios" },
    { id: "proInternship2", title: "3D Artist Intern", companyName: "RenderFarm Inc." }
];


export default function MyReportsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reports, setReports] = useState<InternshipReport[]>([]);
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [isCompanyEvalDialogOpen, setIsCompanyEvalDialogOpen] = useState(false);
  const [isAppealDialogOpen, setIsAppealDialogOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<InternshipReport | null>(null);
  const [evaluatingReport, setEvaluatingReport] = useState<InternshipReport | null>(null);
  const [appealingReport, setAppealingReport] = useState<InternshipReport | null>(null);
  
  const reportForm = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      reportTitle: "", introduction: "", body: "", 
      relevantCourses: [], internshipId: "",
      internshipTitle: "", companyName: "",
    },
  });

  const companyEvalForm = useForm<CompanyEvaluationFormData>({
    resolver: zodResolver(companyEvaluationSchema),
    defaultValues: {
      companyEvaluation: "",
      recommendCompany: false,
    },
  });

  const appealForm = useForm<AppealFormData>({
    resolver: zodResolver(appealSchema),
    defaultValues: { appealMessage: "" },
  });

  useEffect(() => {
    if (user?.role === 'student') {
        setReports(mockStudentReports.filter(report => report.studentId === user.id));
    }
  }, [user]);

  const studentMajorCourses = user?.major && coursesByMajor[user.major as Major] ? coursesByMajor[user.major as Major] : [];
  const availableInternshipsForReport = user?.role === 'student' 
    ? mockStudentCompletedInternships.filter(internship => {
        // Optionally, filter to show only internships not yet reported or allow multiple reports for same internship
        return true; 
      })
    : [];

  const handleReportFormSubmit = (data: ReportFormData) => {
    if (!user) return;
    const selectedInternshipDetails = availableInternshipsForReport.find(i => i.id === data.internshipId);
    if (!selectedInternshipDetails) {
        toast({ title: "Error", description: "Selected internship not found.", variant: "destructive" });
        return;
    }
    
    const reportCoreData: Omit<InternshipReport, 'id' | 'submissionDate' | 'status' | 'studentId' | 'studentName' | 'facultyComments' | 'appealMessage' | 'companyEvaluation' | 'recommendCompany'> = {
      reportTitle: data.reportTitle,
      introduction: data.introduction,
      body: data.body,
      relevantCourses: data.relevantCourses || [],
      internshipId: data.internshipId,
      internshipTitle: selectedInternshipDetails.title,
      companyName: selectedInternshipDetails.companyName,
      facultyAdvisorName: user.role === 'student' ? 'Pending Advisor Assignment' : undefined, // Mock advisor assignment
    };

    if (editingReport) {
      const updatedReport = { ...editingReport, ...reportCoreData };
      setReports(reports.map(r => r.id === editingReport.id ? updatedReport : r));
      // Also update in the mock master list if it exists
      const masterIndex = mockStudentReports.findIndex(r => r.id === editingReport.id);
      if (masterIndex !== -1) mockStudentReports[masterIndex] = {...mockStudentReports[masterIndex], ...reportCoreData};
      toast({ title: "Report Updated", description: `Report "${data.reportTitle}" saved.` });
    } else {
      const newReport: InternshipReport = {
        ...reportCoreData,
        id: `report-${Date.now()}`,
        studentId: user.id,
        studentName: user.name || 'Student',
        submissionDate: new Date().toISOString(),
        status: "Draft", // Initial status for new reports
        companyEvaluation: "", // Initialize empty evaluation fields
        recommendCompany: false,
      };
      setReports(prevReports => [newReport, ...prevReports]);
      mockStudentReports.unshift(newReport); // Add to the master mock list for persistence in session
      toast({ title: "Report Created", description: `Report "${data.reportTitle}" created as Draft.` });
    }
    setIsReportDialogOpen(false);
    reportForm.reset({
      reportTitle: "", introduction: "", body: "", 
      relevantCourses: [], internshipId: "",
      internshipTitle: "", companyName: "",
    });
    setEditingReport(null);
  };

  const handleCompanyEvalFormSubmit = (data: CompanyEvaluationFormData) => {
    if (!evaluatingReport) return;
    
    const updatedReport: InternshipReport = {
      ...evaluatingReport,
      companyEvaluation: data.companyEvaluation || "",
      recommendCompany: data.recommendCompany || false,
    };
    
    setReports(reports.map(r => r.id === evaluatingReport.id ? updatedReport : r));
    const masterIndex = mockStudentReports.findIndex(r => r.id === evaluatingReport.id);
    if (masterIndex !== -1) mockStudentReports[masterIndex] = updatedReport;
    
    toast({ title: "Company Evaluation Updated", description: `Evaluation for "${updatedReport.reportTitle}" saved.` });
    setIsCompanyEvalDialogOpen(false);
    setEvaluatingReport(null);
    companyEvalForm.reset({ companyEvaluation: "", recommendCompany: false });
  };


  const openCreateReportDialog = () => {
    reportForm.reset({
        reportTitle: "", introduction: "", body: "", 
        relevantCourses: [], internshipId: "",
        internshipTitle: "", companyName: "",
    });
    setEditingReport(null);
    setIsReportDialogOpen(true);
  };

  const openEditReportDialog = (report: InternshipReport) => {
    setEditingReport(report);
    reportForm.reset({
      reportTitle: report.reportTitle,
      introduction: report.introduction,
      body: report.body,
      relevantCourses: report.relevantCourses || [],
      internshipId: report.internshipId,
      internshipTitle: report.internshipTitle,
      companyName: report.companyName,
    });
    setIsReportDialogOpen(true);
  };

  const openCompanyEvalDialog = (report: InternshipReport) => {
    setEvaluatingReport(report);
    companyEvalForm.reset({
      companyEvaluation: report.companyEvaluation || "",
      recommendCompany: report.recommendCompany || false,
    });
    setIsCompanyEvalDialogOpen(true);
  };


  const handleDeleteReport = (reportId: string) => {
    if (window.confirm("Are you sure you want to delete this report? This action cannot be undone.")) {
      setReports(reports.filter(r => r.id !== reportId));
      const reportIndex = mockStudentReports.findIndex(r => r.id === reportId);
      if (reportIndex > -1) mockStudentReports.splice(reportIndex, 1);
      toast({ title: "Report Deleted", variant: "destructive" });
    }
  };
  
  const handleDownloadReport = (report: InternshipReport) => {
    const reportContent = `
      Report Title: ${report.reportTitle}
      Student: ${report.studentName} (${report.studentId})
      Internship: ${report.internshipTitle} at ${report.companyName}
      Submission Date: ${new Date(report.submissionDate).toLocaleDateString()}
      Status: ${report.status}
      Advisor: ${report.facultyAdvisorName || 'N/A'}

      Introduction:
      ${report.introduction}

      Body:
      ${report.body}

      Company Evaluation:
      ${report.companyEvaluation || 'N/A'}
      Recommend Company: ${report.recommendCompany ? 'Yes' : 'No'}

      Relevant Courses:
      ${report.relevantCourses?.join(", ") || 'N/A'}

      Faculty Comments:
      ${report.facultyComments || 'N/A'}

      Student Appeal Message:
      ${report.appealMessage || 'N/A'}
    `;
    const blob = new Blob([reportContent.trim()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.studentName}_${report.internshipTitle.replace(/\s+/g, '_')}_Report.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Report Downloaded", description: "The report content has been downloaded as a text file." });
  };

  const openAppealDialog = (report: InternshipReport) => {
    setAppealingReport(report);
    appealForm.reset({ appealMessage: report.appealMessage || "" });
    setIsAppealDialogOpen(true);
  };

  const handleAppealFormSubmit = (data: AppealFormData) => {
    if (!appealingReport) return;
    
    const updatedReport: InternshipReport = {
      ...appealingReport,
      status: "Appealed",
      appealMessage: data.appealMessage,
    };
    
    setReports(reports.map(r => r.id === appealingReport.id ? updatedReport : r));
    const masterIndex = mockStudentReports.findIndex(r => r.id === appealingReport.id);
    if (masterIndex !== -1) mockStudentReports[masterIndex] = updatedReport;
    
    toast({ title: "Appeal Submitted", description: "Your appeal for the report has been submitted." });
    setIsAppealDialogOpen(false);
    setAppealingReport(null);
    appealForm.reset({ appealMessage: "" });
  };
  
  if (user?.role !== 'student') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for students only.</p>;
  }

  const getStatusVariant = (status: InternshipReportStatus) => {
    switch(status) {
      case "Approved": return "default";
      case "Needs Revision": return "destructive";
      case "Rejected": return "destructive";
      case "Draft": return "outline";
      case "Appealed": return "secondary"; 
      case "Pending Review": return "secondary";
      default: return "secondary";
    }
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-3xl font-bold text-primary flex items-center">
              <BookOpen className="mr-3 h-8 w-8" /> My Internship Reports
            </CardTitle>
            <CardDescription className="text-lg">
              Submit, view, and manage your internship reports and company evaluations.
            </CardDescription>
          </div>
          <Button onClick={openCreateReportDialog}>
            <PlusCircle className="mr-2 h-5 w-5" /> Submit New Report
          </Button>
        </CardHeader>
        <CardContent>
           {reports.length > 0 ? (
            <div className="space-y-4">
              {reports.map((report) => (
                <Card key={report.id} className="overflow-hidden">
                  <CardHeader className="flex flex-row items-start justify-between space-x-4 p-4 bg-muted/30">
                    <div>
                      <CardTitle className="text-xl">{report.reportTitle}</CardTitle>
                      <CardDescription>
                        For: {report.internshipTitle} at {report.companyName} <br/>
                        Submitted: {new Date(report.submissionDate).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <Badge variant={getStatusVariant(report.status)} className="whitespace-nowrap mt-1">
                       {report.status}
                   </Badge>
                  </CardHeader>
                  <CardContent className="p-4 space-y-3">
                    {(report.status === "Needs Revision" || report.status === "Rejected") && report.facultyComments && (
                      <Alert variant="destructive">
                        <MessageSquareWarning className="h-4 w-4" />
                        <AlertTitle>Faculty Comments</AlertTitle>
                        <AlertDescription>{report.facultyComments}</AlertDescription>
                      </Alert>
                    )}
                     {report.status === "Appealed" && report.appealMessage && (
                      <Alert variant="default" className="bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700">
                         <Send className="h-4 w-4 text-blue-600" />
                        <AlertTitle className="text-blue-700 dark:text-blue-300">Your Appeal</AlertTitle>
                        <AlertDescription className="text-blue-600 dark:text-blue-400">{report.appealMessage}</AlertDescription>
                      </Alert>
                    )}
                    <p className="text-sm line-clamp-2"><strong className="font-medium">Introduction:</strong> {report.introduction}</p>
                    
                    <div className="pt-2 border-t">
                        <h4 className="text-md font-semibold mt-2 mb-1 text-foreground/80">Company Evaluation</h4>
                        {report.companyEvaluation ? (
                            <>
                                <p className="text-sm text-muted-foreground line-clamp-2">{report.companyEvaluation}</p>
                                <p className="text-xs mt-1">
                                    <strong className="font-medium">Recommend Company:</strong> {report.recommendCompany ? "Yes" : "No"}
                                </p>
                            </>
                        ) : (
                            <p className="text-sm text-muted-foreground">No company evaluation submitted yet.</p>
                        )}
                         <Button variant="outline" size="sm" className="mt-2" onClick={() => openCompanyEvalDialog(report)}>
                            <Building className="mr-1.5 h-3.5 w-3.5"/> {report.companyEvaluation ? "Edit Evaluation" : "Add Evaluation"}
                        </Button>
                    </div>
                  </CardContent>


                  <CardFooter className="p-4 bg-muted/30 flex justify-end space-x-2">
                    <Button variant="outline" size="sm" onClick={() => openEditReportDialog(report)}>
                      <Edit2 className="mr-1.5 h-3.5 w-3.5"/> {report.status === "Draft" ? "Edit Report Draft" : "View/Edit Report"}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDownloadReport(report)} title="Download Report">
                      <Download className="h-4 w-4" />
                    </Button>
                    {(report.status === "Needs Revision" || report.status === "Rejected") && report.status !== "Appealed" && (
                      <Button variant="outline" size="sm" className="border-yellow-500 text-yellow-600 hover:bg-yellow-50 hover:text-yellow-700" onClick={() => openAppealDialog(report)}>
                        <MessageSquareWarning className="mr-1.5 h-3.5 w-3.5"/> Appeal Decision
                      </Button>
                    )}
                    {report.status === "Draft" && (
                      <Button variant="destructive" size="icon" onClick={() => handleDeleteReport(report.id)} title="Delete Draft">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-10">You have not submitted any reports yet. Click "Submit New Report" to start.</p>
          )}
        </CardContent>
      </Card>

      <Dialog open={isReportDialogOpen} onOpenChange={(isOpen) => {
          setIsReportDialogOpen(isOpen);
          if (!isOpen) {
              setEditingReport(null);
              reportForm.reset({
                reportTitle: "", introduction: "", body: "", 
                relevantCourses: [], internshipId: "",
                internshipTitle: "", companyName: "",
              });
          }
      }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{editingReport ? 'Edit Internship Report' : 'Create New Internship Report'}</DialogTitle>
            <DialogDescription>
              {editingReport ? 'Update the core details of your internship report. Company evaluation is handled separately.' : 'Fill in the core details for your internship report. You can add company evaluation later.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={reportForm.handleSubmit(handleReportFormSubmit)}>
            <ScrollArea className="max-h-[70vh] p-1 pr-3">
              <div className="space-y-4 py-4">
                <div>
                  <Label htmlFor="internshipId">Internship*</Label>
                   <Controller
                    name="internshipId"
                    control={reportForm.control}
                    render={({ field }) => (
                        <select {...field} id="internshipId" className="w-full mt-1 p-2 border rounded-md bg-background text-sm">
                            <option value="">Select an Internship</option>
                            {availableInternshipsForReport.map(internship => (
                                <option key={internship.id} value={internship.id}>
                                    {internship.title} at {internship.companyName}
                                </option>
                            ))}
                        </select>
                    )}
                    />
                  {reportForm.formState.errors.internshipId && <p className="text-sm text-destructive mt-1">{reportForm.formState.errors.internshipId.message}</p>}
                </div>

                <div>
                  <Label htmlFor="reportTitle">Report Title*</Label>
                  <Input id="reportTitle" {...reportForm.register("reportTitle")} />
                  {reportForm.formState.errors.reportTitle && <p className="text-sm text-destructive mt-1">{reportForm.formState.errors.reportTitle.message}</p>}
                </div>
                <div>
                  <Label htmlFor="introduction">Introduction*</Label>
                  <Textarea id="introduction" {...reportForm.register("introduction")} rows={3} />
                  {reportForm.formState.errors.introduction && <p className="text-sm text-destructive mt-1">{reportForm.formState.errors.introduction.message}</p>}
                </div>
                <div>
                  <Label htmlFor="body">Body*</Label>
                  <Textarea id="body" {...reportForm.register("body")} rows={8} />
                  {reportForm.formState.errors.body && <p className="text-sm text-destructive mt-1">{reportForm.formState.errors.body.message}</p>}
                </div>
                
                <Card className="mt-4">
                    <CardHeader><CardTitle className="text-lg">Relevant SCAD Courses (Optional)</CardTitle></CardHeader>
                    <CardContent>
                        <Label>Select courses that were particularly helpful for this internship:</Label>
                        <ScrollArea className="h-40 mt-2 border rounded-md p-2">
                           {studentMajorCourses.length > 0 ? studentMajorCourses.map(course => (
                               <div key={course} className="flex items-center space-x-2 my-1">
                                   <Controller
                                        name="relevantCourses"
                                        control={reportForm.control}
                                        render={({ field }) => (
                                            <Checkbox
                                                id={`course-${course.replace(/\s+/g, '-')}`}
                                                checked={field.value?.includes(course)}
                                                onCheckedChange={(checked) => {
                                                    return checked
                                                        ? field.onChange([...(field.value || []), course])
                                                        : field.onChange((field.value || []).filter(value => value !== course));
                                                }}
                                            />
                                        )}
                                    />
                                   <Label htmlFor={`course-${course.replace(/\s+/g, '-')}`} className="font-normal">{course}</Label>
                               </div>
                           )) : <p className="text-sm text-muted-foreground">No courses found for your major, or major not set in profile.</p>}
                        </ScrollArea>
                    </CardContent>
                </Card>

              </div>
            </ScrollArea>
            <DialogFooter className="pt-6">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={reportForm.formState.isSubmitting}>
                <Save className="mr-2 h-4 w-4" /> {editingReport ? 'Save Report Changes' : 'Save Report Draft'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Company Evaluation Dialog */}
      <Dialog open={isCompanyEvalDialogOpen} onOpenChange={(isOpen) => {
          setIsCompanyEvalDialogOpen(isOpen);
          if (!isOpen) {
              setEvaluatingReport(null);
              companyEvalForm.reset({ companyEvaluation: "", recommendCompany: false });
          }
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl text-primary flex items-center"><Building className="mr-2 h-6 w-6"/>Company Evaluation</DialogTitle>
            <DialogDescription>
              Provide your feedback on "{evaluatingReport?.companyName}" for the internship: "{evaluatingReport?.internshipTitle}".
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={companyEvalForm.handleSubmit(handleCompanyEvalFormSubmit)}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="companyEvaluation">Your Evaluation of the Company</Label>
                <Textarea 
                    id="companyEvaluation" 
                    {...companyEvalForm.register("companyEvaluation")} 
                    rows={5} 
                    placeholder="Share your thoughts about the company culture, mentorship, projects, learning opportunities, etc." 
                />
                {companyEvalForm.formState.errors.companyEvaluation && <p className="text-sm text-destructive mt-1">{companyEvalForm.formState.errors.companyEvaluation.message}</p>}
              </div>
              <div className="flex items-center space-x-2">
                <Controller
                  name="recommendCompany"
                  control={companyEvalForm.control}
                  render={({ field }) => (
                    <Checkbox id="recommendCompanyEval" checked={!!field.value} onCheckedChange={field.onChange} />
                  )}
                />
                <Label htmlFor="recommendCompanyEval" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  I would recommend this company to other SCAD students.
                </Label>
              </div>
            </div>
            <DialogFooter className="pt-6">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={companyEvalForm.formState.isSubmitting}>
                <ThumbsUp className="mr-2 h-4 w-4" /> Save Evaluation
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>


      <Dialog open={isAppealDialogOpen} onOpenChange={(isOpen) => {
          setIsAppealDialogOpen(isOpen);
          if (!isOpen) {
              setAppealingReport(null);
              appealForm.reset({ appealMessage: "" });
          }
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl text-primary">Appeal Report Decision</DialogTitle>
            <DialogDescription>
              Report: "{appealingReport?.reportTitle || 'N/A'}" <br/>
              Current Status: <Badge variant={getStatusVariant(appealingReport?.status || 'Draft')} className="ml-1">{appealingReport?.status}</Badge>
              <br/>
              Please provide your reasons for appealing this decision.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={appealForm.handleSubmit(handleAppealFormSubmit)}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="appealMessage">Your Appeal Message*</Label>
                <Textarea 
                  id="appealMessage" 
                  {...appealForm.register("appealMessage")} 
                  rows={6} 
                  placeholder="Clearly state your reasons for appeal. Refer to specific parts of your report or faculty comments if applicable."
                />
                {appealForm.formState.errors.appealMessage && <p className="text-sm text-destructive mt-1">{appealForm.formState.errors.appealMessage.message}</p>}
              </div>
            </div>
            <DialogFooter className="pt-6">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={appealForm.formState.isSubmitting}>
                <Send className="mr-2 h-4 w-4" /> Submit Appeal
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
}


    
