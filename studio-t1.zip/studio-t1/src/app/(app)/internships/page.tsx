
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Search, Filter, Briefcase, Clock, DollarSign, Tag, Building, ExternalLink, CheckCircle, Sparkles, Users, ThumbsUp, UploadCloud, File as FileIcon, CalendarIcon, Crown } from "lucide-react";
import type { Internship, Industry } from "@/types";
import { Industries } from "@/types";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { useAuth } from '@/hooks/use-auth';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const mockInternshipsData: Internship[] = [
  { id: "1", title: "UX Design Intern", companyId: "c1", companyName: "Innovate Corp", companyLogo:"https://picsum.photos/seed/innovate/40/40", duration: "3 Months", type: "Paid", salary: "$25/hr", skillsRequired: ["Figma", "Adobe XD", "User Research"], jobDescription: "Join our dynamic UX team to work on exciting new projects. You will be involved in the entire design process from research to high-fidelity mockups.", industry: "Technology", postedDate: "2024-05-01T10:00:00Z", location: "Remote", applicationsCount: 12, status: "Open" },
  { id: "2", title: "Software Engineer Intern", companyId: "c2", companyName: "Tech Solutions Inc.", companyLogo:"https://picsum.photos/seed/techsolutions/40/40", duration: "6 Months", type: "Paid", salary: "$3000/month", skillsRequired: ["JavaScript", "React", "Node.js", "MongoDB"], jobDescription: "Gain hands-on experience in full-stack development, contributing to our flagship product. Mentorship provided.", industry: "Technology", postedDate: "2024-04-15T14:30:00Z", location: "Savannah, GA", applicationsCount: 25, status: "Open" },
  { id: "3", title: "Marketing Intern", companyId: "c3", companyName: "Creative Agency", companyLogo:"https://picsum.photos/seed/creative/40/40", duration: "Summer", type: "Unpaid", skillsRequired: ["Social Media", "Content Creation", "SEO Basics"], jobDescription: "Support our marketing campaigns, manage social media channels, and assist with content creation. Great learning opportunity.", industry: "Marketing", postedDate: "2024-05-10T09:00:00Z", location: "Remote", applicationsCount: 5, status: "Open" },
  { id: "4", title: "Data Analyst Intern", companyId: "c4", companyName: "FutureAI", companyLogo:"https://picsum.photos/seed/futureai/40/40", duration: "4 Months", type: "Paid", salary: "$28/hr", skillsRequired: ["Python", "SQL", "Tableau", "Statistics"], jobDescription: "Work with large datasets to extract meaningful insights and help drive business decisions. Exposure to machine learning concepts.", industry: "Technology", postedDate: "2024-03-20T11:00:00Z", location: "Atlanta, GA", applicationsCount: 18, status: "Closed" },
  { id: "5", title: "Graphic Design Intern", companyId: "c1", companyName: "Innovate Corp", companyLogo:"https://picsum.photos/seed/innovate2/40/40", duration: "Full-Time (3 Months)", type: "Paid", salary: "$22/hr", skillsRequired: ["Adobe Illustrator", "Photoshop", "Branding"], jobDescription: "Create compelling visual assets for web and print. Collaborate with marketing and product teams.", industry: "Design", postedDate: "2024-05-12T16:00:00Z", location: "Remote", applicationsCount: 9, status: "Open" },
];

const mockPastInternRecommendations = [
  { name: "Innovate Corp", reason: "Excellent mentorship program for UX designers.", logo: "https://picsum.photos/seed/innovate/32/32" },
  { name: "PixelPlay Studios", reason: "Hands-on game development experience from day one.", logo: "https://picsum.photos/seed/pixelplay/32/32" },
  { name: "FutureAI", reason: "Cutting-edge projects in data science and AI.", logo: "https://picsum.photos/seed/futureai/32/32" },
  { name: "Tech Solutions Inc.", reason: "Great for full-stack learning.", logo: "https://picsum.photos/seed/techsolutions/32/32" },
];

const uniqueDurations = ["all", ...new Set(mockInternshipsData.map(i => i.duration))];


export default function InternshipsPage() {
  const { user, addStudentApplication } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState<Industry | "all">("all");
  const [selectedType, setSelectedType] = useState<"all" | "Paid" | "Unpaid">("all");
  const [selectedDuration, setSelectedDuration] = useState<string>("all");
  const [selectedInternship, setSelectedInternship] = useState<Internship | null>(null);
  const [suggestedCompanies, setSuggestedCompanies] = useState<string[]>([]);
  const [isMoreFiltersOpen, setIsMoreFiltersOpen] = useState(false);
  const { toast } = useToast();

  const [coverLetter, setCoverLetter] = useState<File | null>(null);
  const [cv, setCv] = useState<File | null>(null);
  const [otherDocument, setOtherDocument] = useState<File | null>(null);

  const [filterJobStatus, setFilterJobStatus] = useState<'all' | 'Open' | 'Closed'>("all");
  const [sortDate, setSortDate] = useState<'newest' | 'oldest' | 'none'>('newest');


  const filteredInternships = mockInternshipsData.filter(internship => {
    return (
      (internship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
       internship.companyName.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (selectedIndustry === "all" || internship.industry === selectedIndustry) &&
      (selectedType === "all" || internship.type === selectedType) &&
      (selectedDuration === "all" || internship.duration === selectedDuration) &&
      (filterJobStatus === "all" || internship.status === filterJobStatus)
    );
  }).sort((a, b) => {
    if (sortDate === 'newest') {
      return new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime();
    }
    if (sortDate === 'oldest') {
      return new Date(a.postedDate).getTime() - new Date(b.postedDate).getTime();
    }
    return 0;
  });

  useEffect(() => {
    if (user?.role === 'student') {
      const studentInterests = user.jobInterests?.toLowerCase().split(',').map(s => s.trim()).filter(s => s) || [];
      const studentMajor = user.major?.toLowerCase();

      const relevantCompanyNames = mockInternshipsData.filter(internship => {
        const titleLc = internship.title.toLowerCase();
        const descriptionLc = internship.jobDescription.toLowerCase();
        const industryLc = internship.industry.toLowerCase();
        const skillsLc = internship.skillsRequired.map(s => s.toLowerCase());

        let interestMatch = false;
        if (studentInterests.length > 0) {
          interestMatch = studentInterests.some(interest =>
            titleLc.includes(interest) ||
            descriptionLc.includes(interest) ||
            skillsLc.some(skill => skill.includes(interest)) ||
            industryLc.includes(interest)
          );
        }

        let majorMatch = false;
        if (studentMajor) {
          majorMatch = titleLc.includes(studentMajor) ||
                       descriptionLc.includes(studentMajor) ||
                       industryLc.includes(studentMajor) ||
                       skillsLc.some(skill => skill.includes(studentMajor));
        }
        
        return interestMatch || majorMatch;
      }).map(internship => internship.companyName);

      const uniqueCompanies = [...new Set(relevantCompanyNames)];
      setSuggestedCompanies(uniqueCompanies);
    } else {
      setSuggestedCompanies([]);
    }
  }, [user]);

  const handleApply = async (internship: Internship) => {
    if (!user || user.role !== 'student') {
      toast({
        title: "Login Required",
        description: "Please log in as a student to apply for internships.",
        variant: "destructive"
      });
      return;
    }

    const applicationData = {
      internshipId: internship.id,
      internshipTitle: internship.title,
      companyName: internship.companyName,
      companyId: internship.companyId,
    };
    
    const filesToUpload: File[] = [];
    if (cv) filesToUpload.push(cv);
    if (coverLetter) filesToUpload.push(coverLetter);
    if (otherDocument) filesToUpload.push(otherDocument);

    const success = await addStudentApplication(applicationData, filesToUpload);

    if (success) {
      toast({
        title: "Application Submitted!",
        description: `Your application for "${internship.title}" has been submitted.`,
        variant: "default"
      });
    } else {
       toast({
        title: "Application Failed",
        description: `Could not submit application for "${internship.title}". Please try again.`,
        variant: "destructive"
      });
    }
    setSelectedInternship(null);
    setCv(null);
    setCoverLetter(null);
    setOtherDocument(null);
  };
  
  const handleFileChange = (setter: React.Dispatch<React.SetStateAction<File | null>>) => (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setter(e.target.files[0]);
    } else {
      setter(null);
    }
  };


  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg border-primary/10">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <Briefcase className="mr-3 h-8 w-8" /> Available Internships
          </CardTitle>
          <CardDescription className="text-lg">
            Explore exciting internship opportunities. Use the filters to find your perfect match.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 p-4 border rounded-lg bg-secondary/30">
            <div className="relative lg:col-span-4">
              <Label htmlFor="search" className="sr-only">Search</Label>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                id="search"
                placeholder="Search by job title, company..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)} 
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="industry-filter">Industry</Label>
              <Select value={selectedIndustry} onValueChange={(value) => setSelectedIndustry(value as Industry | "all")}>
                <SelectTrigger id="industry-filter"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  {Industries.map(ind => <SelectItem key={ind} value={ind}>{ind}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="type-filter">Payment Type</Label>
              <Select value={selectedType} onValueChange={(value) => setSelectedType(value as "all" | "Paid" | "Unpaid")}>
                <SelectTrigger id="type-filter"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                  <SelectItem value="Unpaid">Unpaid</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <div className="space-y-1">
              <Label htmlFor="duration-filter">Duration</Label>
              <Select value={selectedDuration} onValueChange={setSelectedDuration}>
                <SelectTrigger id="duration-filter"><SelectValue placeholder="Filter by Duration" /></SelectTrigger>
                <SelectContent>
                  {uniqueDurations.map(dur => (
                    <SelectItem key={dur} value={dur}>{dur === "all" ? "All Durations" : dur}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
             <div className="space-y-1">
              <Label htmlFor="status-filter">Job Status</Label>
              <Select value={filterJobStatus} onValueChange={(value) => setFilterJobStatus(value as 'all' | 'Open' | 'Closed')}>
                <SelectTrigger id="status-filter"><SelectValue placeholder="Filter by Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Open">Open (Current)</SelectItem>
                  <SelectItem value="Closed">Closed (Completed)</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <div className="space-y-1 lg:col-start-2">
              <Label htmlFor="sort-date-filter">Sort by Date</Label>
              <Select value={sortDate} onValueChange={(value) => setSortDate(value as 'newest' | 'oldest' | 'none')}>
                <SelectTrigger id="sort-date-filter"><SelectValue placeholder="Sort by Date" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="none">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="lg:col-span-4 text-center mt-2">
                 <Button onClick={() => setIsMoreFiltersOpen(true)} variant="outline">
                    <Filter className="mr-2 h-4 w-4" /> More Insights & Filters
                </Button>
            </div>
          </div>

          {user?.role === 'student' && suggestedCompanies.length > 0 && (
            <Card className="mb-6 p-4 bg-primary/5 border-primary/20">
              <CardHeader className="p-0 pb-2">
                <CardTitle className="text-xl font-semibold text-primary flex items-center">
                    <Sparkles className="mr-2 h-5 w-5 text-primary" /> Companies Matching Your Profile
                    {user.isPro && <Badge className="ml-2 bg-yellow-400 text-yellow-900 hover:bg-yellow-500"><Crown className="h-3 w-3 mr-1"/>PRO</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <p className="text-sm text-muted-foreground mb-2">
                  Based on your interests (e.g., "{user.jobInterests?.split(',')[0] || 'general'}") and major ("{user.major || 'any major'}"), you might be interested in:
                </p>
                <div className="flex flex-wrap gap-2">
                    {(user.isPro ? suggestedCompanies : suggestedCompanies.slice(0, 5)).map(companyName => (
                        <Badge key={companyName} variant="secondary" className="text-base px-3 py-1">{companyName}</Badge>
                    ))}
                     {!user.isPro && suggestedCompanies.length > 5 && (
                        <Button variant="link" size="sm" onClick={() => setIsMoreFiltersOpen(true)} className="p-1 h-auto">
                            ...and more (see insights)
                        </Button>
                    )}
                </div>
              </CardContent>
            </Card>
          )}

          {filteredInternships.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredInternships.map(internship => (
                <Card key={internship.id} className="hover:shadow-xl transition-shadow duration-300 ease-in-out flex flex-col">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                        <div className="space-y-1">
                            <CardTitle className="text-xl">{internship.title}</CardTitle>
                            <CardDescription className="flex items-center text-sm">
                                <Building className="h-4 w-4 mr-1.5 text-muted-foreground" />{internship.companyName}
                            </CardDescription>
                        </div>
                        {internship.companyLogo && 
                            <img src={internship.companyLogo} alt={`${internship.companyName} logo`} data-ai-hint="company logo" className="h-10 w-10 rounded-sm border"/>
                        }
                    </div>
                     <Badge variant={internship.status === 'Open' ? 'default' : 'secondary'} className="w-fit mt-2">{internship.status}</Badge>
                  </CardHeader>
                  <CardContent className="flex-grow space-y-2 text-sm">
                    <div className="flex items-center text-muted-foreground">
                      <Clock className="h-4 w-4 mr-2" /> Duration: {internship.duration}
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <DollarSign className="h-4 w-4 mr-2" /> Type: {internship.type} {internship.type === "Paid" && internship.salary && `(${internship.salary})`}
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <Tag className="h-4 w-4 mr-2" /> Industry: <Badge variant="secondary" className="ml-1">{internship.industry}</Badge>
                    </div>
                     <div className="flex items-center text-muted-foreground">
                       <CalendarIcon className="h-4 w-4 mr-2" /> Posted: {new Date(internship.postedDate).toLocaleDateString()}
                    </div>
                     <div className="flex items-center text-muted-foreground">
                       Location: {internship.location}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="default" className="w-full" onClick={() => setSelectedInternship(internship)}>
                      <ExternalLink className="mr-2 h-4 w-4" /> View Details & Apply
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-10">No internships match your current filters. Try adjusting your search.</p>
          )}
        </CardContent>
      </Card>

      <Dialog open={isMoreFiltersOpen} onOpenChange={setIsMoreFiltersOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-primary">More Filters & Insights</DialogTitle>
            <DialogDescription>
              Discover relevant companies and view all internship listings.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="suggestions" className="w-full pt-2">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="suggestions">Suggestions & Recommendations</TabsTrigger>
              <TabsTrigger value="all_internships">All Internships List</TabsTrigger>
            </TabsList>
            <TabsContent value="suggestions" className="space-y-4">
              {user?.role === 'student' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Sparkles className="mr-2 h-5 w-5 text-primary" /> Companies Based on Your Profile
                       {user.isPro && <Badge className="ml-2 bg-yellow-400 text-yellow-900 hover:bg-yellow-500"><Crown className="h-3 w-3 mr-1"/>PRO</Badge>}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {suggestedCompanies.length > 0 ? (
                      <>
                        <p className="text-sm text-muted-foreground mb-2">
                          Matching your interests: "{user.jobInterests || 'Not set'}" and major: "{user.major || 'Not set'}".
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {suggestedCompanies.map(companyName => (
                            <Badge key={companyName} variant="outline" className="text-md px-3 py-1">{companyName}</Badge>
                          ))}
                        </div>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground">No specific company suggestions based on your current profile. Update your profile for better recommendations.</p>
                    )}
                  </CardContent>
                </Card>
              )}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <ThumbsUp className="mr-2 h-5 w-5 text-green-500" /> Recommended by Past SCAD Interns (Mock)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {mockPastInternRecommendations.map(rec => (
                    <div key={rec.name} className="flex items-start p-3 border rounded-md bg-secondary/50">
                      <img src={rec.logo} alt={`${rec.name} logo`} data-ai-hint="company logo small" className="h-8 w-8 rounded-sm border mr-3 mt-1"/>
                      <div>
                        <h4 className="font-semibold">{rec.name}</h4>
                        <p className="text-xs text-muted-foreground">{rec.reason}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="all_internships">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center"><Briefcase className="mr-2 h-5 w-5" /> All Available Internships</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[350px] pr-3">
                    <div className="space-y-3">
                      {mockInternshipsData.map(internship => (
                        <div key={internship.id} className="p-3 border rounded-md hover:bg-muted/30 transition-colors">
                          <h4 className="font-semibold text-primary">{internship.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            <Building className="inline h-4 w-4 mr-1" /> {internship.companyName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            <Clock className="inline h-3 w-3 mr-1" /> Duration: {internship.duration}
                          </p>
                           <p className="text-xs text-muted-foreground">
                            <Tag className="inline h-3 w-3 mr-1" /> Status: {internship.status || 'N/A'}
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          <DialogFooter className="mt-4">
            <DialogClose asChild><Button variant="outline">Close</Button></DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {selectedInternship && (
        <Dialog open={!!selectedInternship} onOpenChange={() => {
          setSelectedInternship(null); 
          setCv(null); 
          setCoverLetter(null); 
          setOtherDocument(null);
        }}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <div className="flex items-start justify-between mb-2">
                  <div>
                    <DialogTitle className="text-2xl font-bold text-primary">{selectedInternship.title}</DialogTitle>
                    <DialogDescription className="text-base text-foreground flex items-center">
                        <Building className="h-5 w-5 mr-2 text-muted-foreground" /> {selectedInternship.companyName}
                    </DialogDescription>
                  </div>
                  {selectedInternship.companyLogo && 
                        <img src={selectedInternship.companyLogo} alt={`${selectedInternship.companyName} logo`} data-ai-hint="company logo detail" className="h-12 w-12 rounded-md border"/>
                  }
              </div>
              
            </DialogHeader>
            <ScrollArea className="max-h-[65vh]">
              <div className="space-y-4 pr-6">
                <p><strong className="font-semibold">Industry:</strong> <Badge variant="outline">{selectedInternship.industry}</Badge></p>
                <p><strong className="font-semibold">Location:</strong> {selectedInternship.location}</p>
                <p><strong className="font-semibold">Duration:</strong> {selectedInternship.duration}</p>
                <p><strong className="font-semibold">Type:</strong> {selectedInternship.type} {selectedInternship.type === "Paid" && selectedInternship.salary && `(${selectedInternship.salary})`}</p>
                <p><strong className="font-semibold">Status:</strong> <Badge variant={selectedInternship.status === 'Open' ? 'default' : 'secondary'}>{selectedInternship.status}</Badge></p>
                <p><strong className="font-semibold">Skills Required:</strong></p>
                <div className="flex flex-wrap gap-2">
                  {selectedInternship.skillsRequired.map(skill => <Badge key={skill} variant="secondary">{skill}</Badge>)}
                </div>
                <p><strong className="font-semibold">Job Description:</strong></p>
                <p className="text-muted-foreground whitespace-pre-wrap">{selectedInternship.jobDescription}</p>
                <p className="text-xs text-muted-foreground">Posted on: {new Date(selectedInternship.postedDate).toLocaleDateString()}</p>

                {user?.role === 'student' && (
                  <div className="space-y-4 pt-4 border-t">
                    <h3 className="text-lg font-semibold text-foreground">Upload Application Documents</h3>
                    <div className="space-y-2">
                      <Label htmlFor="cv-upload" className="flex items-center gap-2"><FileIcon className="h-4 w-4 text-muted-foreground" /> CV/Resume</Label>
                      <Input id="cv-upload" type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange(setCv)} />
                      {cv && <p className="text-xs text-muted-foreground">Selected CV: {cv.name}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cover-letter-upload" className="flex items-center gap-2"><FileIcon className="h-4 w-4 text-muted-foreground" /> Cover Letter (Optional)</Label>
                      <Input id="cover-letter-upload" type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange(setCoverLetter)} />
                      {coverLetter && <p className="text-xs text-muted-foreground">Selected Cover Letter: {coverLetter.name}</p>}
                    </div>
                     <div className="space-y-2">
                      <Label htmlFor="other-document-upload" className="flex items-center gap-2"><FileIcon className="h-4 w-4 text-muted-foreground" /> Other Certificate/Document (Optional)</Label>
                      <Input id="other-document-upload" type="file" accept=".pdf,.jpg,.png" onChange={handleFileChange(setOtherDocument)} />
                      {otherDocument && <p className="text-xs text-muted-foreground">Selected Document: {otherDocument.name}</p>}
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button variant="outline">Close</Button>
              </DialogClose>
              <Button onClick={() => handleApply(selectedInternship)} disabled={user?.role !== 'student' || selectedInternship.status === 'Closed'}>
                <UploadCloud className="mr-2 h-4 w-4" /> {selectedInternship.status === 'Closed' ? 'Application Closed' : 'Apply Now'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

