
"use client";

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label"; // Added import for Label
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Users, Search, Filter, CheckCircle, XCircle, Eye } from "lucide-react";
import type { Company, Industry } from '@/types';
import { Industries, CompanySizes } from '@/types';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

// Mock data for company applications
const mockCompanyApplications: Company[] = [
  { id: "compApp1", name: "Innovate Corp", industry: "Technology", size: "medium", email: "hr@innovate.com", applicationStatus: "Pending", submittedAt: "2024-05-15T10:00:00Z", logoUrl: "https://picsum.photos/seed/innovatecorp/60/60" },
  { id: "compApp2", name: "Creative Solutions", industry: "Marketing", size: "small", email: "contact@creativesolutions.io", applicationStatus: "Pending", submittedAt: "2024-05-14T14:30:00Z", logoUrl: "https://picsum.photos/seed/creativesol/60/60" },
  { id: "compApp3", name: "HealthFirst Ltd.", industry: "Healthcare", size: "large", email: "recruitment@healthfirst.com", applicationStatus: "Approved", submittedAt: "2024-05-10T09:00:00Z", logoUrl: "https://picsum.photos/seed/healthfirst/60/60" },
  { id: "compApp4", name: "EduGrowth Inc.", industry: "Education", size: "corporate", email: "partners@edugrowth.edu", applicationStatus: "Rejected", submittedAt: "2024-05-01T11:00:00Z", logoUrl: "https://picsum.photos/seed/edugrowth/60/60" },
];

export default function CompanyApplicationsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [applications, setApplications] = useState<Company[]>(mockCompanyApplications);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState<Industry | "all">("all");
  const [selectedApplication, setSelectedApplication] = useState<Company | null>(null);

  const filteredApplications = applications.filter(app => 
    (app.name.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (selectedIndustry === "all" || app.industry === selectedIndustry)
  );

  const handleUpdateStatus = (companyId: string, newStatus: 'Approved' | 'Rejected') => {
    setApplications(prevApps => 
      prevApps.map(app => app.id === companyId ? { ...app, applicationStatus: newStatus } : app)
    );
    const company = applications.find(app => app.id === companyId);
    toast({
      title: `Application ${newStatus}`,
      description: `Company "${company?.name}" application has been ${newStatus.toLowerCase()}.`
    });
    setSelectedApplication(null); // Close dialog if open
  };
  
  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg border-primary/10">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <Users className="mr-3 h-8 w-8" /> Company Applications
          </CardTitle>
          <CardDescription className="text-lg">Review and manage company applications to join the SCAD InternLink system.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 p-4 border rounded-lg bg-secondary/30">
            <div className="relative md:col-span-2">
              <Label htmlFor="search-company" className="sr-only">Search by Company Name</Label>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                id="search-company"
                placeholder="Search by company name..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)} 
              />
            </div>
            <div>
              <Label htmlFor="industry-filter">Filter by Industry</Label>
              <Select value={selectedIndustry} onValueChange={(value) => setSelectedIndustry(value as Industry | "all")}>
                <SelectTrigger id="industry-filter"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  {Industries.map(ind => <SelectItem key={ind} value={ind}>{ind}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Company Name</TableHead>
                <TableHead>Industry</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Submitted At</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredApplications.length > 0 ? filteredApplications.map((app) => (
                <TableRow key={app.id}>
                  <TableCell className="font-medium flex items-center">
                    {app.logoUrl && <Image src={app.logoUrl} alt={`${app.name} logo`} data-ai-hint="company logo small" width={24} height={24} className="mr-2 rounded-sm"/>}
                    {app.name}
                  </TableCell>
                  <TableCell>{app.industry}</TableCell>
                  <TableCell>{app.email}</TableCell>
                  <TableCell>{app.submittedAt ? new Date(app.submittedAt).toLocaleDateString() : 'N/A'}</TableCell>
                  <TableCell>
                    <Badge variant={
                      app.applicationStatus === 'Approved' ? 'default' :
                      app.applicationStatus === 'Rejected' ? 'destructive' : 'secondary'
                    }>
                      {app.applicationStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => setSelectedApplication(app)} title="View Details">
                      <Eye className="h-4 w-4" />
                    </Button>
                    {app.applicationStatus === 'Pending' && (
                      <>
                        <Button variant="ghost" size="icon" className="text-green-600 hover:text-green-700" onClick={() => handleUpdateStatus(app.id, 'Approved')} title="Approve">
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700" onClick={() => handleUpdateStatus(app.id, 'Rejected')} title="Reject">
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center h-24">No company applications match your criteria.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {selectedApplication && (
        <Dialog open={!!selectedApplication} onOpenChange={() => setSelectedApplication(null)}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
                <div className="flex items-center space-x-3 mb-3">
                    {selectedApplication.logoUrl && <Image src={selectedApplication.logoUrl} alt={`${selectedApplication.name} logo`} data-ai-hint="company logo detail" width={60} height={60} className="rounded-md border"/>}
                    <DialogTitle className="text-2xl font-bold text-primary">{selectedApplication.name}</DialogTitle>
                </div>
              <DialogDescription>Review the details of the company's application.</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 py-4 max-h-[60vh] overflow-y-auto pr-2">
              <p><strong className="font-semibold">Email:</strong> {selectedApplication.email}</p>
              <p><strong className="font-semibold">Industry:</strong> <Badge variant="outline">{selectedApplication.industry}</Badge></p>
              <p><strong className="font-semibold">Company Size:</strong> {CompanySizes[selectedApplication.size]}</p>
              <p><strong className="font-semibold">Submitted At:</strong> {selectedApplication.submittedAt ? new Date(selectedApplication.submittedAt).toLocaleString() : 'N/A'}</p>
              <p><strong className="font-semibold">Current Status:</strong> 
                <Badge className="ml-2" variant={
                    selectedApplication.applicationStatus === 'Approved' ? 'default' :
                    selectedApplication.applicationStatus === 'Rejected' ? 'destructive' : 'secondary'
                  }>
                    {selectedApplication.applicationStatus}
                </Badge>
              </p>
              <div>
                <strong className="font-semibold">Uploaded Documents:</strong>
                {/* Placeholder for document display/download */}
                <p className="text-sm text-muted-foreground mt-1">Tax_Document_EIN.pdf (Mock)</p>
                <p className="text-sm text-muted-foreground mt-1">Business_License.pdf (Mock)</p>
              </div>
            </div>
            <DialogFooter className="mt-4">
              <DialogClose asChild>
                <Button variant="outline">Close</Button>
              </DialogClose>
              {selectedApplication.applicationStatus === 'Pending' && (
                <>
                  <Button variant="destructive" onClick={() => handleUpdateStatus(selectedApplication.id, 'Rejected')}>
                    <XCircle className="mr-2 h-4 w-4" /> Reject Application
                  </Button>
                  <Button onClick={() => handleUpdateStatus(selectedApplication.id, 'Approved')}>
                    <CheckCircle className="mr-2 h-4 w-4" /> Approve Application
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
