
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings, Bell, Users, ShieldCheck, Save, CalendarClock } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react"; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


export default function ScadOfficeSystemSettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Mock settings state
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [newCompanyApproval, setNewCompanyApproval] = useState<'auto' | 'manual'>('manual');
  const [reportCycleStartDate, setReportCycleStartDate] = useState('');
  const [reportCycleEndDate, setReportCycleEndDate] = useState('');
  
  const handleSaveChanges = (tab: string) => {
    console.log(`Saving changes for ${tab} tab:`, { emailNotifications, newCompanyApproval, reportCycleStartDate, reportCycleEndDate });
    toast({
        title: "Settings Saved",
        description: `${tab} settings have been updated successfully. (Mock)`,
    });
  };

  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <Settings className="mr-3 h-8 w-8" /> System Settings
          </CardTitle>
          <CardDescription className="text-lg">
            Configure overall platform settings, notification preferences, and administrative parameters.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="general"><Bell className="mr-2 h-4 w-4 inline-block"/>Notifications</TabsTrigger>
              <TabsTrigger value="user_management"><Users className="mr-2 h-4 w-4 inline-block"/>User Management</TabsTrigger>
              <TabsTrigger value="cycle_settings"><CalendarClock className="mr-2 h-4 w-4 inline-block"/>Cycle Settings</TabsTrigger>
              <TabsTrigger value="security"><ShieldCheck className="mr-2 h-4 w-4 inline-block"/>Security & Access</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="space-y-6 p-4 border rounded-md">
              <CardTitle className="text-xl mb-4">Notification Settings</CardTitle>
              <div className="flex items-center justify-between space-x-2 p-3 border rounded-md hover:bg-secondary/50">
                <Label htmlFor="email-notifications" className="flex flex-col space-y-1">
                  <span>Email Notifications for New Applications</span>
                  <span className="font-normal leading-snug text-muted-foreground">
                    Receive an email when a student applies to an internship or a company registers.
                  </span>
                </Label>
                <Switch
                  id="email-notifications"
                  checked={emailNotifications}
                  onCheckedChange={setEmailNotifications}
                />
              </div>
               <div className="flex items-center justify-between space-x-2 p-3 border rounded-md hover:bg-secondary/50">
                <Label htmlFor="weekly-summary" className="flex flex-col space-y-1">
                  <span>Weekly Summary Emails</span>
                  <span className="font-normal leading-snug text-muted-foreground">
                    Send a weekly digest of platform activity to admins.
                  </span>
                </Label>
                <Switch id="weekly-summary" defaultChecked/>
              </div>
              <div className="pt-4 text-right">
                <Button onClick={() => handleSaveChanges("Notification")}><Save className="mr-2 h-4 w-4"/> Save Notification Settings</Button>
              </div>
            </TabsContent>

            <TabsContent value="user_management" className="space-y-6 p-4 border rounded-md">
              <CardTitle className="text-xl mb-4">User & Company Management</CardTitle>
              <div className="space-y-2">
                <Label htmlFor="company-approval">New Company Approval Process</Label>
                <Select value={newCompanyApproval} onValueChange={(value) => setNewCompanyApproval(value as 'auto' | 'manual')}>
                    <SelectTrigger id="company-approval"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="manual">Manual Approval by SCAD Office</SelectItem>
                        <SelectItem value="auto">Automatic Approval (Not Recommended)</SelectItem>
                    </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">Choose how new company registrations are handled.</p>
              </div>
              <div className="pt-4 text-right">
                 <Button onClick={() => handleSaveChanges("User Management")}><Save className="mr-2 h-4 w-4"/> Save User Settings</Button>
              </div>
            </TabsContent>

            <TabsContent value="cycle_settings" className="space-y-6 p-4 border rounded-md">
                <CardTitle className="text-xl mb-4">Academic Cycle Settings</CardTitle>
                <div className="space-y-2">
                    <Label htmlFor="report-cycle-start">Internship Report Submission Cycle Start Date</Label>
                    <Input 
                        id="report-cycle-start" 
                        type="date" 
                        value={reportCycleStartDate}
                        onChange={(e) => setReportCycleStartDate(e.target.value)}
                        className="max-w-xs"
                    />
                    <p className="text-xs text-muted-foreground">Set the start date for the current report submission period.</p>
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="report-cycle-end">Internship Report Submission Cycle End Date</Label>
                    <Input 
                        id="report-cycle-end" 
                        type="date" 
                        value={reportCycleEndDate}
                        onChange={(e) => setReportCycleEndDate(e.target.value)}
                        className="max-w-xs"
                    />
                    <p className="text-xs text-muted-foreground">Set the end date for the current report submission period.</p>
                </div>
                <div className="pt-4 text-right">
                    <Button onClick={() => handleSaveChanges("Cycle Settings")}><Save className="mr-2 h-4 w-4"/> Save Cycle Settings</Button>
                </div>
            </TabsContent>

            <TabsContent value="security" className="space-y-6 p-4 border rounded-md">
                <CardTitle className="text-xl mb-4">Security Settings</CardTitle>
                <div className="space-y-2">
                    <Label htmlFor="session-timeout">Admin Session Timeout (minutes)</Label>
                    <Input id="session-timeout" type="number" defaultValue={30} className="max-w-xs"/>
                    <p className="text-xs text-muted-foreground">Set how long an admin session can remain idle before automatic logout.</p>
                </div>
                <div className="flex items-center justify-between space-x-2 p-3 border rounded-md hover:bg-secondary/50">
                    <Label htmlFor="mfa" className="flex flex-col space-y-1">
                    <span>Require Multi-Factor Authentication for SCAD Office</span>
                    <span className="font-normal leading-snug text-muted-foreground">
                        Enhance security by requiring MFA for all SCAD Office accounts.
                    </span>
                    </Label>
                    <Switch id="mfa" />
                </div>
                <div className="pt-4 text-right">
                    <Button onClick={() => handleSaveChanges("Security")}><Save className="mr-2 h-4 w-4"/> Save Security Settings</Button>
                </div>
            </TabsContent>

          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

