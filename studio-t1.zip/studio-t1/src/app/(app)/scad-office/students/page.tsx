
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, Search, Filter, UserCog, Eye, Briefcase, Mail, Book, Users2, Award, Star } from "lucide-react";
import { useAuth, MOCK_USERS } from '@/hooks/use-auth';
import type { User as StudentUser, StudentInternshipStatus, PastInternship } from "@/types";
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Majors } from "@/types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";

const internshipStatuses: StudentInternshipStatus[] = ["Not Started", "Actively Interning", "Internship Completed", "Report Submitted", "Report Approved"];

export default function ScadOfficeStudentsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [students, setStudents] = useState<StudentUser[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<StudentUser[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMajor, setSelectedMajor] = useState<string>("all");
  const [selectedInternshipStatus, setSelectedInternshipStatus] = useState<StudentInternshipStatus | "all">("all");
  const [viewingStudent, setViewingStudent] = useState<StudentUser | null>(null);


  useEffect(() => {
    // Get all users with 'student' role from MOCK_USERS
    const allStudents = Object.values(MOCK_USERS)
        .filter(u => u.role === 'student')
        .map(u => ({ ...u, id: u.email } as StudentUser)); // Ensure 'id' field
    setStudents(allStudents);
    setFilteredStudents(allStudents);
  }, []);
  
  useEffect(() => {
    let tempFiltered = students;
    if (searchTerm) {
        tempFiltered = tempFiltered.filter(s => 
            s.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.email.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    if (selectedMajor !== "all") {
        tempFiltered = tempFiltered.filter(s => s.major === selectedMajor);
    }
    if (selectedInternshipStatus !== "all") {
        tempFiltered = tempFiltered.filter(s => s.internshipStatus === selectedInternshipStatus);
    }
    setFilteredStudents(tempFiltered);
  }, [searchTerm, selectedMajor, selectedInternshipStatus, students]);


  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }

  const getInitials = (name?: string) => {
    if (!name) return "U";
    const names = name.split(' ');
    if (names.length > 1) return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    return name.substring(0, 2).toUpperCase();
  };

  const handleManageAccount = (studentEmail: string) => {
    // Mock manage account action
    toast({
      title: "Manage Account (Mock)",
      description: `Navigating to account management for ${studentEmail}.`,
    });
  };

  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <GraduationCap className="mr-3 h-8 w-8" /> Manage Students
          </CardTitle>
          <CardDescription className="text-lg">
            View and manage student profiles, activities, and internship progress.
          </CardDescription>
        </CardHeader>
        <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
                <div className="relative lg:col-span-2">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input 
                        placeholder="Search by student name or email..." 
                        className="pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Select value={selectedMajor} onValueChange={setSelectedMajor}>
                    <SelectTrigger><SelectValue placeholder="Filter by Major" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Majors</SelectItem>
                        {Majors.map(major => (
                            <SelectItem key={major} value={major}>{major}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                <Select value={selectedInternshipStatus} onValueChange={(val) => setSelectedInternshipStatus(val as StudentInternshipStatus | "all")}>
                    <SelectTrigger><SelectValue placeholder="Filter by Internship Status" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Internship Statuses</SelectItem>
                        {internshipStatuses.map(status => (
                            <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

           {filteredStudents.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Major</TableHead>
                  <TableHead>Semester</TableHead>
                  <TableHead><Briefcase className="inline h-4 w-4 mr-1"/>Internship Status</TableHead>
                  <TableHead>PRO</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium flex items-center">
                       <Avatar className="h-8 w-8 mr-2 border">
                            <AvatarImage src={`https://picsum.photos/seed/${student.email}/32/32`} alt={student.name || 'avatar'} data-ai-hint="student profile" />
                            <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                        </Avatar>
                        {student.name || 'N/A'}
                    </TableCell>
                    <TableCell>{student.email}</TableCell>
                    <TableCell>{student.major || 'N/A'}</TableCell>
                    <TableCell>{student.semester || 'N/A'}</TableCell>
                    <TableCell>
                        <Badge variant={
                            student.internshipStatus === "Report Approved" ? "default" : 
                            student.internshipStatus === "Actively Interning" ? "secondary" :
                            "outline"
                        }>
                            {student.internshipStatus || 'N/A'}
                        </Badge>
                    </TableCell>
                    <TableCell>{student.isPro ? <Star className="h-4 w-4 text-yellow-500"/> : "No"}</TableCell>
                    <TableCell className="text-right space-x-1">
                      <Button variant="ghost" size="icon" title="View Profile" onClick={() => setViewingStudent(student)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Manage Account" onClick={() => handleManageAccount(student.email)}>
                        <UserCog className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">No students found matching your criteria.</p>
          )}
        </CardContent>
      </Card>

      {viewingStudent && (
        <Dialog open={!!viewingStudent} onOpenChange={() => setViewingStudent(null)}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader className="mb-4">
                <div className="flex items-center space-x-4">
                    <Avatar className="h-20 w-20 border-2 border-primary">
                        <AvatarImage src={`https://picsum.photos/seed/${viewingStudent.email}/80/80`} alt={viewingStudent.name || 'avatar'} data-ai-hint="student avatar large" />
                        <AvatarFallback className="text-2xl">{getInitials(viewingStudent.name)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <DialogTitle className="text-3xl font-bold text-primary">{viewingStudent.name || "Student Profile"}</DialogTitle>
                        <DialogDescription className="text-md text-muted-foreground">{viewingStudent.email}</DialogDescription>
                    </div>
                    {viewingStudent.isPro && <Badge variant="default" className="ml-auto text-sm px-3 py-1 bg-yellow-400 text-yellow-900"><Star className="h-4 w-4 mr-1.5"/>PRO Member</Badge>}
                </div>
            </DialogHeader>
            
            <ScrollArea className="max-h-[65vh] pr-4">
                <div className="space-y-6">
                    <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><GraduationCap className="mr-2 h-5 w-5 text-primary"/>Academic Information</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm">
                            <p><strong className="font-medium">Major:</strong> {viewingStudent.major || 'N/A'}</p>
                            <p><strong className="font-medium">Semester:</strong> {viewingStudent.semester || 'N/A'}</p>
                            <p><strong className="font-medium">Internship Status:</strong> 
                                <Badge variant={viewingStudent.internshipStatus === "Report Approved" ? "default" : viewingStudent.internshipStatus === "Actively Interning" ? "secondary" : "outline"} className="ml-1.5">
                                    {viewingStudent.internshipStatus || 'N/A'}
                                </Badge>
                            </p>
                        </div>
                    </section>

                    <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Users2 className="mr-2 h-5 w-5 text-primary"/>Professional Details</h3>
                        <div className="space-y-2 text-sm">
                             <div>
                                <strong className="font-medium">Job Interests:</strong>
                                <p className="text-muted-foreground whitespace-pre-wrap">{viewingStudent.jobInterests || 'Not specified'}</p>
                            </div>
                            <div>
                                <strong className="font-medium">College Activities & Achievements:</strong>
                                <p className="text-muted-foreground whitespace-pre-wrap">{viewingStudent.collegeActivities || 'Not specified'}</p>
                            </div>
                        </div>
                    </section>

                     <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/>Past Internships & Work Experience</h3>
                        {viewingStudent.pastInternships && viewingStudent.pastInternships.length > 0 ? (
                            <ul className="space-y-4">
                            {viewingStudent.pastInternships.map((internship: PastInternship, index: number) => (
                                <li key={index} className="p-3 border rounded-md bg-secondary/50 text-sm">
                                <h4 className="font-semibold">{internship.jobTitle} <span className="text-muted-foreground font-normal">at {internship.companyName}</span></h4>
                                <p className="text-xs text-muted-foreground">{internship.duration}</p>
                                <p className="mt-1 text-foreground/80">{internship.responsibilities}</p>
                                </li>
                            ))}
                            </ul>
                        ) : (
                            <p className="text-sm text-muted-foreground">No past internships or work experience listed.</p>
                        )}
                    </section>

                    {/* Placeholder for other profile sections like skills, portfolio link etc. */}
                    <section>
                         <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Award className="mr-2 h-5 w-5 text-primary"/>Skills & Portfolio</h3>
                         <p className="text-sm text-muted-foreground">(Skills and portfolio information would appear here - Mock)</p>
                    </section>
                </div>
            </ScrollArea>

            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline">Close</Button>
              </DialogClose>
              <Button onClick={() => handleManageAccount(viewingStudent?.email || '')} variant="default">
                  <UserCog className="mr-2 h-4 w-4"/> Manage Account (Mock)
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

    </div>
  );
}

