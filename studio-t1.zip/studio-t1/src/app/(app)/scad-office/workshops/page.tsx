
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CalendarDays, PlusCircle, Edit2, Trash2, Search } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { Workshop } from "@/types";
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const mockScadWorkshops: Workshop[] = [
  { id: "ws1", title: "Resume Building Masterclass", date: "2024-09-15T00:00:00Z", time: "2:00 PM - 4:00 PM", description: "Learn to craft a compelling resume.", facilitator: "Career Services Team", location: "Online", maxAttendees: 50, registeredAttendees: 25 },
  { id: "ws2", title: "Networking for Creatives", date: "2024-09-22T00:00:00Z", time: "10:00 AM - 11:30 AM", description: "Effective networking for creative students.", facilitator: "Jane Doe", location: "Room 301", maxAttendees: 30, registeredAttendees: 30 },
];

const initialWorkshopData: Omit<Workshop, 'id' | 'registeredAttendees'> = {
    title: '', date: '', time: '', description: '', facilitator: '', location: '', maxAttendees: 50
};

export default function ScadOfficeWorkshopsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [workshops, setWorkshops] = useState<Workshop[]>(mockScadWorkshops);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingWorkshop, setEditingWorkshop] = useState<Workshop | null>(null);
  const [workshopFormData, setWorkshopFormData] = useState(initialWorkshopData);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredWorkshops = workshops.filter(ws => 
    ws.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ws.facilitator?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setWorkshopFormData(prev => ({ ...prev, [name]: name === 'maxAttendees' ? parseInt(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingWorkshop) {
        setWorkshops(prev => prev.map(ws => ws.id === editingWorkshop.id ? {...editingWorkshop, ...workshopFormData, registeredAttendees: ws.registeredAttendees} : ws));
        toast({title: "Workshop Updated", description: `"${workshopFormData.title}" has been updated.`});
    } else {
        const newWorkshop: Workshop = { ...workshopFormData, id: `ws${Date.now()}`, registeredAttendees: 0};
        setWorkshops(prev => [newWorkshop, ...prev]);
        toast({title: "Workshop Created", description: `New workshop "${newWorkshop.title}" has been added.`});
    }
    setIsDialogOpen(false);
    setEditingWorkshop(null);
    setWorkshopFormData(initialWorkshopData);
  };

  const openEditDialog = (workshop: Workshop) => {
    setEditingWorkshop(workshop);
    setWorkshopFormData({
        title: workshop.title, date: workshop.date.split('T')[0], time: workshop.time, description: workshop.description,
        facilitator: workshop.facilitator, location: workshop.location, maxAttendees: workshop.maxAttendees
    });
    setIsDialogOpen(true);
  };

  const openCreateDialog = () => {
    setEditingWorkshop(null);
    setWorkshopFormData(initialWorkshopData);
    setIsDialogOpen(true);
  };
  
  const handleDeleteWorkshop = (workshopId: string) => {
    if (window.confirm("Are you sure you want to delete this workshop?")) {
        setWorkshops(prev => prev.filter(ws => ws.id !== workshopId));
        toast({title: "Workshop Deleted", variant: "destructive"});
    }
  };


  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-3xl font-bold text-primary flex items-center">
              <CalendarDays className="mr-3 h-8 w-8" /> Manage Workshops
            </CardTitle>
            <CardDescription className="text-lg">
              Create, edit, and manage career development workshops for students.
            </CardDescription>
          </div>
          <Button onClick={openCreateDialog}><PlusCircle className="mr-2 h-4 w-4"/> Create Workshop</Button>
        </CardHeader>
        <CardContent>
            <div className="relative mb-6 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    placeholder="Search workshops by title or facilitator..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

          {filteredWorkshops.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Facilitator</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Attendees</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredWorkshops.map((ws) => (
                  <TableRow key={ws.id}>
                    <TableCell className="font-medium">{ws.title}</TableCell>
                    <TableCell>{new Date(ws.date).toLocaleDateString()}, {ws.time}</TableCell>
                    <TableCell>{ws.facilitator || 'N/A'}</TableCell>
                    <TableCell>{ws.location || 'N/A'}</TableCell>
                    <TableCell>{ws.registeredAttendees || 0} / {ws.maxAttendees || 'N/A'}</TableCell>
                    <TableCell className="text-right space-x-1">
                      <Button variant="ghost" size="icon" onClick={() => openEditDialog(ws)}><Edit2 className="h-4 w-4"/></Button>
                      <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDeleteWorkshop(ws.id)}><Trash2 className="h-4 w-4"/></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">No workshops found.</p>
          )}
        </CardContent>
      </Card>

       <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl">{editingWorkshop ? 'Edit Workshop' : 'Create New Workshop'}</DialogTitle>
            <DialogDescription>
              {editingWorkshop ? 'Update workshop details.' : 'Fill in details for the new workshop.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
            <div><Label htmlFor="title">Title</Label><Input id="title" name="title" value={workshopFormData.title} onChange={handleInputChange} required /></div>
            <div><Label htmlFor="date">Date</Label><Input id="date" name="date" type="date" value={workshopFormData.date} onChange={handleInputChange} required /></div>
            <div><Label htmlFor="time">Time</Label><Input id="time" name="time" value={workshopFormData.time} onChange={handleInputChange} required placeholder="e.g., 2:00 PM - 4:00 PM" /></div>
            <div><Label htmlFor="description">Description</Label><Textarea id="description" name="description" value={workshopFormData.description} onChange={handleInputChange} required /></div>
            <div><Label htmlFor="facilitator">Facilitator</Label><Input id="facilitator" name="facilitator" value={workshopFormData.facilitator || ''} onChange={handleInputChange} /></div>
            <div><Label htmlFor="location">Location</Label><Input id="location" name="location" value={workshopFormData.location || ''} onChange={handleInputChange} placeholder="e.g., Online or Room 101" /></div>
            <div><Label htmlFor="maxAttendees">Max Attendees</Label><Input id="maxAttendees" name="maxAttendees" type="number" value={workshopFormData.maxAttendees || ''} onChange={handleInputChange} /></div>
            <DialogFooter className="pt-4">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit">{editingWorkshop ? 'Save Changes' : 'Create Workshop'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

    </div>
  );
}
