
"use client";

import React, { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, Search, Filter, CalendarCheck2, History, Star, CheckCircle, XCircle, Phone, PhoneCall, PhoneIncoming, PhoneOff as PhoneReject, UserCircle2 } from "lucide-react";
import { useAuth, MOCK_USERS } from '@/hooks/use-auth';
import type { Appointment, User as StudentUser, AppointmentStatus } from "@/types";
import { useState, useEffect, useCallback } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { VideoCallUI } from '@/components/feature/video-call-ui'; 

const mockAllAppointments: Appointment[] = [
    { id: "appt1", studentId: "student@scad.edu", studentName: "Alex Bee", advisorName: "Dr. Emily Carter", type: "Resume Review", date: "2024-09-10T00:00:00Z", time: "11:00 AM", status: "Scheduled", isOnline: true },
    { id: "appt2", studentId: "student@scad.edu", studentName: "Alex Bee", advisorName: "Mr. John Davis", type: "Career Counseling", date: "2024-08-20T00:00:00Z", time: "2:30 PM", status: "Completed", notes: "Discussed UX portfolio strategies." },
    { id: "appt3", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Emily Carter", type: "Mock Interview", date: "2024-09-05T00:00:00Z", time: "9:00 AM", status: "Scheduled", isOnline: false },
    { id: "appt4", studentId: "another@scad.edu", studentName: "Sam Lee (Pro Test)", advisorName: "Ms. Advisor", type: "Resume Review", date: "2024-09-12T00:00:00Z", time: "1:00 PM", status: "Pending Confirmation", isOnline: true },
    { id: "appt5", studentId: "extra@scad.edu", studentName: "Pat Jones", advisorName: "Dr. Emily Carter", type: "Career Counseling", date: "2024-09-01T00:00:00Z", time: "10:00 AM", status: "Cancelled" },
    { id: "appt6", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Mr. John Davis", type: "Report Clarification", date: "2024-09-18T00:00:00Z", time: "3:00 PM", status: "Pending Confirmation", notes: "Clarification needed for Q3 report details regarding project scope.", isOnline: false },
    { id: "appt7_nonpro_pending", studentId: "student@scad.edu", studentName: "Alex Bee (Non-Pro Test)", advisorName: "Dr. Test Advisor", type: "Other", date: "2024-09-20T00:00:00Z", time: "10:00 AM", status: "Pending Confirmation", notes: "This is a test request from a non-pro student.", isOnline: true },
    { id: "apptProScad1", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Anya Sharma", type: "Career Counseling", date: "2024-10-05T00:00:00Z", time: "11:00 AM", status: "Pending Confirmation", notes: "Pro student seeking advanced portfolio review.", isOnline: true },
    { id: "apptProScad2", studentId: "another@scad.edu", studentName: "Sam Lee (Pro Test)", advisorName: "Mr. Ben Miller", type: "Mock Interview", date: "2024-10-08T00:00:00Z", time: "02:00 PM", status: "Scheduled", isOnline: false },
    { id: "apptProScad3", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Emily Carter", type: "Resume Review", date: "2024-10-10T00:00:00Z", time: "09:30 AM", status: "Completed", notes: "Final resume check before applying to tier 1 studios." },
    { id: "apptProScad4", studentId: "another@scad.edu", studentName: "Sam Lee (Pro Test)", advisorName: "Ms. Advisor", type: "Other", date: "2024-10-12T00:00:00Z", time: "04:00 PM", status: "Pending Confirmation", notes: "Discussion about industry trends for Pro members.", isOnline: true },
];

interface ActiveCallInfo {
  appointmentId: string;
  participantName: string;
  isInitiator: boolean; 
}

export default function ScadOfficeAppointmentsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [allAppointments, setAllAppointments] = useState<Appointment[]>(mockAllAppointments);
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<AppointmentStatus | "all">("all");
  const [filterAdvisor, setFilterAdvisor] = useState<string>("all");
  const [activeCall, setActiveCall] = useState<ActiveCallInfo | null>(null);
  const [simulatedStudentCall, setSimulatedStudentCall] = useState<Appointment | null>(null); 


  const uniqueAdvisors = ["all", ...new Set(allAppointments.map(a => a.advisorName).filter(Boolean) as string[])];

  const isProStudent = useCallback((studentId: string): boolean => {
    const student = MOCK_USERS[studentId.toLowerCase()] as StudentUser | undefined;
    return !!student?.isPro;
  }, []);

  useEffect(() => {
    let tempFiltered = allAppointments.filter(appointment => {
        // Only show pending confirmations for Pro students or if SCAD office is the advisor
        if (appointment.status === "Pending Confirmation") {
           return isProStudent(appointment.studentId) || (user?.role === 'scad_office' && appointment.advisorName === user.name);
        }
        return true;
    });

    if (searchTerm) {
        tempFiltered = tempFiltered.filter(a => 
            a.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            a.type.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    if (filterStatus !== "all") {
        tempFiltered = tempFiltered.filter(a => a.status === filterStatus);
    }
    if (filterAdvisor !== "all") {
        tempFiltered = tempFiltered.filter(a => a.advisorName === filterAdvisor);
    }
    setFilteredAppointments(tempFiltered);
  }, [searchTerm, filterStatus, filterAdvisor, allAppointments, isProStudent, user]);

 useEffect(() => {
    if (user?.role === 'scad_office' && !activeCall && !simulatedStudentCall) {
      const scheduledAppointmentsWithScadAdvisor = allAppointments.filter(
        appt => appt.status === "Scheduled" && appt.advisorName === user.name && appt.isOnline 
      );
      if (scheduledAppointmentsWithScadAdvisor.length > 0) {
        const randomApptIndex = Math.floor(Math.random() * scheduledAppointmentsWithScadAdvisor.length);
        const appointmentToSimulateCall = scheduledAppointmentsWithScadAdvisor[randomApptIndex];
        
        const timer = setTimeout(() => {
          setSimulatedStudentCall(appointmentToSimulateCall);
          toast({
            title: "Incoming Student Call",
            description: `Incoming call from ${appointmentToSimulateCall.studentName} for ${appointmentToSimulateCall.type}.`,
            duration: 10000,
            action: (
              <div className="flex gap-2">
                <Button size="sm" onClick={() => handleAcceptStudentCall(appointmentToSimulateCall)} className="bg-green-500 hover:bg-green-600">Accept</Button>
                <Button size="sm" variant="outline" onClick={() => handleRejectStudentCall(appointmentToSimulateCall)}>Reject</Button>
              </div>
            )
          });
        }, 10000); 
        return () => clearTimeout(timer);
      }
    }
  }, [user, allAppointments, activeCall, simulatedStudentCall, toast]);


  const handleUpdateAppointmentStatus = (appointmentId: string, newStatus: AppointmentStatus) => {
    const appointmentIndex = mockAllAppointments.findIndex(a => a.id === appointmentId);
    if (appointmentIndex !== -1) {
        if (isProStudent(mockAllAppointments[appointmentIndex].studentId) || newStatus !== "Pending Confirmation") {
            mockAllAppointments[appointmentIndex].status = newStatus;
            setAllAppointments([...mockAllAppointments]); 
            toast({ title: "Appointment Updated", description: `Appointment status changed to ${newStatus}.` });
        } else {
             toast({ title: "Action Restricted", description: "Cannot set non-Pro student appointment to 'Pending Confirmation' from here.", variant: "destructive" });
        }
    } else {
        toast({ title: "Error", description: "Could not update appointment status.", variant: "destructive" });
    }
  };

  const handleStartOrJoinCall = (appointment: Appointment) => {
    if (activeCall) {
        toast({ title: "Already in a call", description: "Please leave your current call before starting/joining another.", variant: "destructive"});
        return;
    }
    if (!appointment.isOnline) {
        toast({ title: "Offline Appointment", description: "This is an in-person appointment. No online call to join.", variant: "default"});
        return;
    }
    setActiveCall({
        appointmentId: appointment.id,
        participantName: appointment.studentName,
        isInitiator: true, 
    });
    setSimulatedStudentCall(null);
    toast({ title: "Joining Call", description: `Connecting to call with ${appointment.studentName}...` });
  };

  const handleAcceptStudentCall = (appointment: Appointment) => {
     if (activeCall) {
        toast({ title: "Already in a call", description: "Please leave your current call before accepting another.", variant: "destructive"});
        return;
    }
     setActiveCall({
        appointmentId: appointment.id,
        participantName: appointment.studentName,
        isInitiator: false, 
     });
     setSimulatedStudentCall(null);
     toast({ title: "Call Accepted", description: `Connecting to ${appointment.studentName}...`});
  };

  const handleRejectStudentCall = (appointment: Appointment) => {
    setSimulatedStudentCall(null); 
    toast({ title: "Call Rejected", description: `You rejected the call from ${appointment.studentName}.`, variant: "default" });
  };

  const handleLeaveCall = () => {
    if(activeCall) {
       toast({ title: "Call Ended", description: `You left the call with ${activeCall.participantName}.` });
    }
    setActiveCall(null);
    setSimulatedStudentCall(null);
  };

  const handleParticipantJoined = () => {
    if (activeCall) {
      toast({ title: "Student Joined", description: `${activeCall.participantName} has joined the call.` });
    }
  };

  const handleParticipantLeft = () => {
    if (activeCall) {
      toast({ title: "Student Left", description: `${activeCall.participantName} has left the call. Ending session.` });
      setActiveCall(null); // End the call locally
    }
  };
  
  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }
  
  if (activeCall) {
    return <VideoCallUI 
        participantName={activeCall.participantName} 
        onLeaveCall={handleLeaveCall} 
        isCallCreator={activeCall.isInitiator}
        onParticipantJoin={handleParticipantJoined}
        onParticipantLeave={handleParticipantLeft} 
      />;
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-3xl font-bold text-primary flex items-center">
                <Video className="mr-3 h-8 w-8" /> Manage Appointments
            </CardTitle>
            <CardDescription className="text-lg">
                Oversee and manage student appointments with career advisors. Pending requests from non-Pro students are hidden unless you are the assigned advisor.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input 
                        placeholder="Search by student or type..." 
                        className="pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Select value={filterStatus} onValueChange={(val) => setFilterStatus(val as AppointmentStatus | "all")}>
                    <SelectTrigger><SelectValue placeholder="Filter by Status" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        {(["Scheduled", "Completed", "Cancelled", "Pending Confirmation"] as AppointmentStatus[]).map(s => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                 <Select value={filterAdvisor} onValueChange={setFilterAdvisor}>
                    <SelectTrigger><SelectValue placeholder="Filter by Advisor" /></SelectTrigger>
                    <SelectContent>
                        {uniqueAdvisors.map(adv => (
                            <SelectItem key={adv} value={adv}>{adv === "all" ? "All Advisors" : adv}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

          {filteredAppointments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Advisor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAppointments.map((appt) => (
                  <TableRow key={appt.id}>
                    <TableCell className="font-medium flex items-center">
                        <UserCircle2 className="h-4 w-4 mr-1.5 text-muted-foreground"/>
                        {appt.studentName}
                        {isProStudent(appt.studentId) && (
                            <Badge variant="secondary" className="ml-2 bg-yellow-400 text-yellow-900 hover:bg-yellow-500">
                                <Star className="mr-1 h-3 w-3" /> PRO
                            </Badge>
                        )}
                        {(appt.status === "Scheduled" || appt.status === "Pending Confirmation") && appt.isOnline !== undefined && (
                            <span
                                className={`ml-2 h-2.5 w-2.5 rounded-full ${appt.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}
                                title={appt.isOnline ? 'Online Appointment' : 'Offline/In-person Appointment'}
                            />
                        )}
                    </TableCell>
                    <TableCell>{new Date(appt.date).toLocaleDateString()}, {appt.time}</TableCell>
                    <TableCell>{appt.type}</TableCell>
                    <TableCell>{appt.advisorName || 'N/A'}</TableCell>
                    <TableCell>
                        <Badge 
                            variant={
                                appt.status === 'Scheduled' ? 'default' : 
                                appt.status === 'Completed' ? 'secondary' :
                                appt.status === 'Cancelled' ? 'destructive' :
                                'outline' 
                            }
                        >
                            {appt.status}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                        {/* <Button variant="outline" size="sm">View Details</Button> */}
                        {simulatedStudentCall && simulatedStudentCall.id === appt.id && appt.isOnline ? (
                             <>
                                <Button variant="default" size="sm" onClick={() => handleAcceptStudentCall(appt)} className="bg-green-500 hover:bg-green-600">
                                    <PhoneIncoming className="mr-1.5 h-4 w-4" /> Accept
                                </Button>
                                <Button variant="destructive" size="sm" onClick={() => handleRejectStudentCall(appt)}>
                                    <PhoneReject className="mr-1.5 h-4 w-4" /> Reject
                                </Button>
                            </>
                        ) : appt.status === "Scheduled" && appt.isOnline ? (
                             <Button variant="default" size="sm" onClick={() => handleStartOrJoinCall(appt)}>
                                <PhoneCall className="mr-1.5 h-4 w-4"/> Join Call
                            </Button>
                        ): appt.status === "Scheduled" && !appt.isOnline ? (
                           <Badge variant="outline">In-Person</Badge>
                        ) : null}
                         {appt.status === "Pending Confirmation" && (isProStudent(appt.studentId) || appt.advisorName === user?.name) && (!simulatedStudentCall || simulatedStudentCall.id !== appt.id) && (
                            <>
                                <Button 
                                    variant="default" 
                                    size="sm" 
                                    onClick={() => handleUpdateAppointmentStatus(appt.id, "Scheduled")}
                                >
                                    <CheckCircle className="mr-1.5 h-4 w-4"/>Confirm
                                </Button>
                                <Button 
                                    variant="destructive" 
                                    size="sm"
                                    onClick={() => handleUpdateAppointmentStatus(appt.id, "Cancelled")}
                                >
                                    <XCircle className="mr-1.5 h-4 w-4"/>Reject
                                </Button>
                            </>
                        )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">No appointments found matching your criteria, or no Pro student requests pending.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

