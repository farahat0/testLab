
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { BarChart2, Users, Briefcase, FileText, PieChart as PieChartIcon, TrendingUp, TrendingDown, Download, CheckSquare, AlertTriangle, Star, BookOpen, Clock } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Pie, Cell, Legend, Tooltip, BarChart as RechartsBarChart, PieChart as RechartsPieChart } from 'recharts';
import * as RechartsPrimitive from "recharts";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const totalStudents = 2500;
const totalCompanies = 150;
const activeInternships = 320;
const applicationsReceived = 1250;

const reportStatusData = [
  { name: 'Approved', value: 180, fill: "hsl(var(--chart-1))" },
  { name: 'Rejected', value: 25, fill: "hsl(var(--chart-2))" },
  { name: 'Needs Revision (Flagged)', value: 45, fill: "hsl(var(--chart-3))" },
  { name: 'Pending Review', value: 70, fill: "hsl(var(--chart-4))" },
];
const avgReviewTime = 3.5; // days

const frequentlyUsedCoursesData = [
  { course: 'UXDS 310: Interaction Design', count: 85, fill: "hsl(var(--chart-1))" },
  { course: 'ANIM 350: 3D Modeling', count: 72, fill: "hsl(var(--chart-2))" },
  { course: 'GRDS 205: Typography I', count: 65, fill: "hsl(var(--chart-3))" },
  { course: 'FILM 230: Cinematography', count: 58, fill: "hsl(var(--chart-4))" },
  { course: 'ADS 250: Copywriting', count: 50, fill: "hsl(var(--chart-5))" },
];

const topRatedCompaniesData = [
  { name: 'Innovate Corp', rating: 4.8, fill: "hsl(var(--primary))" },
  { name: 'PixelPlay Studios', rating: 4.7, fill: "hsl(var(--accent))" },
  { name: 'Creative Solutions', rating: 4.5, fill: "hsl(var(--secondary-foreground))" },
  { name: 'Tech Solutions Inc.', rating: 4.4, fill: "hsl(var(--chart-2))" },
  { name: 'FutureAI', rating: 4.3, fill: "hsl(var(--chart-4))" },
];

const topCompaniesByInternshipCountData = [
  { name: 'Tech Solutions Inc.', count: 25, fill: "hsl(var(--chart-1))" },
  { name: 'Innovate Corp', count: 22, fill: "hsl(var(--chart-2))" },
  { name: 'Global Web Services', count: 18, fill: "hsl(var(--chart-3))" },
  { name: 'Design Hub', count: 15, fill: "hsl(var(--chart-4))" },
  { name: 'Media Max', count: 12, fill: "hsl(var(--chart-5))" },
];


const applicationTrendData = [
  { month: 'Jan', applications: 150 }, { month: 'Feb', applications: 180 },
  { month: 'Mar', applications: 220 }, { month: 'Apr', applications: 200 },
  { month: 'May', applications: 250 }, { month: 'Jun', applications: 230 },
];

export default function ScadOfficeStatisticsPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  const handleGenerateReport = () => {
    // Mock report generation
    toast({
      title: "Report Generated (Mock)",
      description: "A comprehensive statistics report has been downloaded.",
    });
    // In a real app, this would trigger a download of a CSV/PDF file.
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Metric,Value\n"
      + `Total Students,${totalStudents}\n`
      + `Total Companies,${totalCompanies}\n`
      + `Active Internships,${activeInternships}\n`
      + `Applications This Month,${applicationsReceived}\n`
      + `Avg. Report Review Time (days),${avgReviewTime}\n`
      + reportStatusData.map(r => `Report Status - ${r.name},${r.value}`).join("\n") + "\n"
      + frequentlyUsedCoursesData.map(c => `Course Usage - ${c.course},${c.count}`).join("\n") + "\n"
      + topRatedCompaniesData.map(c => `Top Rated Company - ${c.name},${c.rating}`).join("\n") + "\n"
      + topCompaniesByInternshipCountData.map(c => `Top Company (Count) - ${c.name},${c.count}`).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "scad_internlink_statistics_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row justify-between items-start">
          <div>
            <CardTitle className="text-3xl font-bold text-primary flex items-center">
              <BarChart2 className="mr-3 h-8 w-8" /> Platform Statistics
            </CardTitle>
            <CardDescription className="text-lg">
              View key metrics and statistics for the SCAD InternLink program.
            </CardDescription>
          </div>
          <Button onClick={handleGenerateReport} variant="outline">
            <Download className="mr-2 h-4 w-4" /> Generate Full Report
          </Button>
        </CardHeader>
      </Card>

    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Students</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{totalStudents}</div>
                <p className="text-xs text-muted-foreground">+5% from last semester</p>
            </CardContent>
        </Card>
         <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Companies</CardTitle>
                <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{totalCompanies}</div>
                <p className="text-xs text-muted-foreground">+12 newly approved</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Internships</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{activeInternships}</div>
                <p className="text-xs text-muted-foreground"><TrendingUp className="inline h-3 w-3 text-green-500"/> +8% this month</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Applications This Month</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{applicationsReceived}</div>
                 <p className="text-xs text-muted-foreground"><TrendingDown className="inline h-3 w-3 text-red-500"/> -3% from last month peak</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg. Report Review Time</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{avgReviewTime} days</div>
                 <p className="text-xs text-muted-foreground">Per report (current cycle)</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Reports Approved</CardTitle>
                <CheckSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{reportStatusData.find(r => r.name === 'Approved')?.value || 0}</div>
                 <p className="text-xs text-muted-foreground">This cycle</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Reports Flagged/Rejected</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">
                    {(reportStatusData.find(r => r.name === 'Rejected')?.value || 0) + 
                     (reportStatusData.find(r => r.name === 'Needs Revision (Flagged)')?.value || 0)}
                </div>
                 <p className="text-xs text-muted-foreground">This cycle</p>
            </CardContent>
        </Card>
         <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Top Rated Company (Avg)</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-xl font-bold">{topRatedCompaniesData[0].name} ({topRatedCompaniesData[0].rating}/5)</div>
                 <p className="text-xs text-muted-foreground">Based on student evaluations</p>
            </CardContent>
        </Card>

    </div>

    <div className="grid gap-6 md:grid-cols-2">
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><PieChartIcon className="mr-2 h-5 w-5"/>Report Status Distribution</CardTitle>
                <CardDescription>Overview of internship report statuses for the current cycle.</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                 <ChartContainer config={{}} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.PieChart>
                            <RechartsPrimitive.Pie data={reportStatusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                            {reportStatusData.map((entry, index) => (
                                <RechartsPrimitive.Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                            </RechartsPrimitive.Pie>
                            <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                            <ChartLegend content={<ChartLegendContent nameKey="name" />} />
                        </RechartsPrimitive.PieChart>
                    </ResponsiveContainer>
                 </ChartContainer>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><BookOpen className="mr-2 h-5 w-5"/>Most Frequently Used Courses</CardTitle>
                <CardDescription>Top courses students cited as helpful in their internships.</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                <ChartContainer config={{ count: { label: "Mentions", color: "hsl(var(--primary))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.BarChart data={frequentlyUsedCoursesData} layout="vertical" margin={{ right: 30 }}>
                        <CartesianGrid horizontal={false} />
                        <XAxis type="number" dataKey="count" />
                        <YAxis type="category" dataKey="course" tickLine={false} axisLine={false} tickMargin={8} width={180} />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <RechartsPrimitive.Bar dataKey="count" fill="var(--color-count)" radius={4} barSize={15} />
                        </RechartsPrimitive.BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
            </CardContent>
        </Card>
         <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><Star className="mr-2 h-5 w-5"/>Top Rated Companies by Students</CardTitle>
                <CardDescription>Average rating based on student evaluations (out of 5).</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                <ChartContainer config={{ rating: { label: "Avg. Rating", color: "hsl(var(--primary))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.BarChart data={topRatedCompaniesData} layout="vertical" margin={{ right: 30 }}>
                        <CartesianGrid horizontal={false} />
                        <XAxis type="number" dataKey="rating" domain={[0,5]}/>
                        <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} tickMargin={8} width={120} />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <RechartsPrimitive.Bar dataKey="rating" fill="var(--color-rating)" radius={4} barSize={20} />
                        </RechartsPrimitive.BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center"><Briefcase className="mr-2 h-5 w-5"/>Top Companies by Internship Count</CardTitle>
                <CardDescription>Companies with the highest number of active/recent internships.</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px]">
                 <ChartContainer config={{ count: { label: "Internships", color: "hsl(var(--accent))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.PieChart>
                            <RechartsPrimitive.Pie data={topCompaniesByInternshipCountData} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                            {topCompaniesByInternshipCountData.map((entry, index) => (
                                <RechartsPrimitive.Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                            </RechartsPrimitive.Pie>
                            <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                            <ChartLegend content={<ChartLegendContent nameKey="name" />} />
                        </RechartsPrimitive.PieChart>
                    </ResponsiveContainer>
                 </ChartContainer>
            </CardContent>
        </Card>

        <Card className="md:col-span-2">
            <CardHeader>
                <CardTitle className="flex items-center"><TrendingUp className="mr-2 h-5 w-5"/>Application Trends</CardTitle>
                <CardDescription>Monthly trend of internship applications received.</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
                <ChartContainer config={{ applications: { label: "Applications", color: "hsl(var(--primary))" } }} className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPrimitive.BarChart data={applicationTrendData}>
                        <CartesianGrid vertical={false} />
                        <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <ChartLegend content={<ChartLegendContent />} />
                        <RechartsPrimitive.Bar dataKey="applications" fill="var(--color-applications)" radius={4} />
                        </RechartsPrimitive.BarChart>
                    </ResponsiveContainer>
                </ChartContainer>
            </CardContent>
        </Card>
    </div>

    </div>
  );
}

