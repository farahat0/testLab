
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText, Search, Filter, Download, CalendarClock, User as UserIcon, MessageSquareWarning, CheckCircle, Edit3, XCircle } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { InternshipReport, InternshipReportStatus, Major } from "@/types"; // Import Major
import { Majors } from "@/types"; // Import Majors
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const mockAllInternshipReports: InternshipReport[] = [
    { id: "report1", studentId: "student@scad.edu", studentName: "Alex Bee", studentMajor: "UX Design", internshipId: "1", internshipTitle: "UX Design Intern", companyName: "Innovate Corp", submissionDate: "2023-08-15T00:00:00Z", reportTitle: "UX Internship Report", introduction: "Intro for UX report.", body: "Body of UX report.", companyEvaluation: "Innovate Corp was a fantastic place to learn.", recommendCompany: true, status: "Approved", facultyAdvisorName: "Prof. Ada Lovelace", internshipStartDate: "2023-05-15T00:00:00Z", internshipEndDate: "2023-08-10T00:00:00Z", companySupervisorName: "Dr. UX Head" },
    { id: "report2", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentMajor: "Animation", internshipId: "5", internshipTitle: "Junior Game Dev Intern", companyName: "PixelPlay Studios", submissionDate: "2023-07-20T00:00:00Z", reportTitle: "Game Dev Report", introduction: "Intro for game dev.", body: "Body of game dev report.", companyEvaluation: "PixelPlay offered great hands-on experience.", recommendCompany: true, status: "Pending Review", facultyAdvisorName: "Prof. Alan Turing", internshipStartDate: "2023-05-01T00:00:00Z", internshipEndDate: "2023-07-15T00:00:00Z", companySupervisorName: "Mr. Dev Lead" },
    { id: "report3", studentId: "student@scad.edu", studentName: "Alex Bee", studentMajor: "UX Design", internshipId: "int003", internshipTitle: "Marketing Assistant", companyName: "Creative Co.", submissionDate: "2023-09-01T00:00:00Z", reportTitle: "Marketing Internship Summary", introduction: "Intro for marketing.", body: "Body of marketing report.", status: "Needs Revision", facultyAdvisorName: "Prof. Grace Hopper", facultyComments: "Lacks detail in project outcomes.", internshipStartDate: "2023-06-01T00:00:00Z", internshipEndDate: "2023-08-20T00:00:00Z", companySupervisorName: "Ms. Marketing Manager" },
    { id: "report4", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentMajor: "Animation", internshipId: "gameInternshipPro", internshipTitle: "Advanced Game Design", companyName: "Metaverse Makers", submissionDate: "2024-03-10T00:00:00Z", reportTitle: "Metaverse Design Doc", introduction: "Deep dive into procedural generation for level design.", body: "Explored algorithms and implemented a prototype system.", status: "Appealed", facultyAdvisorName: "Prof. Alan Turing", facultyComments: "Report structure was unclear.", appealMessage: "I have restructured the report to better highlight the key findings and my contributions as per feedback.", internshipStartDate: "2023-12-01T00:00:00Z", internshipEndDate: "2024-02-28T00:00:00Z", companySupervisorName: "Dr. Lead Designer" },
];

export default function ScadOfficeReportsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reports, setReports] = useState<InternshipReport[]>(mockAllInternshipReports);
  const [filteredReports, setFilteredReports] = useState<InternshipReport[]>(mockAllInternshipReports);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<InternshipReportStatus | "all">("all");
  const [selectedMajor, setSelectedMajor] = useState<Major | "all">("all"); // State for major filter
  const [viewingReport, setViewingReport] = useState<InternshipReport | null>(null);

  // State for clarification dialog
  const [isClarificationDialogOpen, setIsClarificationDialogOpen] = useState(false);
  const [reportForClarification, setReportForClarification] = useState<InternshipReport | null>(null);
  const [clarificationAction, setClarificationAction] = useState<InternshipReportStatus | null>(null);
  const [currentClarificationText, setCurrentClarificationText] = useState("");

  useEffect(() => {
    let tempFiltered = reports;
    if (searchTerm) {
        tempFiltered = tempFiltered.filter(r => 
            r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            r.reportTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
            r.internshipTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
            r.companyName.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    if (filterStatus !== "all") {
        tempFiltered = tempFiltered.filter(r => r.status === filterStatus);
    }
    if (selectedMajor !== "all") { // Apply major filter
        tempFiltered = tempFiltered.filter(r => r.studentMajor === selectedMajor);
    }
    setFilteredReports(tempFiltered);
  }, [searchTerm, filterStatus, selectedMajor, reports]);

  const handleDownloadReport = (report: InternshipReport) => {
    const reportContent = `
      Report Title: ${report.reportTitle}
      Student: ${report.studentName} (${report.studentId})
      Student Major: ${report.studentMajor || 'N/A'}
      Internship: ${report.internshipTitle} at ${report.companyName}
      Internship Dates: ${report.internshipStartDate ? new Date(report.internshipStartDate).toLocaleDateString() : 'N/A'} - ${report.internshipEndDate ? new Date(report.internshipEndDate).toLocaleDateString() : 'N/A'}
      Company Supervisor: ${report.companySupervisorName || 'N/A'}
      Submission Date: ${new Date(report.submissionDate).toLocaleDateString()}
      Status: ${report.status}
      Advisor: ${report.facultyAdvisorName || 'N/A'}

      Introduction:
      ${report.introduction || 'N/A'}

      Body:
      ${report.body || 'N/A'}

      Student's Evaluation of Company:
      ${report.companyEvaluation || 'Not Provided'}
      Recommend Company to other SCAD students: ${report.recommendCompany !== undefined ? (report.recommendCompany ? 'Yes' : 'No') : 'Not Provided'}

      Relevant SCAD Courses Mentioned:
      ${report.relevantCourses?.join(", ") || 'N/A'}
      
      Faculty Comments:
      ${report.facultyComments || 'N/A'}

      Student Appeal Message (if any):
      ${report.appealMessage || 'N/A'}
    `;
    const blob = new Blob([reportContent.trim()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.studentName}_${report.internshipTitle.replace(/\s+/g, '_')}_Report.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Report Downloaded", description: "The report content has been downloaded as a text file." });
  };

  const getStatusVariant = (status: InternshipReportStatus) => {
    switch(status) {
      case "Approved": return "default";
      case "Needs Revision": return "destructive";
      case "Rejected": return "destructive";
      case "Draft": return "outline";
      case "Appealed": return "secondary"; 
      case "Pending Review": return "secondary";
      default: return "secondary";
    }
  }

  const handleOfficeUpdateStatus = (reportId: string, newStatus: InternshipReportStatus, comments?: string) => {
    setReports(prev => prev.map(r => r.id === reportId ? {...r, status: newStatus, facultyComments: comments || r.facultyComments } : r)); 
    const masterIndex = mockAllInternshipReports.findIndex(r => r.id === reportId);
    if (masterIndex !== -1) {
        mockAllInternshipReports[masterIndex].status = newStatus;
        if(comments !== undefined) mockAllInternshipReports[masterIndex].facultyComments = comments;
    }
    toast({title: "Report Status Updated by Office", description: `Report marked as ${newStatus}.`});
    if (viewingReport?.id === reportId) {
        setViewingReport(prev => prev ? {...prev, status: newStatus, facultyComments: comments !== undefined ? comments : prev.facultyComments} : null);
    }
  };

  const openClarificationDialog = (report: InternshipReport, action: 'Needs Revision' | 'Rejected') => {
    setReportForClarification(report);
    setClarificationAction(action);
    setCurrentClarificationText(report.facultyComments || "");
    setIsClarificationDialogOpen(true);
  };

  const submitClarification = () => {
    if (reportForClarification && clarificationAction) {
      handleOfficeUpdateStatus(reportForClarification.id, clarificationAction, currentClarificationText);
      setIsClarificationDialogOpen(false);
      setReportForClarification(null);
      setClarificationAction(null);
      setCurrentClarificationText("");
    }
  };

  if (user?.role !== 'scad_office') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for SCAD Office personnel only.</p>;
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <FileText className="mr-3 h-8 w-8" /> Internship Reports Overview
          </CardTitle>
          <CardDescription className="text-lg">
            Review and manage all submitted internship reports from students.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
            <div className="relative md:col-span-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    placeholder="Search reports..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <Select value={selectedMajor} onValueChange={(val) => setSelectedMajor(val as Major | "all")}>
                <SelectTrigger><SelectValue placeholder="Filter by Major" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Majors</SelectItem>
                    {Majors.map(m => (
                        <SelectItem key={m} value={m}>{m}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={(val) => setFilterStatus(val as InternshipReportStatus | "all")}>
                <SelectTrigger><SelectValue placeholder="Filter by Status" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {(["Pending Review", "Approved", "Needs Revision", "Draft", "Appealed", "Rejected"] as InternshipReportStatus[]).map(s => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>

          {filteredReports.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student Name</TableHead>
                  <TableHead>Report Title</TableHead>
                  <TableHead>Internship</TableHead>
                  <TableHead>Submission Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Advisor</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">{report.studentName} <span className="text-xs text-muted-foreground">({report.studentMajor || 'N/A'})</span></TableCell>
                    <TableCell>{report.reportTitle}</TableCell>
                    <TableCell>{report.internshipTitle} at {report.companyName}</TableCell>
                    <TableCell>{new Date(report.submissionDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                       <Badge variant={getStatusVariant(report.status)}>
                           {report.status}
                       </Badge>
                    </TableCell>
                    <TableCell>{report.facultyAdvisorName || 'N/A'}</TableCell>
                    <TableCell className="text-right space-x-1">
                      <Button variant="outline" size="sm" onClick={() => setViewingReport(report)}>View/Review</Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDownloadReport(report)} title="Download Report"><Download className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">No reports found matching your criteria.</p>
          )}
        </CardContent>
      </Card>

      {/* Dialog to view full report and manage status/comments */}
      <Dialog open={!!viewingReport} onOpenChange={() => setViewingReport(null)}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl text-primary">{viewingReport?.reportTitle}</DialogTitle>
            <DialogDescription>
                <span className="block"><UserIcon className="inline h-4 w-4 mr-1" />Student: {viewingReport?.studentName} ({viewingReport?.studentId}) - Major: {viewingReport?.studentMajor || 'N/A'}</span>
                <span className="block"><FileText className="inline h-4 w-4 mr-1" />Internship: {viewingReport?.internshipTitle} at {viewingReport?.companyName}</span>
                <span className="block"><CalendarClock className="inline h-4 w-4 mr-1" />Dates: {viewingReport?.internshipStartDate ? new Date(viewingReport.internshipStartDate).toLocaleDateString() : 'N/A'} - {viewingReport?.internshipEndDate ? new Date(viewingReport.internshipEndDate).toLocaleDateString() : 'N/A'}</span>
                <span className="block"><UserIcon className="inline h-4 w-4 mr-1" />Company Supervisor: {viewingReport?.companySupervisorName || 'N/A'}</span>
            </DialogDescription>
          </DialogHeader>
            <ScrollArea className="max-h-[60vh] p-1 pr-3">
                <div className="space-y-4 py-4">
                    <h3 className="font-semibold text-lg">Introduction</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewingReport?.introduction || "N/A"}</p>
                    
                    <h3 className="font-semibold text-lg">Body</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewingReport?.body || "N/A"}</p>
                    
                    <h3 className="font-semibold text-lg">Student's Evaluation of Company</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{viewingReport?.companyEvaluation || "Not provided"}</p>
                    <p className="text-sm"><strong className="font-medium">Recommends Company:</strong> {viewingReport?.recommendCompany !== undefined ? (viewingReport.recommendCompany ? "Yes" : "No") : 'Not provided'}</p>
                    
                    <h3 className="font-semibold text-lg">Relevant SCAD Courses</h3>
                    <p className="text-sm text-muted-foreground">{viewingReport?.relevantCourses?.join(", ") || "N/A"}</p>
                    
                    {viewingReport?.facultyComments && (
                        <>
                            <h3 className="font-semibold text-lg">Faculty/Office Comments</h3>
                            <p className="text-sm text-muted-foreground p-2 border rounded-md bg-secondary">{viewingReport.facultyComments}</p>
                        </>
                    )}
                    {viewingReport?.appealMessage && (viewingReport.status === "Appealed" || viewingReport.status === "Pending Review" && viewingReport.appealMessage) && (
                       <>
                         <h3 className="font-semibold text-lg text-blue-600">Student Appeal Message</h3>
                         <p className="text-sm text-blue-500 p-2 border border-blue-300 rounded-md bg-blue-50">{viewingReport.appealMessage}</p>
                       </>
                    )}
                </div>
            </ScrollArea>
            <DialogFooter className="pt-6 flex flex-col sm:flex-row gap-2">
                <div className="flex-grow">
                    Current Status: <Badge variant={getStatusVariant(viewingReport?.status || "Draft")}>{viewingReport?.status}</Badge>
                </div>
              <DialogClose asChild><Button type="button" variant="outline">Close</Button></DialogClose>
               {(viewingReport?.status === 'Pending Review' || viewingReport?.status === 'Appealed') && (
                <>
                    <Button variant="default" size="sm" onClick={() => viewingReport && handleOfficeUpdateStatus(viewingReport.id, "Approved")}>
                        <CheckCircle className="mr-1.5 h-4 w-4"/> Approve
                    </Button>
                    <Button variant="outline" className="text-orange-600 border-orange-500 hover:bg-orange-50 hover:text-orange-700" size="sm" onClick={() => viewingReport && openClarificationDialog(viewingReport, "Needs Revision")}>
                        <Edit3 className="mr-1.5 h-4 w-4"/> Mark as Needs Revision
                    </Button>
                     <Button variant="destructive" size="sm" onClick={() => viewingReport && openClarificationDialog(viewingReport, "Rejected")}>
                        <XCircle className="mr-1.5 h-4 w-4"/> Reject Report
                    </Button>
                </>
                )}
            </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clarification Dialog for SCAD Office */}
      <Dialog open={isClarificationDialogOpen} onOpenChange={setIsClarificationDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl text-primary">
              Provide Clarification for {reportForClarification?.reportTitle}
            </DialogTitle>
            <DialogDescription>
              Please detail the reasons for marking this report as '{clarificationAction}'. <br/>
              Student: {reportForClarification?.studentName}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-2">
            <Label htmlFor="scadOfficeClarificationText">Comments / Clarification:</Label>
            <Textarea 
              id="scadOfficeClarificationText"
              value={currentClarificationText}
              onChange={(e) => setCurrentClarificationText(e.target.value)}
              rows={6}
              placeholder="Explain your reasoning clearly. This will override any previous comments if applicable."
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsClarificationDialogOpen(false)}>Cancel</Button>
            <Button onClick={submitClarification}>Submit Clarification</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}

