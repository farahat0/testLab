
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, UserCheck, FileEdit, Download, Mail, Briefcase, GraduationCap, Eye, Search, Filter, Users2, Award } from "lucide-react"; // Added Users2, Award
import { useAuth } from '@/hooks/use-auth';
import type { User as StudentUser, InternshipReport, PastInternship } from "@/types"; 
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge"; // Added Badge import

interface CompanyIntern extends StudentUser {
    internshipTitle: string;
    startDate: string; // ISO Date
    endDate: string; // ISO Date
    status: 'Active' | 'Completed' | 'Terminated';
    evaluationSummary?: string; // Mock field for evaluation by company
    studentReport?: Partial<InternshipReport>; // Include parts of the student's report
}

const mockCompanyInterns: CompanyIntern[] = [
    { 
      id: "student@scad.edu", email: "student@scad.edu", role: 'student', name: "Alex Bee", major: "UX Design", 
      internshipTitle: "Frontend Developer Intern", startDate: "2024-06-01T00:00:00Z", endDate: "2024-08-31T00:00:00Z", 
      status: "Active", evaluationSummary: "Alex is performing well, good grasp of UX principles. Showing great potential in front-end tasks and collaborating effectively with the team.",
      jobInterests: "UX Design, Web Development, Interactive Media",
      collegeActivities: "SCAD UX Club (President), Hackathon Participant (2022)",
      semester: "Semester 5",
      pastInternships: [ { companyName: "Old Startup", jobTitle: "Junior Dev", duration: "Summer 2022", responsibilities: "Fixed bugs" } ],
      studentReport: { 
        reportTitle: "Innovate Corp UX Internship Report",
        introduction: "Summary of my UX design internship experience.",
        body: "Worked on wireframes, user testing, and mockups for various client projects.",
        companyEvaluation: "Innovate Corp offered a great learning environment and supportive mentors.", 
        recommendCompany: true,
        facultyComments: "Good report, well detailed.",
        appealMessage: undefined, 
      }
    },
    { 
      id: "prostudent@scad.edu", email: "prostudent@scad.edu", role: 'student', name: "Casey Dell", major: "Game Development", 
      internshipTitle: "Backend Developer Intern", startDate: "2024-01-15T00:00:00Z", endDate: "2024-05-15T00:00:00Z", 
      status: "Completed", evaluationSummary: "Casey was an excellent intern, quickly learned new tech and contributed significantly to the project's backend architecture.",
      jobInterests: "Game Development, 3D Animation",
      collegeActivities: "SCAD Game Dev Club, SIGGRAPH Volunteer",
      semester: "Semester 7",
      isPro: true,
      pastInternships: [ { companyName: "Indie Games Co.", jobTitle: "QA Tester", duration: "Spring 2022", responsibilities: "Tested game builds" } ],
      studentReport: {
        reportTitle: "PixelPlay Game Dev Internship Report",
        introduction: "An overview of my contributions to the new game title.",
        body: "My role involved developing core gameplay mechanics and integrating AI features.",
        companyEvaluation: "PixelPlay was a fast-paced environment with many opportunities to contribute to real projects.",
        recommendCompany: true,
        facultyComments: "Initially needed more detail, but appeal clarified points.",
        appealMessage: "I believe my contributions were substantial and have added further examples of my work and learning outcomes.",
      }
    },
    { 
      id: "newstudent@scad.edu", email: "newstudent@scad.edu", role: 'student', name: "Jordan River", major: "Film & Television", 
      internshipTitle: "Production Assistant Intern", startDate: "2024-05-01T00:00:00Z", endDate: "2024-07-31T00:00:00Z", 
      status: "Completed", evaluationSummary: "Jordan was diligent and proactive. Good understanding of set protocols.",
      jobInterests: "Film Production, Directing",
      collegeActivities: "SCAD Film Club",
      semester: "Semester 3",
    },
];


export default function CompanyInternsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [interns, setInterns] = useState<CompanyIntern[]>([]);
  const [filteredInterns, setFilteredInterns] = useState<CompanyIntern[]>([]);
  const [viewingProfileIntern, setViewingProfileIntern] = useState<CompanyIntern | null>(null);
  const [evaluatingIntern, setEvaluatingIntern] = useState<CompanyIntern | null>(null);
  const [currentEvaluationText, setCurrentEvaluationText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<'all' | 'Active' | 'Completed' | 'Terminated'>("all");


  useEffect(() => {
    if (user?.role === 'company') {
        setInterns(mockCompanyInterns); 
        setFilteredInterns(mockCompanyInterns);
    }
  }, [user]);

  useEffect(() => {
    let tempFiltered = interns;
    if (searchTerm) {
        tempFiltered = tempFiltered.filter(intern => 
            intern.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            intern.internshipTitle.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    if (filterStatus !== "all") {
        tempFiltered = tempFiltered.filter(intern => intern.status === filterStatus);
    }
    setFilteredInterns(tempFiltered);
  }, [searchTerm, filterStatus, interns]);


  if (user?.role !== 'company') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for companies only.</p>;
  }

  const getInitials = (name?: string) => {
    if (!name) return "U";
    const names = name.split(' ');
    if (names.length > 1) return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    return name.substring(0, 2).toUpperCase();
  };

  const handleDownloadEvaluation = (intern: CompanyIntern) => {
    let reportContent = `
      Intern: ${intern.name} (${intern.email})
      Internship: ${intern.internshipTitle}
      Dates: ${new Date(intern.startDate).toLocaleDateString()} - ${new Date(intern.endDate).toLocaleDateString()}
      Status: ${intern.status}

      Company Evaluation of Intern (Summary):
      ${intern.evaluationSummary || 'No evaluation summary available.'}
    `;

    if (intern.studentReport) {
      reportContent += `

      -------------------------------------
      Student's Internship Report Summary:
      Title: ${intern.studentReport.reportTitle || 'N/A'}
      Introduction: ${intern.studentReport.introduction || 'N/A'}
      Body Summary: ${intern.studentReport.body ? intern.studentReport.body.substring(0,200) + "..." : 'N/A'}

      Student's Evaluation of Company:
      ${intern.studentReport.companyEvaluation || 'N/A'}
      Student Recommends Company: ${intern.studentReport.recommendCompany ? 'Yes' : 'No'}
      
      Faculty Comments on Student's Report:
      ${intern.studentReport.facultyComments || 'N/A'}
      `;
      if (intern.studentReport.appealMessage) {
        reportContent += `
      Student's Appeal Message:
      ${intern.studentReport.appealMessage}
        `;
      }
    } else {
       reportContent += `

      Student's report details not available.
       `;
    }

    const blob = new Blob([reportContent.trim()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${intern.name}_Internship_Summary.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Internship Summary Downloaded", description: "A summary of the intern's records has been downloaded." });
  };

  const openEvaluationDialog = (intern: CompanyIntern) => {
    setEvaluatingIntern(intern);
    setCurrentEvaluationText(intern.evaluationSummary || "");
  };

  const handleSaveEvaluation = () => {
    if (!evaluatingIntern) return;
    
    const updatedInterns = interns.map(i => 
        i.id === evaluatingIntern.id ? { ...i, evaluationSummary: currentEvaluationText } : i
    );
    setInterns(updatedInterns);
        
    const masterIndex = mockCompanyInterns.findIndex(i => i.id === evaluatingIntern.id);
    if (masterIndex !== -1) {
        mockCompanyInterns[masterIndex].evaluationSummary = currentEvaluationText;
    }

    toast({ title: "Evaluation Saved", description: `Evaluation for ${evaluatingIntern.name} has been updated.` });
    setEvaluatingIntern(null);
    setCurrentEvaluationText("");
  };


  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between">
            <div>
                <CardTitle className="text-3xl font-bold text-primary flex items-center">
                    <Users className="mr-3 h-8 w-8" /> Manage Interns
                </CardTitle>
                <CardDescription className="text-lg">
                    View and manage your current and past interns' evaluations and progress.
                </CardDescription>
            </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    placeholder="Search by intern name or job title..." 
                    className="pl-10" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as 'all' | 'Active' | 'Completed' | 'Terminated')}>
                <SelectTrigger><SelectValue placeholder="Filter by Status" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                    <SelectItem value="Terminated">Terminated</SelectItem>
                </SelectContent>
            </Select>
          </div>

           {filteredInterns.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Internship Role</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInterns.map((intern) => (
                  <TableRow key={intern.id}>
                    <TableCell className="font-medium flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                            <AvatarImage src={`https://picsum.photos/seed/${intern.email}/32/32`} alt={intern.name || 'avatar'} data-ai-hint="student avatar" />
                            <AvatarFallback>{getInitials(intern.name)}</AvatarFallback>
                        </Avatar>
                        {intern.name}
                    </TableCell>
                    <TableCell>{intern.internshipTitle}</TableCell>
                    <TableCell>{new Date(intern.startDate).toLocaleDateString()}</TableCell>
                    <TableCell>{new Date(intern.endDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                        <Badge variant={
                          intern.status === 'Active' ? 'secondary' :
                          intern.status === 'Completed' ? 'default' :
                          'destructive'
                        }>
                          {intern.status}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                        <Button variant="outline" size="sm" onClick={() => openEvaluationDialog(intern)}>
                            <FileEdit className="mr-1.5 h-3.5 w-3.5"/> Evaluations
                        </Button>
                         <Button variant="ghost" size="icon" onClick={() => handleDownloadEvaluation(intern)} title="Download Evaluation Summary">
                            <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setViewingProfileIntern(intern)}>
                            <Eye className="mr-1.5 h-3.5 w-3.5"/> View Profile
                        </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">No intern records match your current filters.</p>
          )}
        </CardContent>
      </Card>

      {/* View Student Profile Dialog */}
      {viewingProfileIntern && (
        <Dialog open={!!viewingProfileIntern} onOpenChange={() => setViewingProfileIntern(null)}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader className="mb-4">
              <div className="flex items-center space-x-4">
                <Avatar className="h-20 w-20 border-2 border-primary">
                    <AvatarImage src={`https://picsum.photos/seed/${viewingProfileIntern.email}/80/80`} alt={viewingProfileIntern.name || 'avatar'} data-ai-hint="student avatar large"/>
                    <AvatarFallback className="text-2xl">{getInitials(viewingProfileIntern.name)}</AvatarFallback>
                </Avatar>
                <div>
                    <DialogTitle className="text-3xl font-bold text-primary">{viewingProfileIntern.name || "Student Profile"}</DialogTitle>
                    <DialogDescription className="text-md text-muted-foreground">{viewingProfileIntern.email}</DialogDescription>
                </div>
                {viewingProfileIntern.isPro && <Badge variant="default" className="ml-auto text-sm px-3 py-1 bg-yellow-400 text-yellow-900">PRO</Badge>}
              </div>
            </DialogHeader>
            <ScrollArea className="max-h-[60vh] pr-4">
                <div className="space-y-6">
                    <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/>Current Internship (with You)</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm">
                           <p><strong className="font-medium">Internship Role:</strong> {viewingProfileIntern.internshipTitle}</p>
                           <p><strong className="font-medium">Status with Company:</strong> 
                                <Badge variant={
                                  viewingProfileIntern.status === 'Active' ? 'secondary' :
                                  viewingProfileIntern.status === 'Completed' ? 'default' :
                                  'destructive'
                                } className="ml-1.5">
                                  {viewingProfileIntern.status}
                                </Badge>
                           </p>
                           <p><strong className="font-medium">Start Date:</strong> {new Date(viewingProfileIntern.startDate).toLocaleDateString()}</p>
                           <p><strong className="font-medium">End Date:</strong> {new Date(viewingProfileIntern.endDate).toLocaleDateString()}</p>
                        </div>
                    </section>

                    <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><GraduationCap className="mr-2 h-5 w-5 text-primary"/>Academic Information</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm">
                            <p><strong className="font-medium">Major:</strong> {viewingProfileIntern.major || 'N/A'}</p>
                            <p><strong className="font-medium">Semester:</strong> {viewingProfileIntern.semester || 'N/A'}</p>
                        </div>
                    </section>

                    <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Users2 className="mr-2 h-5 w-5 text-primary"/>Professional Details</h3>
                        <div className="space-y-2 text-sm">
                             <div>
                                <strong className="font-medium">Job Interests:</strong>
                                <p className="text-muted-foreground whitespace-pre-wrap">{viewingProfileIntern.jobInterests || 'Not specified'}</p>
                            </div>
                            <div>
                                <strong className="font-medium">College Activities & Achievements:</strong>
                                <p className="text-muted-foreground whitespace-pre-wrap">{viewingProfileIntern.collegeActivities || 'Not specified'}</p>
                            </div>
                        </div>
                    </section>
                    
                     <section>
                        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/>Past Internships & Work Experience</h3>
                        {viewingProfileIntern.pastInternships && viewingProfileIntern.pastInternships.length > 0 ? (
                            <ul className="space-y-4">
                            {viewingProfileIntern.pastInternships.map((internship: PastInternship, index: number) => (
                                <li key={index} className="p-3 border rounded-md bg-secondary/50 text-sm">
                                <h4 className="font-semibold">{internship.jobTitle} <span className="text-muted-foreground font-normal">at {internship.companyName}</span></h4>
                                <p className="text-xs text-muted-foreground">{internship.duration}</p>
                                <p className="mt-1 text-foreground/80">{internship.responsibilities}</p>
                                </li>
                            ))}
                            </ul>
                        ) : (
                            <p className="text-sm text-muted-foreground">No other past internships or work experience listed by the student.</p>
                        )}
                    </section>


                    {viewingProfileIntern.studentReport && (
                        <section className="pt-4 mt-4 border-t">
                            <h3 className="text-lg font-semibold text-foreground mb-2">Student's Internship Report Summary (with You)</h3>
                            <p className="text-sm"><strong className="font-medium">Title:</strong> {viewingProfileIntern.studentReport.reportTitle || 'N/A'}</p>
                            <p className="text-sm text-muted-foreground line-clamp-3"><strong className="font-medium">Introduction:</strong> {viewingProfileIntern.studentReport.introduction || 'N/A'}</p>
                            <p className="text-sm text-muted-foreground line-clamp-3"><strong className="font-medium">Student's Evaluation of Your Company:</strong> {viewingProfileIntern.studentReport.companyEvaluation || 'N/A'}</p>
                            <p className="text-sm"><strong className="font-medium">Recommended Your Company:</strong> {viewingProfileIntern.studentReport.recommendCompany ? 'Yes' : 'No'}</p>
                        </section>
                    )}
                     <Button variant="link" className="p-0 h-auto text-xs mt-2" onClick={() => toast({title: "Full Profile (Mock)", description:"This would navigate to the student's full public profile if available."})}>
                        View Full Student Public Profile (Mock)
                    </Button>
                </div>
            </ScrollArea>
            <DialogFooter className="mt-6">
              <DialogClose asChild><Button variant="outline">Close</Button></DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Manage Evaluation Dialog */}
      {evaluatingIntern && (
        <Dialog open={!!evaluatingIntern} onOpenChange={() => setEvaluatingIntern(null)}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-2xl text-primary">Intern Evaluation: {evaluatingIntern.name}</DialogTitle>
              <DialogDescription>For internship: {evaluatingIntern.internshipTitle} (Status: {evaluatingIntern.status})</DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-2">
                <Label htmlFor="evaluationSummary">Evaluation Summary & Comments</Label>
                <Textarea 
                    id="evaluationSummary"
                    value={currentEvaluationText}
                    onChange={(e) => setCurrentEvaluationText(e.target.value)}
                    rows={6}
                    placeholder="Provide your overall evaluation, comments on performance, skills, areas for improvement, etc. Clearing this text will remove the evaluation."
                />
                {evaluatingIntern.status !== 'Completed' && (
                    <p className="text-xs text-muted-foreground">Note: This intern is not yet marked as 'Completed'. Formal evaluations are typically for completed internships.</p>
                )}
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
              <Button onClick={handleSaveEvaluation}>Save Evaluation</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

