
"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Search, User, Briefcase, Eye, CheckCircle, XCircle, Download, GraduationCap, Users2 } from "lucide-react";
import { useAuth, MOCK_USERS } from '@/hooks/use-auth';
import type { InternshipApplication, Internship, User as StudentUserType, PastInternship } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from '@/components/ui/scroll-area';

// Mock applications data (would come from backend)
const mockApplicationsForCompany: InternshipApplication[] = [
  { id: "appC1", internshipId: "job1", internshipTitle: "Frontend Developer Intern", companyName: "Tech Solutions Inc.", companyId: "company@example.com", studentId: "student@scad.edu", studentName: "Alex Bee", studentEmail: "student@scad.edu", status: "Pending", appliedDate: "2024-05-25T10:00:00Z", documents: [{ name: "Alex_Bee_Resume.pdf" }, { name: "Alex_Bee_CoverLetter.pdf" }] },
  { id: "appC2", internshipId: "job1", internshipTitle: "Frontend Developer Intern", companyName: "Tech Solutions Inc.", companyId: "company@example.com", studentId: "prostudent@scad.edu", studentName: "Casey Dell", studentEmail: "prostudent@scad.edu", status: "Reviewed", appliedDate: "2024-05-24T11:30:00Z", documents: [{ name: "Casey_Dell_Portfolio.pdf" }] },
  { id: "appC3", internshipId: "job2", internshipTitle: "Backend Developer Intern", companyName: "Tech Solutions Inc.", companyId: "company@example.com", studentId: "another@scad.edu", studentName: "Sam Lee", studentEmail: "another@scad.edu", status: "Interviewing", appliedDate: "2024-05-22T09:00:00Z" },
];

// Mock company's job posts
const mockCompanyJobs: Partial<Internship>[] = [
  { id: "job1", title: "Frontend Developer Intern" },
  { id: "job2", title: "Backend Developer Intern" },
];


export default function CompanyApplicationsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [applications, setApplications] = useState<InternshipApplication[]>([]);
  const [filteredApplications, setFilteredApplications] = useState<InternshipApplication[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedJobId, setSelectedJobId] = useState<string>("all");
  const [selectedApplication, setSelectedApplication] = useState<InternshipApplication | null>(null);
  const [viewingStudentProfile, setViewingStudentProfile] = useState<StudentUserType | null>(null);


  useEffect(() => {
    if (user && user.role === 'company') {
      // Filter applications for the current company
      const companyApps = mockApplicationsForCompany.filter(app => app.companyId === user.id);
      setApplications(companyApps);
      setFilteredApplications(companyApps);
    }
  }, [user]);

  useEffect(() => {
    let tempFiltered = applications;
    if (searchTerm) {
        tempFiltered = tempFiltered.filter(app => 
            app.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            app.internshipTitle.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    if (selectedJobId !== "all") {
        tempFiltered = tempFiltered.filter(app => app.internshipId === selectedJobId);
    }
    setFilteredApplications(tempFiltered);
  }, [searchTerm, selectedJobId, applications]);


  const handleStatusUpdate = (applicationId: string, newStatus: InternshipApplication['status']) => {
    setApplications(prev => prev.map(app => app.id === applicationId ? {...app, status: newStatus} : app));
    toast({title: "Status Updated", description: `Application status changed to ${newStatus}.`});
    if (selectedApplication?.id === applicationId) {
        setSelectedApplication(prev => prev ? {...prev, status: newStatus} : null);
    }
  };

  const handleViewStudentProfile = (studentEmail: string) => {
    const studentData = MOCK_USERS[studentEmail.toLowerCase()] as StudentUserType | undefined;
    if (studentData) {
        setViewingStudentProfile({ ...studentData, id: studentEmail }); // Ensure ID is set
    } else {
        toast({ title: "Student Profile Not Found", description: "Could not find detailed profile for this student.", variant: "destructive" });
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    const names = name.split(' ');
    if (names.length > 1) return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    return name.substring(0, 2).toUpperCase();
  };

  const handleDownloadDocument = (docName: string) => {
    const mockContent = `This is a mock document: ${docName}\n\nGenerated on: ${new Date().toLocaleString()}`;
    const blob = new Blob([mockContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = docName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Mock Document Downloaded",
      description: `${docName} has been downloaded.`,
    });
  };


  if (user?.role !== 'company') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for companies only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <FileText className="mr-3 h-8 w-8" /> Candidate Applications
          </CardTitle>
          <CardDescription className="text-lg">
            Review and manage applications submitted for your internship postings.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    placeholder="Search by applicant name or job title..." 
                    className="pl-10" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <Select value={selectedJobId} onValueChange={setSelectedJobId}>
                <SelectTrigger><SelectValue placeholder="Filter by Job Post" /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Job Posts</SelectItem>
                    {mockCompanyJobs.map(job => (
                        <SelectItem key={job.id} value={job.id!}>{job.title}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>

          {filteredApplications.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead><User className="inline h-4 w-4 mr-1"/>Applicant</TableHead>
                  <TableHead><Briefcase className="inline h-4 w-4 mr-1"/>Job Title</TableHead>
                  <TableHead>Applied Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApplications.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">{app.studentName}</TableCell>
                    <TableCell>{app.internshipTitle}</TableCell>
                    <TableCell>{new Date(app.appliedDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          app.status === 'Accepted' || app.status === 'Offered' ? 'default' : 
                          app.status === 'Rejected' ? 'destructive' : 'secondary'
                        }
                      >
                        {app.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="sm" onClick={() => setSelectedApplication(app)}>
                        <Eye className="mr-1.5 h-3.5 w-3.5" /> View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-10">No applications match your current filters, or no applications received yet.</p>
          )}
        </CardContent>
      </Card>

      {selectedApplication && (
        <Dialog open={!!selectedApplication} onOpenChange={() => setSelectedApplication(null)}>
            <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                    <DialogTitle className="text-2xl text-primary">{selectedApplication.studentName}</DialogTitle>
                    <DialogDescription>Applying for: {selectedApplication.internshipTitle}</DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-3 max-h-[60vh] overflow-y-auto">
                    <p><strong>Email:</strong> {selectedApplication.studentEmail}</p>
                    <p><strong>Applied on:</strong> {new Date(selectedApplication.appliedDate).toLocaleString()}</p>
                    <p><strong>Current Status:</strong> 
                        <Badge 
                            variant={
                            selectedApplication.status === 'Accepted' || selectedApplication.status === 'Offered' ? 'default' : 
                            selectedApplication.status === 'Rejected' ? 'destructive' : 'secondary'
                            }  className="ml-2"
                        >
                            {selectedApplication.status}
                        </Badge>
                    </p>
                    <div>
                        <strong>Documents:</strong>
                        {selectedApplication.documents && selectedApplication.documents.length > 0 ? (
                            <ul className="list-disc list-inside ml-4 mt-1">
                                {selectedApplication.documents.map((doc, idx) => (
                                    <li key={idx}>
                                        <button 
                                            onClick={() => handleDownloadDocument(doc.name)}
                                            className="text-sm text-primary hover:underline cursor-pointer"
                                        >
                                            {doc.name} <Download className="inline h-3 w-3 ml-1"/>
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        ) : <p className="text-sm text-muted-foreground">No documents submitted.</p>}
                    </div>
                    <Button variant="link" className="p-0 h-auto" onClick={() => handleViewStudentProfile(selectedApplication.studentEmail)}>
                        View Student Profile
                    </Button>
                </div>
                <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0">
                    <Select 
                        value={selectedApplication.status} 
                        onValueChange={(newStatus) => handleStatusUpdate(selectedApplication.id, newStatus as InternshipApplication['status'])}
                    >
                        <SelectTrigger className="w-full sm:w-[180px]">
                            <SelectValue placeholder="Update Status" />
                        </SelectTrigger>
                        <SelectContent>
                            {(["Pending", "Reviewed", "Interviewing", "Offered", "Accepted", "Rejected"] as InternshipApplication['status'][]).map(status => (
                                <SelectItem key={status} value={status}>{status}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <DialogClose asChild><Button variant="outline">Close</Button></DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
      )}

    {viewingStudentProfile && (
        <Dialog open={!!viewingStudentProfile} onOpenChange={() => setViewingStudentProfile(null)}>
            <DialogContent className="sm:max-w-2xl">
                 <DialogHeader className="mb-4">
                    <div className="flex items-center space-x-4">
                        <Avatar className="h-20 w-20 border-2 border-primary">
                            <AvatarImage src={`https://picsum.photos/seed/${viewingStudentProfile.email}/80/80`} alt={viewingStudentProfile.name || 'avatar'} data-ai-hint="student avatar large"/>
                            <AvatarFallback className="text-2xl">{getInitials(viewingStudentProfile.name)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <DialogTitle className="text-3xl font-bold text-primary">{viewingStudentProfile.name || "Student Profile"}</DialogTitle>
                            <DialogDescription className="text-md text-muted-foreground">{viewingStudentProfile.email}</DialogDescription>
                        </div>
                        {viewingStudentProfile.isPro && <Badge variant="default" className="ml-auto text-sm px-3 py-1 bg-yellow-400 text-yellow-900">PRO</Badge>}
                    </div>
                </DialogHeader>
                <ScrollArea className="max-h-[60vh] pr-4">
                    <div className="space-y-6">
                        <section>
                            <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><GraduationCap className="mr-2 h-5 w-5 text-primary"/>Academic Information</h3>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm">
                                <p><strong className="font-medium">Major:</strong> {viewingStudentProfile.major || 'N/A'}</p>
                                <p><strong className="font-medium">Semester:</strong> {viewingStudentProfile.semester || 'N/A'}</p>
                            </div>
                        </section>

                        <section>
                            <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Users2 className="mr-2 h-5 w-5 text-primary"/>Professional Details</h3>
                            <div className="space-y-2 text-sm">
                                <div>
                                    <strong className="font-medium">Job Interests:</strong>
                                    <p className="text-muted-foreground whitespace-pre-wrap">{viewingStudentProfile.jobInterests || 'Not specified'}</p>
                                </div>
                                <div>
                                    <strong className="font-medium">College Activities & Achievements:</strong>
                                    <p className="text-muted-foreground whitespace-pre-wrap">{viewingStudentProfile.collegeActivities || 'Not specified'}</p>
                                </div>
                            </div>
                        </section>

                        <section>
                            <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/>Past Internships & Work Experience</h3>
                            {viewingStudentProfile.pastInternships && viewingStudentProfile.pastInternships.length > 0 ? (
                                <ul className="space-y-4">
                                {viewingStudentProfile.pastInternships.map((internship: PastInternship, index: number) => (
                                    <li key={index} className="p-3 border rounded-md bg-secondary/50 text-sm">
                                    <h4 className="font-semibold">{internship.jobTitle} <span className="text-muted-foreground font-normal">at {internship.companyName}</span></h4>
                                    <p className="text-xs text-muted-foreground">{internship.duration}</p>
                                    <p className="mt-1 text-foreground/80">{internship.responsibilities}</p>
                                    </li>
                                ))}
                                </ul>
                            ) : (
                                <p className="text-sm text-muted-foreground">No past internships or work experience listed.</p>
                            )}
                        </section>
                    </div>
                </ScrollArea>
                <DialogFooter className="mt-6">
                    <DialogClose asChild><Button variant="outline">Close</Button></DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )}
    </div>
  );
}

