
"use client";

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, Edit2, Trash2, Briefcase, Search, Filter as FilterIcon } from "lucide-react"; // Renamed Filter to FilterIcon to avoid conflict
import type { Internship, Industry } from '@/types';
import { Industries } from '@/types';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

// Mock data for company's job posts
const mockCompanyJobs: Internship[] = [
  { id: "job1", title: "Frontend Developer Intern", companyId: "c2", companyName: "Tech Solutions Inc.", duration: "4 Months", type: "Paid", salary: "$28/hr", skillsRequired: ["HTML", "CSS", "JavaScript", "React"], jobDescription: "Develop and maintain user interfaces for web applications.", industry: "Technology", postedDate: "2024-05-10T00:00:00Z", applicationsCount: 5, status: "Open", location: "Remote" },
  { id: "job2", title: "Backend Developer Intern", companyId: "c2", companyName: "Tech Solutions Inc.", duration: "6 Months", type: "Paid", salary: "$30/hr", skillsRequired: ["Node.js", "Express", "MongoDB"], jobDescription: "Work on server-side logic and database management.", industry: "Technology", postedDate: "2024-04-20T00:00:00Z", applicationsCount: 12, status: "Open", location: "Savannah, GA" },
  { id: "job3", title: "QA Intern", companyId: "c2", companyName: "Tech Solutions Inc.", duration: "3 Months", type: "Unpaid", skillsRequired: ["Manual Testing", "Bug Reporting"], jobDescription: "Ensure software quality through rigorous testing procedures.", industry: "Technology", postedDate: "2024-03-15T00:00:00Z", applicationsCount: 2, status: "Closed", location: "Remote" },
  { id: "job4", title: "Marketing Intern", companyId: "c2", companyName: "Tech Solutions Inc.", duration: "Summer", type: "Paid", salary: "$20/hr", skillsRequired: ["Social Media", "SEO"], jobDescription: "Assist marketing team.", industry: "Marketing", postedDate: "2024-06-01T00:00:00Z", applicationsCount: 0, status: "Open", location: "Atlanta, GA" },
];

const initialJobFormData: Omit<Internship, 'id' | 'companyId' | 'companyName' | 'companyLogo' | 'applicationsCount' | 'postedDate'> = {
  title: '',
  duration: '',
  type: 'Paid',
  salary: '',
  skillsRequired: [],
  jobDescription: '',
  industry: Industries[0], 
  status: 'Open',
  location: ''
};

export default function CompanyJobsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [jobs, setJobs] = useState<Internship[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<Internship[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<Internship | null>(null);
  const [jobFormData, setJobFormData] = useState(initialJobFormData);
  const [skillsInput, setSkillsInput] = useState('');

  // Search and Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'Open' | 'Closed'>('all');
  const [filterType, setFilterType] = useState<'all' | 'Paid' | 'Unpaid'>('all');
  const [filterIndustry, setFilterIndustry] = useState<Industry | 'all'>('all');

  useEffect(() => {
    if (user && user.role === 'company') {
      const companySpecificJobs = mockCompanyJobs.filter(job => job.companyName === user.name);
      setJobs(companySpecificJobs);
    }
  }, [user]);

  useEffect(() => {
    let tempFiltered = jobs;

    // Apply search term
    if (searchTerm.trim()) {
      tempFiltered = tempFiltered.filter(job =>
        job.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply status filter
    if (filterStatus !== 'all') {
      tempFiltered = tempFiltered.filter(job => job.status === filterStatus);
    }

    // Apply type filter
    if (filterType !== 'all') {
      tempFiltered = tempFiltered.filter(job => job.type === filterType);
    }

    // Apply industry filter
    if (filterIndustry !== 'all') {
      tempFiltered = tempFiltered.filter(job => job.industry === filterIndustry);
    }

    setFilteredJobs(tempFiltered);
  }, [jobs, searchTerm, filterStatus, filterType, filterIndustry]);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setJobFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: keyof Internship, value: string) => {
    setJobFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSkillsChange = () => {
    if (skillsInput.trim() !== "") {
      const newSkills = skillsInput.split(',').map(s => s.trim()).filter(s => s);
      setJobFormData(prev => ({ ...prev, skillsRequired: [...new Set([...prev.skillsRequired, ...newSkills])] }));
      setSkillsInput("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setJobFormData(prev => ({...prev, skillsRequired: prev.skillsRequired.filter(skill => skill !== skillToRemove)}));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const newJobData = {
      ...jobFormData,
      skillsRequired: jobFormData.skillsRequired,
    };

    if (editingJob) {
      const updatedJobs = jobs.map(job => job.id === editingJob.id ? { ...editingJob, ...newJobData } : job);
      setJobs(updatedJobs);
      // Update master mock data
      const masterIndex = mockCompanyJobs.findIndex(j => j.id === editingJob.id);
      if (masterIndex !== -1) mockCompanyJobs[masterIndex] = { ...mockCompanyJobs[masterIndex], ...newJobData };
      toast({ title: "Job Updated", description: `Internship post "${newJobData.title}" has been updated.` });
    } else {
      const newJob: Internship = {
        ...newJobData,
        id: `job${Date.now()}`,
        companyId: user.id, 
        companyName: user.name || "My Company",
        applicationsCount: 0,
        postedDate: new Date().toISOString(),
      };
      setJobs(prev => [newJob, ...prev]);
      mockCompanyJobs.unshift(newJob); // Add to master mock list
      toast({ title: "Job Created", description: `New internship post "${newJob.title}" has been created.` });
    }
    setIsDialogOpen(false);
    setEditingJob(null);
    setJobFormData(initialJobFormData);
    setSkillsInput('');
  };

  const openEditDialog = (job: Internship) => {
    setEditingJob(job);
    setJobFormData({
      title: job.title,
      duration: job.duration,
      type: job.type,
      salary: job.salary || '',
      skillsRequired: job.skillsRequired,
      jobDescription: job.jobDescription,
      industry: job.industry,
      status: job.status || 'Open',
      location: job.location || '',
    });
    setSkillsInput(job.skillsRequired.join(', '));
    setIsDialogOpen(true);
  };
  
  const openCreateDialog = () => {
    setEditingJob(null);
    setJobFormData(initialJobFormData);
    setSkillsInput('');
    setIsDialogOpen(true);
  };

  const handleDeleteJob = (jobId: string) => {
    if (window.confirm("Are you sure you want to delete this job post? This action cannot be undone.")) {
      setJobs(jobs.filter(job => job.id !== jobId));
      const masterIndex = mockCompanyJobs.findIndex(j => j.id === jobId);
      if (masterIndex !== -1) mockCompanyJobs.splice(masterIndex, 1);
      toast({ title: "Job Deleted", description: "The internship post has been removed.", variant: "destructive" });
    }
  };

  const handleApplyFilters = () => {
    // Filtering is done via useEffect, just close dialog
    setIsFilterDialogOpen(false);
  };

  const handleClearFilters = () => {
    setFilterStatus('all');
    setFilterType('all');
    setFilterIndustry('all');
    setIsFilterDialogOpen(false);
  };

  if (user?.role !== 'company') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for companies only.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="shadow-lg border-primary/10">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-3xl font-bold text-primary flex items-center">
              <Briefcase className="mr-3 h-8 w-8" /> Manage Internship Posts
            </CardTitle>
            <CardDescription className="text-lg">Create, view, and manage your company's internship listings.</CardDescription>
          </div>
          <Button onClick={openCreateDialog}>
            <PlusCircle className="mr-2 h-5 w-5" /> Create New Job Post
          </Button>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6 p-4 border rounded-lg bg-secondary/30">
            <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                    placeholder="Search job titles..." 
                    className="pl-10" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <Button variant="outline" onClick={() => setIsFilterDialogOpen(true)}>
                <FilterIcon className="mr-2 h-4 w-4" /> Filter
            </Button>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Applications</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredJobs.length > 0 ? filteredJobs.map((job) => (
                <TableRow key={job.id}>
                  <TableCell className="font-medium">{job.title}</TableCell>
                  <TableCell>{job.duration}</TableCell>
                  <TableCell>{job.type} {job.type === "Paid" && job.salary ? `(${job.salary})` : ''}</TableCell>
                  <TableCell><Badge variant={job.status === 'Open' ? 'default' : 'secondary'}>{job.status}</Badge></TableCell>
                  <TableCell>{job.applicationsCount}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => openEditDialog(job)}>
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDeleteJob(job.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center h-24">No job posts match your criteria. Create one or adjust filters!</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Job Creation/Editing Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{editingJob ? 'Edit Internship Post' : 'Create New Internship Post'}</DialogTitle>
            <DialogDescription>
              {editingJob ? 'Update the details for your internship listing.' : 'Fill in the details for the new internship opportunity.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
            <div>
              <Label htmlFor="title">Job Title</Label>
              <Input id="title" name="title" value={jobFormData.title} onChange={handleInputChange} required />
            </div>
            <div>
              <Label htmlFor="jobDescription">Job Description</Label>
              <Textarea id="jobDescription" name="jobDescription" value={jobFormData.jobDescription} onChange={handleInputChange} rows={5} required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="duration">Duration (e.g., 3 Months, Summer 2024)</Label>
                <Input id="duration" name="duration" value={jobFormData.duration} onChange={handleInputChange} required />
              </div>
              <div>
                <Label htmlFor="location">Location (e.g., Remote, Savannah, GA)</Label>
                <Input id="location" name="location" value={jobFormData.location || ''} onChange={handleInputChange} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="type">Type</Label>
                <Select name="type" value={jobFormData.type} onValueChange={(value) => handleSelectChange('type', value as 'Paid' | 'Unpaid')}>
                  <SelectTrigger id="type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Paid">Paid</SelectItem>
                    <SelectItem value="Unpaid">Unpaid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {jobFormData.type === 'Paid' && (
                <div>
                  <Label htmlFor="salary">Salary (if paid, e.g., $20/hr, $3000/month)</Label>
                  <Input id="salary" name="salary" value={jobFormData.salary} onChange={handleInputChange} />
                </div>
              )}
            </div>
            <div>
              <Label htmlFor="industry">Industry</Label>
              <Select name="industry" value={jobFormData.industry} onValueChange={(value) => handleSelectChange('industry', value as Industry)}>
                <SelectTrigger id="industry"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Industries.map(ind => <SelectItem key={ind} value={ind}>{ind}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
             <div>
                <Label htmlFor="skillsInput">Skills Required (comma-separated or add one by one)</Label>
                <div className="flex gap-2">
                    <Input 
                        id="skillsInput" 
                        value={skillsInput} 
                        onChange={(e) => setSkillsInput(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); handleSkillsChange();}}}
                    />
                    <Button type="button" onClick={handleSkillsChange} variant="outline">Add Skill</Button>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                    {jobFormData.skillsRequired.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="flex items-center gap-1">
                            {skill}
                            <button type="button" onClick={() => removeSkill(skill)} className="ml-1 text-destructive hover:text-destructive-foreground">
                                <Trash2 className="h-3 w-3"/>
                            </button>
                        </Badge>
                    ))}
                </div>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select name="status" value={jobFormData.status} onValueChange={(value) => handleSelectChange('status', value as 'Open' | 'Closed')}>
                <SelectTrigger id="status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Open">Open (Accepting Applications)</SelectItem>
                  <SelectItem value="Closed">Closed (Not Accepting Applications)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter className="pt-4">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit">{editingJob ? 'Save Changes' : 'Create Post'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Filter Dialog */}
      <Dialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl">Filter Job Posts</DialogTitle>
            <DialogDescription>
              Apply filters to narrow down the list of internship posts.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="filter-status">Status</Label>
              <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as 'all' | 'Open' | 'Closed')}>
                <SelectTrigger id="filter-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="Closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filter-type">Payment Type</Label>
              <Select value={filterType} onValueChange={(value) => setFilterType(value as 'all' | 'Paid' | 'Unpaid')}>
                <SelectTrigger id="filter-type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                  <SelectItem value="Unpaid">Unpaid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filter-industry">Industry</Label>
              <Select value={filterIndustry} onValueChange={(value) => setFilterIndustry(value as Industry | 'all')}>
                <SelectTrigger id="filter-industry"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  {Industries.map(ind => <SelectItem key={ind} value={ind}>{ind}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={handleClearFilters}>Clear Filters</Button>
            <DialogClose asChild><Button type="button" variant="secondary">Cancel</Button></DialogClose>
            <Button type="button" onClick={handleApplyFilters}>Apply Filters</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

