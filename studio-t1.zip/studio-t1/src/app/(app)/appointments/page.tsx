
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, CalendarPlus, History, Crown, Phone, Trash2, PhoneIncoming, PhoneOff as PhoneReject, Star, UserCircle2 } from "lucide-react"; 
import { useAuth } from '@/hooks/use-auth';
import type { Appointment, AppointmentType } from "@/types";
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { VideoCallUI } from '@/components/feature/video-call-ui'; 

const appointmentTypes: AppointmentType[] = ["Career Counseling", "Report Clarification", "Resume Review", "Mock Interview", "Other"];

const appointmentRequestSchema = z.object({
  type: z.enum(appointmentTypes, { required_error: "Appointment type is required." }),
  preferredDate: z.string().refine((date) => !!date && !isNaN(Date.parse(date)), { message: "Valid preferred date is required." }),
  preferredTime: z.string().min(1, "Preferred time is required (e.g., 10:00 AM)."),
  advisorName: z.string().optional(),
  reason: z.string().min(10, "Please provide a brief reason (min 10 characters).").max(500, "Reason cannot exceed 500 characters."),
});

type AppointmentRequestFormData = z.infer<typeof appointmentRequestSchema>;

// Mock data - defined at module level for persistence across re-renders in this mock setup
const mockStudentAppointments: Appointment[] = [
    { id: "appt1", studentId: "student@scad.edu", studentName: "Alex Bee", advisorName: "Dr. Emily Carter", type: "Resume Review", date: "2024-09-10T00:00:00Z", time: "11:00 AM", status: "Scheduled", isOnline: true },
    { id: "appt2", studentId: "student@scad.edu", studentName: "Alex Bee", advisorName: "Mr. John Davis", type: "Career Counseling", date: "2024-08-20T00:00:00Z", time: "2:30 PM", status: "Completed", notes: "Discussed UX portfolio strategies." },
    { id: "appt3", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Emily Carter", type: "Mock Interview", date: "2024-09-05T00:00:00Z", time: "9:00 AM", status: "Scheduled", isOnline: false },
    { id: "apptPro1", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Ms. Jane Smith", type: "Career Counseling", date: "2024-09-25T00:00:00Z", time: "10:00 AM", status: "Scheduled", notes: "Follow-up on career path options for game dev.", isOnline: true },
    { id: "apptPro2", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Mr. John Davis", type: "Report Clarification", date: "2024-09-28T00:00:00Z", time: "3:00 PM", status: "Pending Confirmation", notes: "Need to discuss feedback on recent internship report.", isOnline: true },
    { id: "apptPro3", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Emily Carter", type: "Resume Review", date: "2024-10-02T00:00:00Z", time: "1:30 PM", status: "Scheduled", isOnline: false },
    { id: "apptPro4", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Anya Sharma", type: "Career Counseling", date: "2024-10-05T00:00:00Z", time: "11:00 AM", status: "Pending Confirmation", notes: "Pro student seeking advanced portfolio review.", isOnline: true },
    { id: "apptPro5", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Mr. Ben Miller", type: "Mock Interview", date: "2024-10-08T00:00:00Z", time: "02:00 PM", status: "Scheduled", isOnline: false },
    { id: "apptPro6", studentId: "prostudent@scad.edu", studentName: "Casey Dell", advisorName: "Dr. Test Advisor", type: "Other", date: "2024-10-15T00:00:00Z", time: "11:00 AM", status: "Scheduled", notes: "Discussing advanced industry topics.", isOnline: true },
];

interface ActiveCallInfo {
  appointmentId: string;
  participantName: string;
  isIncoming: boolean;
}

export default function AppointmentsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false);
  const [activeCall, setActiveCall] = useState<ActiveCallInfo | null>(null); 
  const [simulatedIncomingCall, setSimulatedIncomingCall] = useState<Appointment | null>(null);


  const form = useForm<AppointmentRequestFormData>({
    resolver: zodResolver(appointmentRequestSchema),
    defaultValues: {
      type: "Career Counseling",
      preferredDate: new Date().toISOString().split('T')[0], 
      preferredTime: "10:00 AM",
      advisorName: "",
      reason: "",
    },
  });

  useEffect(() => {
    if (user?.role === 'student') {
        setAppointments(mockStudentAppointments.filter(appt => appt.studentId === user.id));
        
        if (user.isPro) {
            const scheduledProAppointment = mockStudentAppointments.find(
                appt => appt.studentId === user.id && appt.status === "Scheduled" && appt.isOnline && appt.id !== activeCall?.appointmentId && !simulatedIncomingCall
            );
            if (scheduledProAppointment) {
                const timer = setTimeout(() => {
                    setSimulatedIncomingCall(scheduledProAppointment);
                    toast({
                        title: "Incoming Call",
                        description: `Incoming call from ${scheduledProAppointment.advisorName} for ${scheduledProAppointment.type}.`,
                        duration: 10000, 
                        action: (
                            <div className="flex gap-2">
                                <Button size="sm" onClick={() => handleAcceptCall(scheduledProAppointment)} className="bg-green-500 hover:bg-green-600">Accept</Button>
                                <Button size="sm" variant="outline" onClick={() => handleRejectCall(scheduledProAppointment)}>Reject</Button>
                            </div>
                        )
                    });
                }, 7000); 
                return () => clearTimeout(timer);
            }
        }
    }
  }, [user, activeCall, simulatedIncomingCall, toast]); 


  const onSubmitAppointmentRequest = (data: AppointmentRequestFormData) => {
    if (!user || !user.isPro) {
        toast({ title: "Error", description: "Only Pro students can schedule appointments.", variant: "destructive" });
        return;
    }

    const newAppointmentRequest: Appointment = {
      id: `apptReq-${Date.now()}`,
      studentId: user.id,
      studentName: user.name || "Student",
      type: data.type,
      date: new Date(data.preferredDate).toISOString(),
      time: data.preferredTime,
      advisorName: data.advisorName,
      notes: data.reason,
      status: "Pending Confirmation",
      isOnline: Math.random() > 0.5 
    };

    mockStudentAppointments.push(newAppointmentRequest);
    setAppointments(prev => [...prev, newAppointmentRequest].filter(appt => appt.studentId === user.id));
    
    toast({ title: "Appointment Requested", description: "Your request has been submitted. You'll be notified upon confirmation." });
    setIsScheduleDialogOpen(false);
    form.reset();
  };

  const handleCancelAppointment = (appointmentId: string) => {
    const apptIndex = mockStudentAppointments.findIndex(a => a.id === appointmentId && a.studentId === user?.id);
    if (apptIndex !== -1 && mockStudentAppointments[apptIndex].status !== 'Completed' && mockStudentAppointments[apptIndex].status !== 'Cancelled') {
        mockStudentAppointments[apptIndex].status = "Cancelled";
        setAppointments(mockStudentAppointments.filter(appt => appt.studentId === user.id));
        toast({ title: "Appointment Cancelled", description: "The appointment has been cancelled." });
    } else {
        toast({ title: "Error", description: "Could not cancel appointment or it's already completed/cancelled.", variant: "destructive"});
    }
  };

  const handleJoinCall = (appointment: Appointment) => {
    if (activeCall) {
        toast({ title: "Already in a call", description: "Please leave your current call before joining another.", variant: "destructive"});
        return;
    }
    if (!appointment.isOnline) {
        toast({ title: "Offline Appointment", description: "This is an in-person appointment. No online call to join.", variant: "default"});
        return;
    }
    setActiveCall({ 
      appointmentId: appointment.id, 
      participantName: appointment.advisorName || "Advisor",
      isIncoming: false 
    });
    setSimulatedIncomingCall(null); 
  };

  const handleAcceptCall = (appointment: Appointment) => {
     if (activeCall) {
        toast({ title: "Already in a call", description: "Please leave your current call before accepting another.", variant: "destructive"});
        return;
    }
     setActiveCall({
        appointmentId: appointment.id,
        participantName: appointment.advisorName || "Advisor",
        isIncoming: true, 
     });
     setSimulatedIncomingCall(null);
     toast({ title: "Call Accepted", description: `Connecting to ${appointment.advisorName}...`});
  };

  const handleRejectCall = (appointment: Appointment) => {
    setSimulatedIncomingCall(null); 
    toast({ title: "Call Rejected", description: `You rejected the call from ${appointment.advisorName}.`, variant: "default" });
  };

  const handleLeaveCall = () => {
    if(activeCall) {
        const participant = activeCall.participantName;
        toast({ title: "Call Ended", description: `You left the call with ${participant}.` });
    }
    setActiveCall(null);
  };

  const handleParticipantJoined = () => {
    if (activeCall) {
      toast({ title: "Advisor Joined", description: `${activeCall.participantName} has joined the call.` });
    }
  };

  const handleParticipantLeft = () => {
    if (activeCall) {
      toast({ title: "Advisor Left", description: `${activeCall.participantName} has left the call. Ending session.` });
      setActiveCall(null); // End the call locally
    }
  };

  if (user?.role === 'student' && !user.isPro) {
    return (
      <div className="container mx-auto py-12 flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Card className="w-full max-w-lg p-8 shadow-xl text-center bg-card">
          <CardHeader className="p-0 mb-6">
            <Crown className="h-20 w-20 mx-auto text-primary mb-6" />
            <CardTitle className="text-3xl font-bold text-foreground">Pro Feature Locked</CardTitle>
            <CardDescription className="text-xl mt-3 text-muted-foreground">
              Access to <span className="font-semibold text-primary">My Appointments</span> is exclusive to SCAD InternLink Pro students.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0 mb-8">
            <p className="text-foreground/90">
              Upgrade your account to unlock this feature and many more, including advanced career tools, personalized feedback, and priority access to workshops and appointments.
            </p>
          </CardContent>
          <Button size="lg" className="w-full text-lg py-3">
            Upgrade to Pro (Mock Action)
          </Button>
        </Card>
      </div>
    );
  }

  if (user?.role !== 'student') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for students only.</p>;
  }
  
  if (activeCall) {
    return <VideoCallUI 
        participantName={activeCall.participantName} 
        onLeaveCall={handleLeaveCall} 
        isCallCreator={!activeCall.isIncoming}
        onParticipantJoin={handleParticipantJoined}
        onParticipantLeave={handleParticipantLeft}
      />;
  }
  
  const upcomingAppointments = appointments.filter(a => a.status === "Scheduled" || a.status === "Pending Confirmation");
  const pastAppointments = appointments.filter(a => a.status === "Completed" || a.status === "Cancelled");


  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-3xl font-bold text-primary flex items-center">
              <Video className="mr-3 h-8 w-8" /> My Appointments
               {user.isPro && <Badge className="ml-3 bg-yellow-400 text-yellow-900 hover:bg-yellow-500"><Star className="h-4 w-4 mr-1"/>PRO</Badge>}
            </CardTitle>
            <CardDescription className="text-lg">
              Schedule and manage your appointments with career advisors.
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
                <DialogTrigger asChild>
                    <Button disabled={!user.isPro}>
                        <CalendarPlus className="mr-2 h-5 w-5" /> Schedule New Appointment
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle className="text-2xl text-primary">Request New Appointment</DialogTitle>
                        <DialogDescription>Fill in the details below to request an appointment. You will be notified upon confirmation.</DialogDescription>
                    </DialogHeader>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmitAppointmentRequest)} className="space-y-4 py-4">
                            <FormField
                                control={form.control}
                                name="type"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Appointment Type*</FormLabel>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                            <FormControl>
                                                <SelectTrigger><SelectValue placeholder="Select appointment type" /></SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {appointmentTypes.map(type => (
                                                    <SelectItem key={type} value={type}>{type}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <div className="grid grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="preferredDate"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Preferred Date*</FormLabel>
                                            <FormControl><Input type="date" {...field} min={new Date().toISOString().split("T")[0]} /></FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="preferredTime"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Preferred Time*</FormLabel>
                                            <FormControl><Input placeholder="e.g., 2:00 PM" {...field} /></FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                             <FormField
                                control={form.control}
                                name="advisorName"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Preferred Advisor (Optional)</FormLabel>
                                        <FormControl><Input placeholder="e.g., Dr. Emily Carter" {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={form.control}
                                name="reason"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Reason for Appointment*</FormLabel>
                                        <FormControl><Textarea placeholder="Briefly explain the purpose of your appointment..." rows={4} {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter className="pt-4">
                                <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
                                <Button type="submit" disabled={form.formState.isSubmitting}>Request Appointment</Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4 text-foreground">Upcoming & Pending Appointments</h2>
           {upcomingAppointments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Advisor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {upcomingAppointments.map((appt) => (
                  <TableRow key={appt.id}>
                    <TableCell>{new Date(appt.date).toLocaleDateString()}</TableCell>
                    <TableCell>{appt.time}</TableCell>
                    <TableCell className="font-medium">{appt.type}</TableCell>
                    <TableCell>
                        <div className="flex items-center">
                           <UserCircle2 className="h-4 w-4 mr-1.5 text-muted-foreground" />
                            {appt.advisorName || 'N/A'}
                            {(appt.status === "Scheduled" || appt.status === "Pending Confirmation") && appt.isOnline !== undefined && (
                              <span
                                className={`ml-2 h-2.5 w-2.5 rounded-full ${appt.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}
                                title={appt.isOnline ? 'Online Appointment' : 'Offline/In-person Appointment'}
                              />
                            )}
                        </div>
                    </TableCell>
                    <TableCell>
                        <Badge variant={
                            appt.status === 'Scheduled' ? 'default' :
                            appt.status === 'Pending Confirmation' ? 'secondary' :
                            'outline'
                        }>
                            {appt.status}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      {simulatedIncomingCall && simulatedIncomingCall.id === appt.id && appt.isOnline ? (
                          <>
                            <Button variant="default" size="sm" onClick={() => handleAcceptCall(appt)} className="bg-green-500 hover:bg-green-600">
                                <PhoneIncoming className="mr-1.5 h-4 w-4" /> Accept
                            </Button>
                            <Button variant="destructive" size="sm" onClick={() => handleRejectCall(appt)}>
                                <PhoneReject className="mr-1.5 h-4 w-4" /> Reject
                            </Button>
                          </>
                      ) : appt.status === "Scheduled" && appt.isOnline ? (
                        <>
                          <Button variant="default" size="sm" onClick={() => handleJoinCall(appt)}>
                            <Phone className="mr-1.5 h-4 w-4" /> Join Call
                          </Button>
                          {/* <Button variant="outline" size="sm">Reschedule</Button> */}
                        </>
                      ) : appt.status === "Scheduled" && !appt.isOnline ? (
                         <Badge variant="outline">In-Person</Badge>
                      ) : null}
                      {(appt.status === "Scheduled" || appt.status === "Pending Confirmation") && (!simulatedIncomingCall || simulatedIncomingCall.id !== appt.id) && (
                        <Button variant="destructive" size="sm" onClick={() => handleCancelAppointment(appt.id)}>
                          <Trash2 className="mr-1.5 h-4 w-4" /> Cancel
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-6">You have no upcoming or pending appointments.</p>
          )}

          <h2 className="text-xl font-semibold mb-4 mt-8 text-foreground">Past Appointments</h2>
           {pastAppointments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Advisor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pastAppointments.map((appt) => (
                  <TableRow key={appt.id}>
                    <TableCell>{new Date(appt.date).toLocaleDateString()}</TableCell>
                    <TableCell>{appt.time}</TableCell>
                    <TableCell className="font-medium">{appt.type}</TableCell>
                    <TableCell>{appt.advisorName || 'N/A'}</TableCell>
                    <TableCell>
                        <Badge variant={ appt.status === 'Completed' ? 'secondary' : 'destructive'}>
                            {appt.status}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                       <Button variant="ghost" size="sm" onClick={() => toast({title: "View Notes (Mock)", description: `Notes for ${appt.type} with ${appt.advisorName}: ${appt.notes || "No notes available."}`})}>View Notes</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-muted-foreground py-6">You have no past appointments.</p>
          )}

        </CardContent>
      </Card>
    </div>
  );
}

