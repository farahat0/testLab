// src/app/(app)/profile/page.tsx
"use client";

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import type { PastInternship, Major, StudentAssessment } from '@/types';
import { Majors, Semesters } from '@/types';
import { Save, PlusCircle, Trash2, Crown, Eye, CheckSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

// Mock data for assessments - ideally this would come from a context or backend
const mockStudentAssessmentsForAllUsers: StudentAssessment[] = [
    { id: "assess1", studentId: "student@scad.edu", assessmentName: "UX Design Principles", status: "Completed", score: 85, completedDate: "2024-03-10T00:00:00Z", feedback: "Good understanding of core concepts.", postedToProfile: true },
    { id: "assess2", studentId: "student@scad.edu", assessmentName: "Frontend Development Basics", status: "In Progress", score: undefined, completedDate: undefined, postedToProfile: false },
    { id: "assessPro1", studentId: "prostudent@scad.edu", assessmentName: "Advanced Game Mechanics", status: "Completed", score: 92, completedDate: "2024-04-01T00:00:00Z", postedToProfile: true },
    { id: "assessPro2", studentId: "prostudent@scad.edu", assessmentName: "Character Design Fundamentals", status: "Not Started", score: undefined, completedDate: undefined, postedToProfile: false },
    { id: "assessPro3", studentId: "prostudent@scad.edu", assessmentName: "Advanced Shading Techniques", status: "Completed", score: 88, completedDate: "2024-05-10T00:00:00Z", feedback: "Excellent control of light and shadow.", postedToProfile: false }, // Not posted
    { id: "assessPro4", studentId: "prostudent@scad.edu", assessmentName: "Storyboarding Essentials", status: "Completed", score: 75, completedDate: "2024-06-01T00:00:00Z", feedback: "Good sequencing.", postedToProfile: true },
];


export default function ProfilePage() {
  const { user, loading: authLoading, updateUserProfile } = useAuth();
  const { toast } = useToast();

  const [name, setName] = useState('');
  const [jobInterests, setJobInterests] = useState('');
  const [collegeActivities, setCollegeActivities] = useState('');
  const [major, setMajor] = useState<Major | ''>('');
  const [semester, setSemester] = useState('');
  const [pastInternships, setPastInternships] = useState<PastInternship[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [postedAssessments, setPostedAssessments] = useState<StudentAssessment[]>([]);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setJobInterests(user.jobInterests || '');
      setCollegeActivities(user.collegeActivities || '');
      setMajor((user.major as Major) || '');
      setSemester(user.semester || '');
      setPastInternships(user.pastInternships || []);

      if (user.isPro) {
        const userAssessments = mockStudentAssessmentsForAllUsers.filter(
          assessment => assessment.studentId === user.id && assessment.status === "Completed" && assessment.postedToProfile === true
        );
        setPostedAssessments(userAssessments);
      }
    }
  }, [user]);

  const handleAddInternship = () => {
    setPastInternships([...pastInternships, { companyName: '', jobTitle: '', responsibilities: '', duration: '' }]);
  };

  const handleRemoveInternship = (index: number) => {
    setPastInternships(pastInternships.filter((_, i) => i !== index));
  };

  const handleInternshipChange = (index: number, field: keyof PastInternship, value: string) => {
    const updatedInternships = [...pastInternships];
    updatedInternships[index] = { ...updatedInternships[index], [field]: value };
    setPastInternships(updatedInternships);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const success = await updateUserProfile({
        name,
        jobInterests,
        collegeActivities,
        major: major as Major,
        semester,
        pastInternships,
    });
    
    if (success) {
      toast({
        title: "Profile Updated",
        description: "Your profile information has been saved.",
      });
      setIsEditing(false);
    } else {
       toast({
        title: "Update Failed",
        description: "Could not update your profile. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (authLoading) {
    return <p className="text-center py-10">Loading profile...</p>;
  }

  if (!user) {
    return <p className="text-center py-10 text-destructive">User not found. Please log in.</p>;
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <Card className="shadow-xl border-primary/20">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-3xl font-bold text-primary">My Profile</CardTitle>
            <Button onClick={() => setIsEditing(!isEditing)} variant={isEditing ? "destructive" : "outline"}>
              {isEditing ? "Cancel Editing" : "Edit Profile"}
            </Button>
          </div>
          <CardDescription>View and update your personal and professional information.</CardDescription>
        </CardHeader>
      </Card>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} disabled={!isEditing} />
              </div>
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" value={user.email} disabled />
                <p className="text-xs text-muted-foreground mt-1">Email cannot be changed.</p>
              </div>
              <div>
                <Label htmlFor="role">Role</Label>
                <Input id="role" value={user.role.replace("_", " ").toUpperCase()} disabled />
                {user.isPro && <Badge className="mt-2 bg-yellow-400 text-yellow-900 hover:bg-yellow-500"><Crown className="mr-1 h-3 w-3"/>PRO Member</Badge>}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Academic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="major">Major</Label>
                <Select value={major} onValueChange={(value) => setMajor(value as Major)} disabled={!isEditing}>
                  <SelectTrigger id="major">
                    <SelectValue placeholder="Select your major" />
                  </SelectTrigger>
                  <SelectContent>
                    {Majors.map((m) => (
                      <SelectItem key={m} value={m}>{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="semester">Current Semester</Label>
                <Select value={semester} onValueChange={setSemester} disabled={!isEditing}>
                  <SelectTrigger id="semester">
                    <SelectValue placeholder="Select your semester" />
                  </SelectTrigger>
                  <SelectContent>
                    {Semesters.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="text-xl">Professional Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="jobInterests">Job Interests</Label>
              <Textarea id="jobInterests" placeholder="Describe your career goals, preferred industries, and types of roles you're interested in..." value={jobInterests} onChange={(e) => setJobInterests(e.target.value)} rows={4} disabled={!isEditing} />
            </div>
            <div>
              <Label htmlFor="collegeActivities">College Activities & Achievements</Label>
              <Textarea id="collegeActivities" placeholder="List any relevant college activities, clubs, projects, or achievements..." value={collegeActivities} onChange={(e) => setCollegeActivities(e.target.value)} rows={4} disabled={!isEditing} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="mt-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-xl">Past Internships & Work Experience</CardTitle>
              {isEditing && (
                <Button type="button" variant="outline" size="sm" onClick={handleAddInternship}>
                  <PlusCircle className="mr-2 h-4 w-4" /> Add Experience
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {pastInternships.length === 0 && !isEditing && <p className="text-muted-foreground">No past internships or work experience added yet.</p>}
            {pastInternships.map((internship, index) => (
              <div key={index} className="p-4 border rounded-md space-y-3 relative bg-secondary/30">
                {isEditing && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 text-destructive hover:bg-destructive/10"
                    onClick={() => handleRemoveInternship(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
                <div>
                  <Label htmlFor={`companyName-${index}`}>Company Name</Label>
                  <Input id={`companyName-${index}`} value={internship.companyName} onChange={(e) => handleInternshipChange(index, 'companyName', e.target.value)} disabled={!isEditing} />
                </div>
                <div>
                  <Label htmlFor={`jobTitle-${index}`}>Job Title</Label>
                  <Input id={`jobTitle-${index}`} value={internship.jobTitle} onChange={(e) => handleInternshipChange(index, 'jobTitle', e.target.value)} disabled={!isEditing} />
                </div>
                <div>
                  <Label htmlFor={`duration-${index}`}>Duration (e.g., May 2023 - Aug 2023)</Label>
                  <Input id={`duration-${index}`} value={internship.duration} onChange={(e) => handleInternshipChange(index, 'duration', e.target.value)} disabled={!isEditing} />
                </div>
                <div>
                  <Label htmlFor={`responsibilities-${index}`}>Responsibilities</Label>
                  <Textarea id={`responsibilities-${index}`} value={internship.responsibilities} onChange={(e) => handleInternshipChange(index, 'responsibilities', e.target.value)} rows={3} disabled={!isEditing} />
                </div>
              </div>
            ))}
            {pastInternships.length === 0 && isEditing && <p className="text-muted-foreground">Click "Add Experience" to list your past roles.</p>}
          </CardContent>
        </Card>

        {user.isPro && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="text-xl flex items-center">
                <Eye className="mr-2 h-5 w-5 text-primary" />
                Profile Views
                <Crown className="ml-2 h-5 w-5 text-yellow-400" />
              </CardTitle>
              <CardDescription>Companies that have recently viewed your profile.</CardDescription>
            </CardHeader>
            <CardContent>
              {user.profileViewedBy && user.profileViewedBy.length > 0 ? (
                <ul className="space-y-2">
                  {user.profileViewedBy.map((companyName, index) => (
                    <li key={index} className="p-3 border rounded-md bg-secondary/30">
                      <span className="font-medium">{companyName}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted-foreground">Your profile hasn't been viewed by any companies yet. Make sure your profile is complete and up-to-date!</p>
              )}
            </CardContent>
          </Card>
        )}

        {user.isPro && postedAssessments.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="text-xl flex items-center">
                <CheckSquare className="mr-2 h-5 w-5 text-primary" />
                Posted Assessment Scores
                <Crown className="ml-2 h-5 w-5 text-yellow-400" />
              </CardTitle>
              <CardDescription>Your assessment scores visible on your public profile.</CardDescription>
            </CardHeader>
            <CardContent>
                <ul className="space-y-3">
                  {postedAssessments.map((assessment) => (
                    <li key={assessment.id} className="p-3 border rounded-md bg-secondary/30 flex justify-between items-center">
                      <span className="font-medium">{assessment.assessmentName}</span>
                      <Badge variant="default" className="text-base">{assessment.score}%</Badge>
                    </li>
                  ))}
                </ul>
            </CardContent>
          </Card>
        )}


        {isEditing && (
          <CardFooter className="mt-8 justify-end">
            <Button type="submit" size="lg">
              <Save className="mr-2 h-5 w-5" /> Save Changes
            </Button>
          </CardFooter>
        )}
      </form>
    </div>
  );
}
