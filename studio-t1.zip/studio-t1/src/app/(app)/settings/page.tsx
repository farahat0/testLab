
// src/app/(app)/settings/page.tsx
"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SettingsPage() {
  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Application settings will be displayed here.</p>
          {/* Theme switcher, notification preferences, etc. */}
        </CardContent>
      </Card>
    </div>
  );
}
