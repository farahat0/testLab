
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ListChecks, PlayCircle, Crown, CheckCircle, Eye } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import type { StudentAssessment } from "@/types";
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";


const mockStudentAssessments: StudentAssessment[] = [
    { id: "assess1", studentId: "student@scad.edu", assessmentName: "UX Design Principles", status: "Completed", score: 85, completedDate: "2024-03-10T00:00:00Z", feedback: "Good understanding of core concepts.", postedToProfile: true },
    { id: "assess2", studentId: "student@scad.edu", assessmentName: "Frontend Development Basics (HTML, CSS, JS)", status: "In Progress", score: undefined, completedDate: undefined },
    { id: "assess3", studentId: "student@scad.edu", assessmentName: "Agile Methodology Quiz", status: "Not Started", score: undefined, completedDate: undefined },
    { id: "assess4", studentId: "prostudent@scad.edu", assessmentName: "Advanced Game Mechanics", status: "Completed", score: 92, completedDate: "2024-04-01T00:00:00Z", postedToProfile: true },
    { id: "assess5", studentId: "prostudent@scad.edu", assessmentName: "Character Design Fundamentals", status: "Not Started", score: undefined, completedDate: undefined, postedToProfile: false },
    { id: "assess6", studentId: "prostudent@scad.edu", assessmentName: "Advanced Shading Techniques", status: "Completed", score: 88, completedDate: "2024-05-10T00:00:00Z", feedback: "Excellent control of light and shadow.", postedToProfile: true },
    { id: "assess7", studentId: "prostudent@scad.edu", assessmentName: "Storyboarding Essentials", status: "Completed", score: 75, completedDate: "2024-06-01T00:00:00Z", feedback: "Good sequencing, work on clarity of action.", postedToProfile: false },
    { id: "assess8", studentId: "prostudent@scad.edu", assessmentName: "Unreal Engine 5 Blueprints", status: "In Progress", score: undefined, completedDate: undefined, postedToProfile: false },
];


export default function AssessmentsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [assessments, setAssessments] = useState<StudentAssessment[]>([]);

  useEffect(() => {
    if (user?.role === 'student') {
      setAssessments(mockStudentAssessments.filter(asm => asm.studentId === user.id));
    }
  }, [user]);

  const handleTogglePostScore = (assessmentId: string, currentPostedStatus: boolean | undefined) => {
    const newPostedStatus = !currentPostedStatus;
    setAssessments(prevAssessments => 
      prevAssessments.map(asm => 
        asm.id === assessmentId ? { ...asm, postedToProfile: newPostedStatus } : asm
      )
    );
    // Update mock master list for persistence in demo
    const masterIndex = mockStudentAssessments.findIndex(asm => asm.id === assessmentId);
    if (masterIndex !== -1) {
      mockStudentAssessments[masterIndex].postedToProfile = newPostedStatus;
    }

    toast({
      title: newPostedStatus ? "Score Posted to Profile" : "Score Removed from Profile",
      description: `The score for this assessment will ${newPostedStatus ? 'now be visible on' : 'no longer be visible on'} your profile. (Mock Action)`,
    });
  };

  const handleTakeAssessment = (assessmentName: string, status: StudentAssessment['status']) => {
    let actionText = "";
    if (status === "Not Started") actionText = "Starting";
    else if (status === "In Progress") actionText = "Continuing";
    
    toast({
        title: `${actionText} Assessment`,
        description: `You are now ${actionText.toLowerCase()} the "${assessmentName}" assessment. (Mock Action)`,
    });
    // Here you would navigate to the assessment page or open a modal
  };


  if (user?.role === 'student' && !user.isPro) {
    return (
      <div className="container mx-auto py-12 flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Card className="w-full max-w-lg p-8 shadow-xl text-center bg-card">
          <CardHeader className="p-0 mb-6">
            <Crown className="h-20 w-20 mx-auto text-primary mb-6" />
            <CardTitle className="text-3xl font-bold text-foreground">Pro Feature Locked</CardTitle>
            <CardDescription className="text-xl mt-3 text-muted-foreground">
              Access to <span className="font-semibold text-primary">Assessments</span> is exclusive to SCAD InternLink Pro students.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0 mb-8">
            <p className="text-foreground/90">
              Upgrade your account to unlock this feature and many more, including advanced career tools, personalized feedback, and priority access to workshops and appointments.
            </p>
          </CardContent>
          <Button size="lg" className="w-full text-lg py-3">
            Upgrade to Pro (Mock Action)
          </Button>
        </Card>
      </div>
    );
  }

  if (user?.role !== 'student') {
    return <p className="text-center py-10 text-destructive">Access Denied. This page is for students only.</p>;
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <ListChecks className="mr-3 h-8 w-8" /> My Assessments
          </CardTitle>
          <CardDescription className="text-lg">
            Complete and review your skills assessments to showcase your abilities to potential employers.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {assessments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Assessment Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Completed Date</TableHead>
                  <TableHead>Post to Profile</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assessments.map((assessment) => (
                  <TableRow key={assessment.id}>
                    <TableCell className="font-medium">{assessment.assessmentName}</TableCell>
                    <TableCell>
                      <Badge variant={assessment.status === 'Completed' ? 'default' : assessment.status === 'In Progress' ? 'secondary' : 'outline'}>
                        {assessment.status}
                      </Badge>
                      {assessment.status === 'In Progress' && <Progress value={Math.floor(Math.random() * 50) + 20} className="mt-1 h-2 w-[100px]" />} 
                    </TableCell>
                    <TableCell>{assessment.score !== undefined ? `${assessment.score}%` : 'N/A'}</TableCell>
                    <TableCell>{assessment.completedDate ? new Date(assessment.completedDate).toLocaleDateString() : 'N/A'}</TableCell>
                    <TableCell>
                      {assessment.status === 'Completed' ? (
                        <div className="flex items-center space-x-2">
                            <Switch
                                id={`post-score-${assessment.id}`}
                                checked={!!assessment.postedToProfile}
                                onCheckedChange={() => handleTogglePostScore(assessment.id, assessment.postedToProfile)}
                                aria-label="Post score to profile"
                            />
                            <label htmlFor={`post-score-${assessment.id}`} className="text-sm text-muted-foreground">
                                {assessment.postedToProfile ? 'Posted' : 'Post'}
                            </label>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">N/A</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {assessment.status === 'Not Started' && <Button size="sm" onClick={() => handleTakeAssessment(assessment.assessmentName, assessment.status)}><PlayCircle className="mr-1.5 h-4 w-4" /> Start Assessment</Button>}
                      {assessment.status === 'In Progress' && <Button size="sm" variant="outline" onClick={() => handleTakeAssessment(assessment.assessmentName, assessment.status)}>Continue Assessment</Button>}
                      {assessment.status === 'Completed' && <Button size="sm" variant="ghost" onClick={() => toast({title: "View Results (Mock)", description:`Viewing results for ${assessment.assessmentName}. Feedback: ${assessment.feedback || 'N/A'}`})}><Eye className="mr-1.5 h-4 w-4" /> View Results</Button>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
             <p className="text-center text-muted-foreground py-10">No assessments assigned to you yet.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

