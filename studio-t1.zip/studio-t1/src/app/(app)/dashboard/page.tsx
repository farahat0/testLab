
"use client";

import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart2, Briefcase, FileText, Users, Book, GraduationCap, Bell, PlayCircle, Video, CalendarCheck2, MessageSquare, CalendarDays, CheckCircle } from 'lucide-react'; // Added MessageSquare, CheckCircle, CalendarDays
import Image from 'next/image';
import type { Major, Workshop } from '@/types'; // Added Workshop
import { coursesByMajor } from '@/types';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast'; // Added useToast

// Simulate access to some appointment data for notification purposes
// In a real app, this would come from a service or global state
const mockStudentAppointmentsForNotification = [
    { studentId: "prostudent@scad.edu", status: "Scheduled", title: "Resume Review with Dr. Carter" },
    { studentId: "student@scad.edu", status: "Pending Confirmation", title: "Career Counseling Request" },
];
const mockAllAppointmentsForScadOffice = [
    { status: "Pending Confirmation", studentName: "Alex Bee", type: "Resume Review" },
    { status: "Pending Confirmation", studentName: "Casey Dell", type: "Mock Interview" },
];

// Mock workshops data for notifications
const mockWorkshopsForNotification: Workshop[] = [
  { id: "ws1", title: "Resume Building Masterclass", date: "2024-09-15T00:00:00Z", time: "2:00 PM - 4:00 PM", description: "", attendees: ["prostudent@scad.edu"], isLive: false, videoUrl: "...", isCompleted: true },
  { id: "ws_live_upcoming", title: "Live UX Review", date: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(), time: "3:00 PM - 4:00 PM", description: "Live session!", attendees: ["prostudent@scad.edu"], isLive: true, isCompleted: false },
];


export default function DashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast(); // Initialize toast
  const [isCycleOpen, setIsCycleOpen] = useState(true); 
  const [reportStatusUpdated, setReportStatusUpdated] = useState(false); 
  const [hasNotifications, setHasNotifications] = useState(false);
  const [hasNewAppointmentUpdate, setHasNewAppointmentUpdate] = useState(false); // For pro student
  const [hasPendingAppointmentRequests, setHasPendingAppointmentRequests] = useState(false); // For SCAD office
  const [upcomingWorkshopNotif, setUpcomingWorkshopNotif] = useState<Workshop | null>(null);
  const [mockChatNotif, setMockChatNotif] = useState<string | null>(null);
  const [hasNewCompanyApplicationNotif, setHasNewCompanyApplicationNotif] = useState(false); // For company users


  useEffect(() => {
    // Simulate notifications
    const timer = setTimeout(() => {
      if (user?.role === 'student') {
        setReportStatusUpdated(true);
      }
      if (user?.role === 'student' && user.isPro) {
        const proStudentAppts = mockStudentAppointmentsForNotification.filter(
          app => app.studentId === user.id && (app.status === "Scheduled" || app.status === "Pending Confirmation")
        );
        if (proStudentAppts.length > 0) setHasNewAppointmentUpdate(true);

        // Check for upcoming registered workshops
        const today = new Date();
        const upcomingRegistered = mockWorkshopsForNotification.find(ws => 
            ws.attendees?.includes(user.id) && 
            new Date(ws.date) >= today && 
            new Date(ws.date) <= new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000) && // Within next 3 days
            !ws.isCompleted
        );
        if (upcomingRegistered) setUpcomingWorkshopNotif(upcomingRegistered);

        // Simulate a chat notification for an active live workshop
        const activeLiveWorkshop = mockWorkshopsForNotification.find(ws => 
            ws.isLive && 
            ws.attendees?.includes(user.id) && 
            !ws.isCompleted && 
            new Date(ws.date).toDateString() === today.toDateString() // Assuming it's today
        );
        if (activeLiveWorkshop) {
            setTimeout(() => setMockChatNotif(`New message in "${activeLiveWorkshop.title}" workshop chat! (Mock)`), 5000); // Mock chat after 5s
        }

      }
      if (user?.role === 'scad_office') {
        const pendingRequests = mockAllAppointmentsForScadOffice.filter(
            app => app.status === "Pending Confirmation"
        );
        if (pendingRequests.length > 0) setHasPendingAppointmentRequests(true);
      }
      if (user?.role === 'company') {
        setHasNewCompanyApplicationNotif(true); // Simulate a new application notification
      }
    }, 3000); 

    return () => clearTimeout(timer);
  }, [user]);

  useEffect(() => {
    const studentReportNotif = user?.role === 'student' && reportStatusUpdated;
    const studentAppointmentNotif = user?.role === 'student' && user.isPro && hasNewAppointmentUpdate;
    const scadOfficeAppointmentNotif = user?.role === 'scad_office' && hasPendingAppointmentRequests;
    const workshopNotif = !!upcomingWorkshopNotif;
    const chatNotif = !!mockChatNotif;
    const companyAppNotif = user?.role === 'company' && hasNewCompanyApplicationNotif;
    
    setHasNotifications(isCycleOpen || studentReportNotif || studentAppointmentNotif || scadOfficeAppointmentNotif || workshopNotif || chatNotif || companyAppNotif);
  }, [isCycleOpen, reportStatusUpdated, user, hasNewAppointmentUpdate, hasPendingAppointmentRequests, upcomingWorkshopNotif, mockChatNotif, hasNewCompanyApplicationNotif]);


  if (!user) {
    return <p>Loading user data...</p>;
  }

  const studentMajor = user.major as Major | undefined;
  const majorCourses = studentMajor ? coursesByMajor[studentMajor] : [];

  const dashboardItems = [
    { title: "Active Internships", value: "12", icon: Briefcase, color: "text-blue-500", bgColor: "bg-blue-100 dark:bg-blue-900/30" },
    { title: "Applications Received", value: "78", icon: FileText, color: "text-green-500", bgColor: "bg-green-100 dark:bg-green-900/30" },
    { title: "Registered Students", value: "250+", icon: Users, color: "text-yellow-500", bgColor: "bg-yellow-100 dark:bg-yellow-900/30" },
    { title: "Companies Onboarded", value: "45", icon: BarChart2, color: "text-purple-500", bgColor: "bg-purple-100 dark:bg-purple-900/30" },
  ];

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-start mb-8">
        <Card className="flex-grow shadow-lg border-primary/20 border-2">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-primary">Welcome to SCAD InternLink, {user.name || 'User'}!</CardTitle>
            <CardDescription className="text-lg">
              Your central hub for managing internships and connecting talent.
              You are logged in as: <span className="font-semibold capitalize text-accent">{user.role.replace('_', ' ')}</span>.
              {user.role === 'student' && user.major && (
                  <> Your declared major is: <span className="font-semibold text-accent">{user.major}</span>.</>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p>This is your personalized dashboard. From here, you can navigate to various sections of the platform using the sidebar.</p>
          </CardContent>
        </Card>
        
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="ml-4 relative">
              <Bell className="h-6 w-6 text-primary" />
              {hasNotifications && (
                <span className="absolute top-0 right-0 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80">
            <div className="grid gap-4">
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Notifications</h4>
                <p className="text-sm text-muted-foreground">
                  Recent updates and alerts.
                </p>
              </div>
              <ScrollArea className="max-h-[300px]">
              <div className="grid gap-2 pr-2">
                {isCycleOpen && (
                  <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                    <span className="flex h-2 w-2 translate-y-1 rounded-full bg-sky-500" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">
                        Internship Cycle Open!
                      </p>
                      <p className="text-sm text-muted-foreground">
                        The application cycle for Fall internships is now open.
                      </p>
                    </div>
                  </div>
                )}
                {reportStatusUpdated && user.role === 'student' && (
                   <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                    <span className="flex h-2 w-2 translate-y-1 rounded-full bg-green-500" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">
                        Report Status Update
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Your recent internship report status has been updated. Check "My Reports".
                      </p>
                    </div>
                  </div>
                )}
                {hasNewAppointmentUpdate && user.role === 'student' && user.isPro && (
                     <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                        <CalendarCheck2 className="h-4 w-4 translate-y-0.5 text-blue-500" />
                        <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                                Appointment Update
                            </p>
                            <p className="text-sm text-muted-foreground">
                                Your appointment (e.g., {mockStudentAppointmentsForNotification.find(a => a.studentId === user.id)?.title}) has been confirmed or updated.
                            </p>
                        </div>
                    </div>
                )}
                {upcomingWorkshopNotif && user.role === 'student' && user.isPro && (
                     <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                        <CalendarDays className="h-4 w-4 translate-y-0.5 text-purple-500" />
                        <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                                Upcoming Workshop!
                            </p>
                            <p className="text-sm text-muted-foreground">
                                Workshop "{upcomingWorkshopNotif.title}" is on {new Date(upcomingWorkshopNotif.date).toLocaleDateString()}.
                            </p>
                        </div>
                    </div>
                )}
                 {mockChatNotif && user.role === 'student' && user.isPro && (
                     <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                        <MessageSquare className="h-4 w-4 translate-y-0.5 text-teal-500" />
                        <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                                Workshop Chat
                            </p>
                            <p className="text-sm text-muted-foreground">
                                {mockChatNotif}
                            </p>
                        </div>
                    </div>
                )}
                {hasPendingAppointmentRequests && user.role === 'scad_office' && (
                    <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                        <CalendarCheck2 className="h-4 w-4 translate-y-0.5 text-orange-500" />
                        <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                                New Appointment Requests
                            </p>
                            <p className="text-sm text-muted-foreground">
                                There are new student appointment requests (e.g., {mockAllAppointmentsForScadOffice.filter(a=>a.status === "Pending Confirmation").length} pending).
                            </p>
                        </div>
                    </div>
                )}
                {user?.role === 'company' && hasNewCompanyApplicationNotif && (
                     <div className="grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                        <CheckCircle className="h-4 w-4 translate-y-0.5 text-green-500" />
                        <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                                New Student Application!
                            </p>
                            <p className="text-sm text-muted-foreground">
                                A student has applied to one of your internship postings. Check "Applications".
                            </p>
                        </div>
                    </div>
                )}
                {!hasNotifications && ( 
                    <p className="text-sm text-muted-foreground text-center py-4">No new notifications.</p>
                )}
              </div>
              </ScrollArea>
            </div>
          </PopoverContent>
        </Popover>
      </div>


      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
        {dashboardItems.map((item, index) => (
          <Card key={index} className={`shadow-md hover:shadow-lg transition-shadow ${item.bgColor}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
              <item.icon className={`h-5 w-5 ${item.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{item.value}</div>
              <p className="text-xs text-muted-foreground">
                +10% from last month (mock)
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity (Mock)</CardTitle>
            <CardDescription>Overview of recent platform events.</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full"><FileText className="h-4 w-4 text-green-600"/></div>
                New application for "UX Design Intern"
              </li>
              <li className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full"><Briefcase className="h-4 w-4 text-blue-600"/></div>
                "Innovate Corp" posted a new "Software Engineer Intern" role.
              </li>
              <li className="flex items-center gap-3">
                <div className="p-2 bg-yellow-100 dark:bg-yellow-900/30 rounded-full"><Users className="h-4 w-4 text-yellow-600"/></div>
                5 new students registered today.
              </li>
            </ul>
          </CardContent>
        </Card>
        
        {user.role === 'student' && studentMajor && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center"><Video className="mr-2 h-5 w-5 text-primary"/>Internship Guidelines</CardTitle>
              <CardDescription>Understand what counts towards your internship requirement for {studentMajor}.</CardDescription>
            </CardHeader>
            <CardContent>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full">
                    <PlayCircle className="mr-2 h-4 w-4" /> Watch Requirement Video for {studentMajor}
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-xl text-primary">Internship Requirements: {studentMajor}</DialogTitle>
                    <DialogDescription>
                      This video explains the types of internships that fulfill SCAD's requirements for your major.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center my-4">
                    {/* Placeholder for video embed */}
                    <Image src={`https://picsum.photos/seed/${studentMajor.replace(/\s+/g, '')}/640/360`} alt={`Video placeholder for ${studentMajor}`} data-ai-hint="abstract design" width={640} height={360} className="rounded-md" />
                  </div>
                   <p className="text-sm text-muted-foreground"> (Mock Video Content) Key points for {studentMajor}: Minimum duration of X weeks, relevant industry experience, faculty advisor approval needed for final report.</p>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}


        {user.role === 'student' && studentMajor && majorCourses.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center"><GraduationCap className="mr-2 h-5 w-5 text-primary"/>Courses in Your Major: {studentMajor}</CardTitle>
              <CardDescription>A selection of courses relevant to your field of study.</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px]">
                <ul className="space-y-2">
                  {majorCourses.map(course => (
                    <li key={course} className="flex items-center gap-2 p-2 rounded-md hover:bg-secondary">
                      <Book className="h-4 w-4 text-muted-foreground"/>
                      <span>{course}</span>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            </CardContent>
          </Card>
        )}

        {user.role !== 'student' && ( 
            <Card className="relative overflow-hidden">
                <Image 
                    src="https://picsum.photos/seed/dashboard/600/400" 
                    alt="Campus Life" 
                    fill
                    style={{objectFit: 'cover'}}
                    className="opacity-20"
                    data-ai-hint="campus students" 
                />
              <CardHeader className="relative z-10">
                <CardTitle>Stay Connected</CardTitle>
                <CardDescription>Explore upcoming SCAD events and workshops.</CardDescription>
              </CardHeader>
              <CardContent className="relative z-10">
                <p>Check the "Workshops" section for new career development opportunities.</p>
              </CardContent>
            </Card>
        )}
      </div>
    </div>
  );
}

