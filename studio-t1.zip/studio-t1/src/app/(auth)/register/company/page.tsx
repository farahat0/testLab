
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import type { CompanySizeKey, Industry } from '@/types';
import { CompanySizes, Industries } from '@/types';
import { Briefcase, UploadCloud, FileText, Image as ImageIcon } from 'lucide-react';

export default function CompanyRegistrationPage() {
  const [companyName, setCompanyName] = useState('');
  const [industry, setIndustry] = useState<Industry | ''>('');
  const [companySize, setCompanySize] = useState<CompanySizeKey | ''>('');
  const [companyEmail, setCompanyEmail] = useState('');
  const [companyLogo, setCompanyLogo] = useState<File | null>(null);
  const [taxDocuments, setTaxDocuments] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { registerCompany } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!industry || !companySize) {
      toast({ title: "Missing Fields", description: "Please select industry and company size.", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    // Simulate backend processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    const success = await registerCompany({
      name: companyName,
      industry: industry as Industry,
      size: companySize as CompanySizeKey,
      email: companyEmail,
      logo: companyLogo || undefined,
      documents: taxDocuments ? [taxDocuments] : undefined,
    });
    setIsLoading(false);
    if (success) {
      toast({ 
        title: "Registration Submitted!", 
        description: "Your company application has been submitted for review. You will be notified upon approval.",
        duration: 5000,
      });
      router.push('/login'); // Redirect to login, or a "pending approval" page
    } else {
      toast({
        title: "Registration Failed",
        description: "Could not register company. Please check your details and try again.",
        variant: "destructive",
      });
    }
  };

  const handleFileChange = (setter: React.Dispatch<React.SetStateAction<File | null>>) => (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setter(e.target.files[0]);
    } else {
      setter(null);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background to-secondary p-4 selection:bg-primary/20">
      <Card className="w-full max-w-xl shadow-2xl border-primary/10">
        <CardHeader className="text-center space-y-2">
           <div className="mx-auto mb-3 flex items-center justify-center gap-2.5 text-primary">
            <Briefcase className="h-12 w-12" />
            <h1 className="text-4xl font-bold tracking-tight">SCAD InternLink</h1>
          </div>
          <CardTitle className="text-3xl font-semibold">Company Registration</CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            Join our network to connect with exceptional SCAD talent.
          </CardDescription>
        </CardHeader>
        <CardContent className="px-6 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="companyName">Company Name</Label>
                <Input id="companyName" value={companyName} onChange={(e) => setCompanyName(e.target.value)} required placeholder="Your Company LLC" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="companyEmail">Official Company Email</Label>
                <Input id="companyEmail" type="email" value={companyEmail} onChange={(e) => setCompanyEmail(e.target.value)} required placeholder="contact@yourcompany.com" />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="industry">Industry</Label>
                <Select value={industry} onValueChange={(value) => setIndustry(value as Industry)} required>
                  <SelectTrigger id="industry" className="w-full">
                    <SelectValue placeholder="Select industry (e.g., Technology)" />
                  </SelectTrigger>
                  <SelectContent>
                    {Industries.map((ind) => (
                      <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="companySize">Company Size</Label>
                <Select value={companySize} onValueChange={(value) => setCompanySize(value as CompanySizeKey)} required>
                  <SelectTrigger id="companySize" className="w-full">
                    <SelectValue placeholder="Select company size" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(CompanySizes).map(([key, value]) => (
                      <SelectItem key={key} value={key}>{value}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label htmlFor="companyLogo" className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5 text-muted-foreground"/> Company Logo (Optional)
                </Label>
                <Input id="companyLogo" type="file" accept="image/png, image/jpeg, image/svg+xml" onChange={handleFileChange(setCompanyLogo)} 
                       className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer" />
                {companyLogo && <p className="text-xs text-muted-foreground mt-1">Selected: {companyLogo.name} ({(companyLogo.size / 1024).toFixed(1)} KB)</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="taxDocuments" className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-muted-foreground"/> Proof of Legitimacy (e.g., Tax ID, Business License)
                </Label>
                <Input id="taxDocuments" type="file" accept=".pdf,.doc,.docx,.jpg,.png" onChange={handleFileChange(setTaxDocuments)} required
                       className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer" />
                {taxDocuments && <p className="text-xs text-muted-foreground mt-1">Selected: {taxDocuments.name} ({(taxDocuments.size / 1024).toFixed(1)} KB)</p>}
              </div>
            </div>
            
            <Button type="submit" className="w-full text-lg py-3 mt-4" disabled={isLoading}>
              {isLoading ? 'Submitting Application...' : 'Register Company'}
              {!isLoading && <UploadCloud className="ml-2 h-5 w-5" />}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col items-center space-y-3 py-6 bg-secondary/30">
          <p className="text-sm text-muted-foreground">
            By registering, you agree to SCAD InternLink&apos;s Terms of Service and Privacy Policy.
          </p>
          <p className="text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" className="font-semibold text-primary hover:underline">
              Log In Here
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
