
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth, MOCK_USERS } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Briefcase, LogInIcon, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const success = await login(email, password);
    setIsLoading(false);
    if (success) {
      toast({ title: "Login Successful", description: "Welcome back!" });
      router.push('/dashboard');
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid email or password. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Sort MOCK_USERS by email to ensure consistent order for hydration
  const sortedMockUsers = Object.entries(MOCK_USERS).sort(([emailA], [emailB]) => emailA.localeCompare(emailB));

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background to-secondary p-4">
      <div className="flex flex-col items-center space-y-8">
        <Card className="w-full max-w-md shadow-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex items-center justify-center gap-2 text-primary">
              <Briefcase className="h-10 w-10" />
              <h1 className="text-3xl font-bold">SCAD InternLink</h1>
            </div>
            <CardTitle className="text-2xl">Welcome Back!</CardTitle>
            <CardDescription>Log in to access your account and opportunities.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="text-base"
                />
              </div>
              <Button type="submit" className="w-full text-lg py-6" disabled={isLoading}>
                {isLoading ? 'Logging in...' : 'Log In'}
                {!isLoading && <LogInIcon className="ml-2 h-5 w-5" />}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col items-center space-y-2">
            <Link href="#" className="text-sm text-primary hover:underline">
                Forgot password?
              </Link>
            <p className="text-sm text-muted-foreground">
              Don&apos;t have an account?{' '}
              <Link href="/register/company" className="font-semibold text-primary hover:underline">
                Register as a Company
              </Link>
            </p>
            {/* Add link for student registration if applicable later */}
          </CardFooter>
        </Card>

        <Alert className="w-full max-w-md shadow-lg">
          <Info className="h-5 w-5" />
          <AlertTitle className="font-semibold">Mock Credentials for Demo</AlertTitle>
          <AlertDescription>
            <p className="mb-2">You can use any of the following email addresses to log in. <strong>Any password will work.</strong></p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              {sortedMockUsers.map(([email, userDetails]) => (
                <li key={email}>
                  <strong>{email}</strong> (Role: <span className="capitalize">{userDetails.role.replace('_', ' ')}</span>)
                </li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}

