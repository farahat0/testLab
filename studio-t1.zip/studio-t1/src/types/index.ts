

export type UserRole = 'student' | 'company' | 'scad_office' | 'faculty';

export interface PastInternship {
  companyName: string;
  jobTitle: string;
  responsibilities: string;
  duration: string; // e.g., "May 2023 - Aug 2023"
}

export type StudentInternshipStatus = "Not Started" | "Actively Interning" | "Internship Completed" | "Report Submitted" | "Report Approved";

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name?: string;
  // Student specific fields
  jobInterests?: string;
  pastInternships?: PastInternship[];
  collegeActivities?: string;
  major?: Major; 
  semester?: string; 
  internshipStatus?: StudentInternshipStatus; // Added for SCAD Office student filtering
  // PRO Student badge
  isPro?: boolean;
  // Profile visibility
  profileViewedBy?: string[]; // List of company names that viewed the profile
}

export const Industries = [
  "Technology", "Healthcare", "Finance", "Education", "Design", 
  "Marketing", "Engineering", "Arts", "Media", "Hospitality", "Other"
] as const;

export type Industry = typeof Industries[number];

export const CompanySizes = {
  small: "Small (1-50 employees)",
  medium: "Medium (51-100 employees)",
  large: "Large (101-500 employees)",
  corporate: "Corporate (501+ employees)",
} as const;

export type CompanySizeKey = keyof typeof CompanySizes;

export interface Company {
  id: string;
  name: string;
  industry: Industry;
  size: CompanySizeKey;
  logoUrl?: string; 
  email: string;
  isVerified?: boolean; 
  applicationStatus?: 'Pending' | 'Approved' | 'Rejected'; // For SCAD office view
  submittedAt?: string; // ISO Date string for application timestamp
}

export interface Internship {
  id: string;
  title: string;
  companyId: string;
  companyName: string; 
  companyLogo?: string; 
  duration: string; 
  type: 'Paid' | 'Unpaid';
  salary?: string; 
  skillsRequired: string[];
  jobDescription: string;
  industry: Industry;
  status?: 'Open' | 'Closed'; 
  applicationsCount?: number; 
  postedDate: string; // ISO date string
  location?: string; // e.g. "Remote", "Savannah, GA"
}

export const Majors = [
  "Animation", "Graphic Design", "UX Design", "Film & Television", "Advertising", 
  "Fashion Design", "Industrial Design", "Interior Design", "Photography", "Visual Effects", "Other"
] as const;
export type Major = typeof Majors[number];

export const Semesters = Array.from({ length: 8 }, (_, i) => `Semester ${i + 1}`);

export type InternshipApplicationStatus = "Pending" | "Reviewed" | "Interviewing" | "Offered" | "Accepted" | "Rejected" | "Withdrawn" | "Completed";

export interface InternshipApplication {
  id: string;
  internshipId: string;
  internshipTitle: string; // Denormalized
  companyName: string; // Denormalized
  companyId: string; // For company filtering
  studentId: string;
  studentName: string; // Denormalized
  studentEmail: string; // Denormalized
  status: InternshipApplicationStatus;
  appliedDate: string; // ISO Date string
  documents?: { name: string, url?: string }[]; // CV, Cover Letter, etc.
}
export interface WorkshopNote {
  studentId: string;
  workshopId: string;
  content: string;
  lastUpdated: string; // ISO Date string
}
export interface Workshop {
  id: string;
  title: string;
  date: string; // ISO date string
  time: string; // e.g., "10:00 AM - 12:00 PM"
  description: string;
  facilitator?: string;
  location?: string; // "Online" or physical location
  registrationLink?: string;
  maxAttendees?: number;
  registeredAttendees?: number;
  isLive?: boolean; // True if the workshop is a live session
  videoUrl?: string; // URL for pre-recorded video or live session link
  attendees?: string[]; // List of student IDs registered
  isCompleted?: boolean; // True if the workshop date/time has passed
  rating?: number; // Student's rating for the workshop
  feedback?: string; // Student's feedback for the workshop
}

export type AppointmentStatus = "Scheduled" | "Completed" | "Cancelled" | "Pending Confirmation";
export type AppointmentType = "Career Counseling" | "Resume Review" | "Mock Interview" | "Report Clarification" | "Other";


export interface Appointment {
  id: string;
  studentId: string;
  studentName: string;
  advisorId?: string;
  advisorName?: string;
  type: AppointmentType;
  date: string; // ISO date string
  time: string;
  status: AppointmentStatus;
  notes?: string;
  isOnline?: boolean; // Added to indicate if the other party is online
}

export interface StudentAssessment {
  id: string;
  studentId: string;
  assessmentName: string;
  status: "Not Started" | "In Progress" | "Completed";
  score?: number;
  completedDate?: string; // ISO date string
  feedback?: string;
  postedToProfile?: boolean; // New field to track if score is posted to profile
}

export type InternshipReportStatus = "Pending Review" | "Approved" | "Needs Revision" | "Draft" | "Appealed" | "Rejected";


export interface InternshipReport {
  id: string;
  studentId: string;
  studentName: string;
  studentMajor?: Major; // Added for filtering
  internshipId: string;
  internshipTitle: string; // The title of the internship itself
  companyName: string;
  submissionDate: string; // ISO date string
  
  // Report content
  reportTitle: string; // Title of the report document
  introduction: string;
  body: string;
  
  // Company Evaluation
  companyEvaluation?: string;
  recommendCompany?: boolean;
  
  // Academic reflection
  relevantCourses?: string[];

  facultyAdvisorId?: string;
  facultyAdvisorName?: string;
  status: InternshipReportStatus;
  facultyComments?: string; // Comments from faculty if report needs revision or is rejected
  appealMessage?: string; // Student's message if appealing

  // New fields for detailed view
  internshipStartDate?: string; // ISO date string
  internshipEndDate?: string; // ISO date string
  companySupervisorName?: string; 
}

export const coursesByMajor: Record<Major, string[]> = {
  "Animation": ["ANIM 101: Intro to Animation", "ANIM 220: 2D Animation", "ANIM 350: 3D Modeling", "ANIM 410: Character Animation", "VFX 200: Intro to Visual Effects"],
  "Graphic Design": ["GRDS 101: Intro to Graphic Design", "GRDS 205: Typography I", "GRDS 310: Branding Systems", "GRDS 402: Portfolio Development", "ADS 220: Art Direction"],
  "UX Design": ["UXDS 200: Foundations of UX", "UXDS 250: User Research Methods", "UXDS 310: Interaction Design", "UXDS 380: Prototyping", "IXDS 420: Emerging UX Technologies"],
  "Film & Television": ["FILM 100: Intro to Filmmaking", "FILM 230: Cinematography", "FILM 315: Editing Techniques", "FILM 405: Directing Workshop", "PROD 250: Production Management"],
  "Advertising": ["ADS 101: Principles of Advertising", "ADS 250: Copywriting", "ADS 320: Media Strategy", "ADS 410: Campaign Development", "MKTG 200: Marketing Principles"],
  "Fashion Design": ["FASH 100: Intro to Fashion", "FASH 215: Patternmaking", "FASH 330: Draping Techniques", "FASH 400: Senior Collection", "FASH 250: Textile Science"],
  "Industrial Design": ["INDS 101: Design Thinking", "INDS 220: Materials and Processes", "INDS 305: Product Design Studio", "INDS 450: Advanced Prototyping", "DRAW 200: Technical Drawing"],
  "Interior Design": ["IDSN 101: Fundamentals of Interior Design", "IDSN 225: Space Planning", "IDSN 340: Lighting Design", "IDSN 410: Commercial Interiors Studio", "ARCH 100: Intro to Architecture"],
  "Photography": ["PHOT 101: Intro to Digital Photography", "PHOT 210: Lighting Techniques", "PHOT 300: Studio Photography", "PHOT 450: Advanced Portfolio", "COMM 205: Visual Storytelling"],
  "Visual Effects": ["VFX 100: Intro to VFX", "VFX 250: Compositing I", "VFX 310: 3D for VFX", "VFX 400: Dynamics and Simulation", "ANIM 250: Motion Graphics"],
  "Other": ["GENE 100: General Elective", "ART 101: Art History Survey", "COMM 105: Public Speaking"],
};

// Statistics specific types
export interface ReportStats {
  approved: number;
  rejected: number;
  flagged: number; // or needsRevision
  pending: number;
  total: number;
}

export interface CompanyRating {
  companyName: string;
  averageRating: number; // e.g., out of 5
  numberOfReviews: number;
}

export interface CourseUsage {
  courseName: string;
  mentionCount: number;
}

export interface OverallFacultyStats {
  totalAdvisedStudents: number;
  avgReviewTimeDays: number; // Average time faculty take to review a report
  reportCycleStats: ReportStats; // Stats for the current/selected cycle
  mostFrequentCoursesInReports: CourseUsage[];
  topRatedCompaniesByAdvisees: CompanyRating[];
  topCompaniesByInternshipCountForAdvisees: Array<{ companyName: string; internshipCount: number }>;
}

export interface OverallScadOfficeStats extends OverallFacultyStats {
    // SCAD Office might have broader stats
    totalPlatformStudents: number;
    totalPlatformCompanies: number;
    totalActiveInternships: number;
    platformReportCycleStats: ReportStats; // Platform wide
    platformMostFrequentCourses: CourseUsage[];
    platformTopRatedCompanies: CompanyRating[];
    platformTopCompaniesByInternshipCount: Array<{ companyName: string; internshipCount: number }>;
}




    
